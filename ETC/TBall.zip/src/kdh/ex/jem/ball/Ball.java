package kdh.ex.jem.ball;

import kdh.ex.jem.HMRenderer;
import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec3;
import homi.JEMEngine.Scene.Scene;

import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.BodyType;

public class Ball {
	
	public static final int DOWN = 1;
	public static final int LEFT = 2;
	public static final int UP = 3;
	public static final int RIGHT = 4;
	
	public EMPlane m_Ball;
	public stEMVec3 m_stSmoot;
	
	public float pitch;
	public float roll;
	
	public int BallMove;
	
	public float pitchAmplify;	// �� ���� �����̴� ��(�Ÿ�) ����
	public float rollAmplify;		// �� ���� �����̴� ��(�Ÿ�) ����
	
	public boolean m_LiveState;
	
	
	public Ball(){
		m_stSmoot = new stEMVec3();
	}
	
	public void Enter(Scene sc)
	{
		pitchAmplify 	= 15.0f;
		rollAmplify 	= 7.0f;
		
		BallMove = 1;
		
		
		BodyDef stBDef 		= new BodyDef();							//!< Body�� ��������� Body�� ��ġ �� Ÿ�� ������ ����
		stBDef.type 		= BodyType.DYNAMIC;
		//stBDef.allowSleep 	= false;
		stBDef.position 	= new Vec2(0.0f* HMRenderer.m_fViulX, 0.0f* HMRenderer.m_fViulX);
		Body pBody 			= sc.getWorldPt().createBody(stBDef);				//!< Body�� �����Ѵ�
		
		CircleShape shape 	= new CircleShape();
		shape.m_radius = 2.0f;//* (HMRenderer.m_fViulX* HMRenderer.m_fViulY);
		
		pBody.createFixture(shape, 1.0f);					//!< Shape�� �����Ѵ�.
		
		m_Ball = new EMPlane();						//!< �����ڷ� Plane�� ����
		m_Ball.setTexture(sc, "image/ball.png");	//!< Plane���� ������ �Ǿ��� �ؽ���
		//m_Ball.setPos(0.0f,0.0f,0.0f);
		m_Ball.setFrustumCulling(false);				//!< Plane�� ī�޶� �ٶ󺸴� ��ġ���� ��� ��� plane�� �׷����� �ʽ��ϴ�. false�� �ݴ�
		//m_Ball.setBoundingBoxCalc(true);				//!< FrustumCulling�� �Ϸ��� �� BoundingBoxCalc����� ������մϴ� 
		m_Ball.setBlend(true);						//!< �������� �ϰ� �ʹٸ� true���ּ��� �⺻���� false�Դϴ�.
		m_Ball.connectBody(pBody);	//!< Plane�� ������ ������� ���� ��ü�� pBody�� �����մϴ�
		m_Ball.setType(0);
		m_Ball.setShow(true);

		sc.commit(1, "Ball", m_Ball);
		
		m_LiveState = true;
	}
	
	public void Update(float dt)
	{
		pitch = EM2DEngine.getPitch();
		roll  = EM2DEngine.getRoll();
		
		EM2DEngine.D_CAMERA.setPos(m_stSmoot.m_fX,m_stSmoot.m_fY);
		
		if(m_LiveState == true)
		{
			switch(BallMove)
			{
			case DOWN:
				m_Ball.moveX( -pitch * pitchAmplify * dt);
				
				m_stSmoot.m_fX = SmoothStep(m_stSmoot.m_fX,m_Ball.getPosVec2().m_fX ,5.0f*dt);
				m_stSmoot.m_fY = SmoothStep(m_stSmoot.m_fY,m_Ball.getPosVec2().m_fY ,5.0f*dt);
				//EM2DEngine.D_CAMERA.setPos(m_stSmoot.m_fX,m_stSmoot.m_fY);
				
				//EM2DEngine.D_CAMERA.setPos(m_Ball.getPosVec2().m_fX,m_Ball.getPosVec2().m_fY);
				break;
			case LEFT:
				m_Ball.moveY( -pitch * pitchAmplify * dt);
				
				m_stSmoot.m_fX = SmoothStep(m_stSmoot.m_fX,-m_Ball.getPosVec2().m_fX ,5.0f*dt);
				m_stSmoot.m_fY = SmoothStep(m_stSmoot.m_fY,-m_Ball.getPosVec2().m_fY ,5.0f*dt);
				//EM2DEngine.D_CAMERA.setPos(m_stSmoot.m_fX,m_stSmoot.m_fY);
				
				//EM2DEngine.D_CAMERA.setPos(-m_Ball.getPosVec2().m_fX,-m_Ball.getPosVec2().m_fY);
				break;
			case UP:
				m_Ball.moveX(pitch * pitchAmplify * dt);
				
				m_stSmoot.m_fX = SmoothStep(m_stSmoot.m_fX,m_Ball.getPosVec2().m_fX ,5.0f*dt);
				m_stSmoot.m_fY = SmoothStep(m_stSmoot.m_fY,m_Ball.getPosVec2().m_fY ,5.0f*dt);
				//EM2DEngine.D_CAMERA.setPos(m_stSmoot.m_fX,m_stSmoot.m_fY);
				
				//EM2DEngine.D_CAMERA.setPos(m_Ball.getPosVec2().m_fX,m_Ball.getPosVec2().m_fY);
				break;
			case RIGHT:
				m_Ball.moveY( pitch * pitchAmplify * dt);
				
				m_stSmoot.m_fX = SmoothStep(m_stSmoot.m_fX,-m_Ball.getPosVec2().m_fX ,5.0f*dt);
				m_stSmoot.m_fY = SmoothStep(m_stSmoot.m_fY,-m_Ball.getPosVec2().m_fY ,5.0f*dt);
				//EM2DEngine.D_CAMERA.setPos(m_stSmoot.m_fX,m_stSmoot.m_fY);
				
				//EM2DEngine.D_CAMERA.setPos(-m_Ball.getPosVec2().m_fX,-m_Ball.getPosVec2().m_fY);
				break;
			}
			
			m_Ball.setZRot(m_Ball.getZRot() + ((pitch)*dt));
		}
		
	}
	
	public void Render()
	{
		
	}
	
	public void SetCameraPos()
	{
		EM2DEngine.D_CAMERA.setPos(m_stSmoot.m_fX,m_stSmoot.m_fY);
	}
	
	public void SetDie(boolean LiveState)
	{
		m_LiveState = LiveState;
	}
	
	public boolean GetDie()
	{
		return m_LiveState;
	}
	
	static float Clamp(float value, float min, float max)
	{
		return Math.max(min, Math.min(max, value));
	}
	
	static float Lerp(float value1, float value2, float amount)
	{
		return (value1 + ((value2 - value1) * amount ));
	}
	
	static public float SmoothStep(float value1, float value2, float amount)
	{
		float num = Clamp(amount, 0.0f, 1.0f);
		return Lerp(value1, value2, (num * num) * (3.0f - (2.0f * num)));
	}
	
	public void SetPhysic(int Rid)
	{
		BallMove = Rid;
	}
}
