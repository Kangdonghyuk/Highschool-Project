package kdh.and.was.sheep;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMAni;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.BodyType;
import org.jbox2d.dynamics.FixtureDef;

public class Sheep {

	private static final int SHEEP_NORMAL = 0;
	private static final int SHEEP_GROW = 1;
	private static final int SHEEP_FIGHT = 2;
	private static final int SHEEP_WIN = 3;

	private static final float SHEEP_MAX_SIZE_X = 45.0f;
	private static final float SHEEP_MAX_SIZE_Y = 45.0f;

	private static final float SHEEP_MIN_SIZE_X = 4.0f;
	private static final float SHEEP_MIN_SIZE_Y = 4.0f;

	private static final float SHEEP_ADD_SIZE_X = 0.2f;
	private static final float SHEEP_ADD_SIZE_Y = 0.2f;

	private static final float SHEEP_SUB_SIZE_X = 0.8f;
	private static final float SHEEP_SUB_SIZE_Y = 0.8f;

	private static final float PITCH = 5.0f;
	private static final float ROLL = 2.0f;
	private static final float ROLLBASE = 30.0f;

	private static final float SHEEP_SUB_SIZE_POISON = 0.08f;

	private Scene m_NowScene;

	private EMAni m_SheepAni;

	private BodyDef m_bDef;
	private Body m_Body;
	private CircleShape m_Shape;
	private FixtureDef m_FixDef;

	private stEMVec2 m_stVal;

	private boolean m_bGrowState;
	private boolean m_bPoisonState;
	private boolean m_bPoisonAlpha;
	private boolean m_bUnbeatableState;

	private int m_SheepAniType;

	private int m_nNowTime;
	private int m_nPoisonTime;
	private int m_nFightTime;
	private int m_nGrowTime;
	private int m_nUnbeatableTime;

	public void Enter(Scene scene) {
		m_NowScene = scene;

		m_bDef = null;
		m_Body = null;
		m_Shape = null;
		m_FixDef = null;

		m_SheepAni = null;

		m_stVal = null;

		m_SheepAniType = SHEEP_NORMAL;

		m_bGrowState = false;
		m_bPoisonAlpha = false;
		m_bPoisonState = false;
		m_bUnbeatableState = false;

		m_nNowTime = 0;
		m_nPoisonTime = 0;
		m_nFightTime = 0;
		m_nGrowTime = 0;
		m_nUnbeatableTime = 0;
	}

	private void CreatePhysic(stEMVec2 stSheepPos, float fSheepRadius) {
		m_bDef = new BodyDef();
		m_bDef.type = BodyType.DYNAMIC;
		m_bDef.fixedRotation = true;
		m_bDef.position = new Vec2(stSheepPos.m_fX, stSheepPos.m_fY);

		m_Body = m_NowScene.getWorldPt().createBody(m_bDef);

		m_Shape = new CircleShape();
		m_Shape.m_radius = fSheepRadius;

		m_FixDef = new FixtureDef();
		m_FixDef.shape = m_Shape;
		m_FixDef.density = 1.0f;
		m_FixDef.restitution = 0.0f;

		m_Body.createFixture(m_FixDef);
	}

	private void CreatePlane() {
		m_SheepAni = new EMAni();
		m_SheepAni.setCols(4);
		m_SheepAni.setRows(3);
		m_SheepAni.setTexture(m_NowScene, "image/sheep/sheep_ani.png",
				new stEMVec2(341.2f, 256.0f), m_SheepAni.getCols(),
				m_SheepAni.getRows());
		m_SheepAni.setFrustumCulling(false);
		m_SheepAni.setBlend(true);
		m_SheepAni.setType(0);
		m_SheepAni.connectBody(m_Body);
		m_SheepAni.setShow(true);

		m_SheepAni.setMotion(SHEEP_NORMAL, 3, 0.4f, 0, 1, 2);
		m_SheepAni.setMotion(SHEEP_GROW, 3, 0.4f, 6, 7, 8);
		m_SheepAni.setMotion(SHEEP_FIGHT, 1, 0.4f, 9);
		m_SheepAni.setMotion(SHEEP_WIN, 3, 0.4f, 3, 4, 5);

		m_SheepAni.changeMotion(SHEEP_NORMAL);

		m_NowScene.commit(4, "Sheep", m_SheepAni);
	}

	private void ChangeMotion() {
		if (m_nNowTime < m_nGrowTime) {
			if (m_SheepAniType != SHEEP_GROW) {
				m_SheepAniType = SHEEP_GROW;
				m_SheepAni.changeMotion(m_SheepAniType);
			}
		} else {
			if (m_nNowTime < m_nFightTime) {
				if (m_SheepAniType != SHEEP_FIGHT) {
					m_SheepAniType = SHEEP_FIGHT;
					m_SheepAni.changeMotion(m_SheepAniType);
				}
			} else {
				if (m_SheepAniType != SHEEP_NORMAL) {
					m_SheepAniType = SHEEP_NORMAL;
					m_SheepAni.changeMotion(m_SheepAniType);
				}
			}
		}
	}

	private void CheckItem() {
		if (m_bUnbeatableState == true) {
			if (m_nNowTime > m_nUnbeatableTime) {
				m_SheepAni.setColor(1.0f, 1.0f, 1.0f);
				m_bUnbeatableState = false;
			}
		}
		if (m_bPoisonState == true) {
			stEMVec2 _SheepSize = m_SheepAni.getSize();

			m_SheepAni.setSize(new stEMVec2(_SheepSize.m_fX
					- SHEEP_SUB_SIZE_POISON, _SheepSize.m_fY
					- SHEEP_SUB_SIZE_POISON));

			if (m_bPoisonAlpha == false) {
				m_SheepAni.setAlpha(m_SheepAni.getAlpha() - 0.05f);
				if (m_SheepAni.getAlpha() <= 0.5f)
					m_bPoisonAlpha = true;
			} else if (m_bPoisonAlpha == true) {
				m_SheepAni.setAlpha(m_SheepAni.getAlpha() + 0.05f);
				if (m_SheepAni.getAlpha() >= 1.0f)
					m_bPoisonAlpha = false;
			}

			if (m_nPoisonTime < m_nNowTime) {
				m_SheepAni.setAlpha(1.0f);
				m_bPoisonAlpha = false;
				m_bPoisonState = false;
			}
		}
	}

	private void CheckSheepSize() {
		if (m_SheepAni.getSize().m_fX < SHEEP_MIN_SIZE_X
				&& m_SheepAni.getSize().m_fY < SHEEP_MIN_SIZE_Y) {
			Lose();
		}
	}

	public void OnPause() {
		m_SheepAni.move(0.0f, 0.0f);
	}

	public void Grow() {
		stEMVec2 _SheepSize = m_SheepAni.getSize();

		if (_SheepSize.m_fX < SHEEP_MAX_SIZE_X
				&& _SheepSize.m_fY < SHEEP_MAX_SIZE_Y)
			m_SheepAni.setSize(new stEMVec2(_SheepSize.m_fX + SHEEP_ADD_SIZE_X,
					_SheepSize.m_fY + SHEEP_ADD_SIZE_Y));

		m_nGrowTime = m_nNowTime + 100;
	}

	public void NGrow() {
		stEMVec2 _SheepSize = m_SheepAni.getSize();

		m_SheepAni.setSize(new stEMVec2(_SheepSize.m_fX - SHEEP_SUB_SIZE_X,
				_SheepSize.m_fY - SHEEP_SUB_SIZE_Y));
		
		m_nFightTime = m_nNowTime + 300;
	}

	public void Poison() {
		if (m_bPoisonState == false) {
			m_bPoisonState = true;
			m_nPoisonTime = m_nNowTime + 4000;
		}
	}

	public void Unbeatable() {
		m_SheepAni.setColor(1.0f, 0.5f, 0.5f);
		m_bUnbeatableState = true;
		m_nUnbeatableTime = m_nNowTime + 3000;
	}

	public void Win() {
		m_SheepAni.setColor(1.0f, 1.0f, 1.0f);
		if (m_SheepAniType != SHEEP_WIN) {
			m_SheepAniType = SHEEP_WIN;
			m_SheepAni.changeMotion(m_SheepAniType);
		}
	}

	public void Lose() {
		m_SheepAni.setShow(false);
	}

	public void SetGrowState(boolean gstate) {
		m_bGrowState = gstate;
		if (m_bGrowState == true)
			Grow();
	}

	public boolean GetGrowState() {
		return m_bGrowState;
	}

	public boolean GetUnbeatableState() {
		return m_bUnbeatableState;
	}

	public boolean GetLifeState() {
		return m_SheepAni.getShow();
	}

	public void CreateSheep(stEMVec2 stSheepPos, float fSheepRadius) {
		CreatePhysic(stSheepPos, fSheepRadius);
		CreatePlane();

		m_stVal = new stEMVec2(0.0f, 0.0f);

		m_bGrowState = true;
	}

	public void Update(float dt, int nNowTime) {
		m_nNowTime = nNowTime;

		m_stVal.m_fX = -(EM2DEngine.getPitch() * PITCH);
		m_stVal.m_fY = -((EM2DEngine.getRoll() - ROLLBASE) * ROLL);

		m_SheepAni.move(m_stVal);
		
		if(EM2DEngine.D_SCENE.getChangeSceneName() == "TutorGame")
		{
			if(m_SheepAni.getSize().m_fX <= SHEEP_MIN_SIZE_X + 6.0f)
			{
				m_SheepAni.setSize(SHEEP_MIN_SIZE_X + 6.0f,SHEEP_MIN_SIZE_Y + 6.0f);
			}
		}


		// m_SheepAni.moveX(m_stVal.m_fX);
		// m_SheepAni.moveY(m_stVal.m_fY);

		ChangeMotion();
		CheckItem();

		CheckSheepSize();
	}

	public void ButtonUpdate(int nNowTime, float MoveX, float MoveY) {
		m_nNowTime = nNowTime;

		m_stVal.m_fX = MoveX;
		m_stVal.m_fY = MoveY;

		m_SheepAni.move(m_stVal);

		// m_SheepAni.moveX(m_stVal.m_fX);
		// m_SheepAni.moveY(m_stVal.m_fY);

		ChangeMotion();
		CheckItem();

		CheckSheepSize();
	}

	public EMPlane GetPlane() {
		return m_SheepAni;
	}
}
