package kdh.and.was.other;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class Ball {


	public EMPlane pBall;
	
	public float m_fG;
	public float m_fT;
	public float m_fMoveSpeed;
	public float m_fJumpPower;
	public float m_fJumpSpeed;
	public float m_fGround;
	public stEMVec2 m_stPos;
	public stEMVec2 m_stEndPos;
	public int	m_nLevel;
	public int	m_nKind;
	static public int m_nCommitNumber = 0;
	
	
	public void Init(Scene pThisScene, String strFilePath, int nLayer, float fStartX, float fStartY, float fEndX, float fEndY, float fJumpPower, float fMoveSpeed, float fGround, int nKind,int Level)
	{
		pBall = new EMPlane();						//!< �����ڷ� Plane�� ����
		pBall.setTexture(pThisScene, strFilePath);	//!< Plane���� ������ �Ǿ��� �ؽ���
		pBall.setFrustumCulling(false);				//!< Plane�� ī�޶� �ٶ󺸴� ��ġ���� ��� ��� plane�� �׷����� �ʽ��ϴ�. false�� �ݴ�
		pBall.setPos(fStartX * EM2DEngine.getMagnifX(), fStartY * EM2DEngine.getMagnifY(),0);
		//m_pMain.setBoundingBoxCalc(true);				//!< FrustumCulling�� �Ϸ��� �� BoundingBoxCalc����� ������մϴ� 
		pBall.setSize(1.0f * EM2DEngine.getMagnifX(), 1.0f * EM2DEngine.getMagnifY());
			
		pBall.setOrtho2D(true);
		pBall.setBlend(true);//!< �������� �ϰ� �ʹٸ� true���ּ��� �⺻���� false�Դϴ�.
		pBall.setShow(true);
		pThisScene.commit(nLayer, "newball" + Integer.toString(m_nCommitNumber++) , pBall);
		
		m_stPos = new stEMVec2();
		m_stEndPos = new stEMVec2();
		
		m_stPos.m_fX = fStartX * EM2DEngine.getMagnifX();
		m_stPos.m_fY = fStartY * EM2DEngine.getMagnifY();
		
		m_stEndPos.m_fX = fEndX * EM2DEngine.getMagnifX();
		m_stEndPos.m_fY = fEndY * EM2DEngine.getMagnifY();
		
		m_fJumpPower = fJumpPower * EM2DEngine.getMagnifY();
		m_fJumpSpeed = m_fJumpPower * EM2DEngine.getMagnifY();
		m_fMoveSpeed = fMoveSpeed * EM2DEngine.getMagnifX();
		
		m_fGround = fGround * EM2DEngine.getMagnifY();
		
		m_fG = 9.8f * EM2DEngine.getMagnifY();
		m_fT = 20.0f * EM2DEngine.getMagnifY();
		
		m_nKind = nKind;
		m_nLevel = Level;
	}
	public void Update(float dt)
	{
		if(m_nKind == 0)
		{
			
		}
		else if(m_nKind == 1)
		{
			if(m_nLevel == 0)
			{	
				if(m_stPos.m_fX < m_stEndPos.m_fX)
				{
					m_stPos.m_fX  += m_fMoveSpeed * dt;
				}
				if(m_stPos.m_fX > m_stEndPos.m_fX)
				{
					m_stPos.m_fX  -= m_fMoveSpeed * dt;
				}
				if(m_stPos.m_fX == m_stEndPos.m_fX)
				{
					m_stPos.m_fY=m_fGround;
					m_fJumpPower=0;
				}
				m_stPos.m_fY -= m_fJumpSpeed * dt; 
				m_fJumpSpeed -= m_fG * m_fT * dt;	
			
			
				if(m_stPos.m_fY > m_fGround)
				{
					m_stPos.m_fY = m_fGround;
					m_fJumpSpeed = 0;
					m_nLevel = 1;
				}
			}
			else if(m_nLevel == 1)
			{
				m_stPos.m_fY = m_fGround;
				m_fJumpSpeed = 0;
			}
		}
		
		else if(m_nKind == 2)
		{
			if(m_nLevel == 0)
			{
				if(m_stPos.m_fX < m_stEndPos.m_fX)
				{
					m_stPos.m_fX  += m_fMoveSpeed * dt;
				}
				if(m_stPos.m_fX > m_stEndPos.m_fX)
				{
					m_stPos.m_fX  -= m_fMoveSpeed * dt;
				}
				if(m_stPos.m_fX == m_stEndPos.m_fX)
				{
					m_stPos.m_fY=m_fGround;
					m_fJumpPower=0;
				}
				m_stPos.m_fY -= m_fJumpSpeed * dt; 
				m_fJumpSpeed -= m_fG * m_fT * dt;	
		
		
				if(m_stPos.m_fY > m_fGround)
				{
					m_stPos.m_fY = m_fGround;
					m_fJumpSpeed = 0;
					m_nLevel =1;
				}
			}
			
			
		}
		pBall.setPos(m_stPos.m_fX , m_stPos.m_fY,0);
	}
	
	public void Reset(float fEndX, float fEndY)
	{
		m_stEndPos.m_fX = fEndX * EM2DEngine.getMagnifX();
		m_stEndPos.m_fY = fEndY * EM2DEngine.getMagnifY();
		m_fJumpSpeed = m_fJumpPower * EM2DEngine.getMagnifY();
		m_nLevel = 0;
		
	}
	public void Exit()
	{
		
	}
	
}
