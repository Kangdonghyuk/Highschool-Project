package kdh.and.was.stage;

import homi.JEMEngine.EMVector.stEMVec2;

import javax.microedition.khronos.opengles.GL10;

import kdh.and.was.game.RootGame;

public class Stage49 extends RootGame {
	
	public Stage49(String NextScene, int SceneNumber)
	{
		super.NextScene(NextScene,SceneNumber);
	}
	
	@Override
	public void enter() {
		// TODO Auto-generated method stub
		
		super.enter();

		m_ShowStage.SetStage(49);
		
		m_Sheep.CreateSheep(new stEMVec2(0.0f,0.0f), 15.0f);
		
		m_Wolf.CreateWolf(new stEMVec2(40.0f,40.0f), 15.0f,m_Wolf.WOLF_GROW);
		m_Wolf.CreateWolf(new stEMVec2(40.0f,0.0f), 15.0f,m_Wolf.WOLF_POWER);
		m_Wolf.CreateWolf(new stEMVec2(40.0f,-40.0f), 15.0f,m_Wolf.WOLF_GROW);
		m_Wolf.CreateWolf(new stEMVec2(-40.0f,-40.0f), 15.0f,m_Wolf.WOLF_GROW);
		m_Wolf.CreateWolf(new stEMVec2(-40.0f,0.0f), 15.0f,m_Wolf.WOLF_POWER);
		m_Wolf.CreateWolf(new stEMVec2(-40.0f,40.0f), 15.0f,m_Wolf.WOLF_GROW);


	}
	
	@Override
	public void update(float dt) {
		// TODO Auto-generated method stub
		super.update(dt);
	}
	
	@Override
	public void render(GL10 gl) {
		// TODO Auto-generated method stub
		super.render(gl);
	}
	
	@Override
	public void exit() {
		// TODO Auto-generated method stub
		super.exit();
	}
}
