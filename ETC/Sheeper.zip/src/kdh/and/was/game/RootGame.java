package kdh.and.was.game;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMBBox;
import homi.JEMEngine.EMMath;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.EMVector.stEMVec3;
import homi.JEMEngine.InterFace.EMInput;
import homi.JEMEngine.InterFace.EMInput.stTouchInfo;
import homi.JEMEngine.Scene.Scene;

import java.io.IOException;

import javax.microedition.khronos.opengles.GL10;

import kdh.and.was.activity.HMRenderer;
import kdh.and.was.effect.EffectMNG;
import kdh.and.was.item.ItemMNG;
import kdh.and.was.sheep.Sheep;
import kdh.and.was.show.ShowEat;
import kdh.and.was.show.ShowItemState;
import kdh.and.was.sys.FileMNG;
import kdh.and.was.ui.BackGround;
import kdh.and.was.ui.Finish;
import kdh.and.was.ui.Grow;
import kdh.and.was.ui.Pause;
import kdh.and.was.ui.ReStart;
import kdh.and.was.ui.ReadyGo;
import kdh.and.was.ui.ShowStage;
import kdh.and.was.wolf.WolfMNG;

import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.BodyType;

public class RootGame extends Scene {
	public final int GAME_NONE = 0;
	public final int GAME_PLAY = 1;
	public final int GAME_PAUSE = 2;
	public final int GAME_HELP = 3;
	public final int GAME_WIN = 4;
	public final int GAME_LOSE = 5;

	public FileMNG m_FileMNG;

	public BackGround m_BackGround;

	public ShowStage m_ShowStage;
	public ReadyGo m_ReadyGo;
	public Finish m_Finish;

	public Grow m_GrowButton;
	public Pause m_PauseButton;
	public ReStart m_ReStartButton;

	public Sheep m_Sheep;
	public WolfMNG m_Wolf;
	public EffectMNG m_Effect;
	public ItemMNG m_Item;

	public ShowItemState m_ShowItem;
	public ShowEat m_ShowEat;
	
	public boolean m_MoveButton;

	public int m_GameState;
	public int m_BackGameState;
	public int m_SceneNumber;

	public double m_StartTime;
	public static int m_NowTime;

	public String m_NextScene;

	public void NextScene(String NextScene, int SceneNumber) {
		m_NextScene = NextScene;
		m_SceneNumber = SceneNumber;
	}

	@Override
	public void enter() {

		try {
			EM2DEngine.D_SOUNDMNG.commit("GameBG", "sound/game.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (HMRenderer.m_MusicState == true)
			EM2DEngine.D_SOUNDMNG.play("GameBG", true);

		if (EM2DEngine.D_SOUNDMNG.isPlay("StageBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("StageBG");

		EM2DEngine.D_CAMERA.setPos(new stEMVec3(0.0f, 0.0f, 100.0f));
		// if(EM2DEngine.D_SOUNDMNG.isPause("GameWav") == false)
		// EM2DEngine.D_SOUNDMNG.play("GameWav", true);
		m_FileMNG = new FileMNG();
		int _Tocen = m_FileMNG.FileRead("StageLock.txt");
		if (_Tocen < m_SceneNumber)
			m_FileMNG.FileWrite("StageLock.txt", m_SceneNumber);

		startPhysic(new stEMVec2(0.0f, 0.0f));

		CreateTile(new stEMVec2(0.0f, 55.0f), new stEMVec2(100.0f, 2.0f), 0.0f,
				"Tile01");
		CreateTile(new stEMVec2(0.0f, -55.0f), new stEMVec2(100.0f, 2.0f),
				0.0f, "Tile02");
		CreateTile(new stEMVec2(95.0f, 0.0f), new stEMVec2(100.0f, 2.0f),
				90.0f, "Tile03");
		CreateTile(new stEMVec2(-95.0f, 0.0f), new stEMVec2(100.0f, 2.0f),
				90.0f, "Tile04");
		
		
		HMRenderer.m_BackSceneName = EM2DEngine.D_SCENE.getChangeSceneName();
		
		m_MoveButton = HMRenderer.m_MoveButton;

		ClassEnter();

		m_StartTime = System.currentTimeMillis();
		m_NowTime = 0;

		m_GameState = GAME_NONE;
		m_BackGameState = GAME_NONE;

		super.enter();
	}

	public void ClassEnter() {
		m_BackGround = new BackGround();
		m_BackGround.Enter(this);

		m_ShowStage = new ShowStage();
		m_ShowStage.Enter(this);

		m_ReadyGo = new ReadyGo();
		m_ReadyGo.Enter(this);

		m_Finish = new Finish();
		m_Finish.Enter(this);

		m_GrowButton = new Grow();
		m_GrowButton.Enter(this);

		m_PauseButton = new Pause();
		m_PauseButton.Enter(this);

		m_ReStartButton = new ReStart();
		m_ReStartButton.Enter(this);

		m_Sheep = new Sheep();
		m_Sheep.Enter(this);

		m_Wolf = new WolfMNG();
		m_Wolf.Enter(this);

		m_Effect = new EffectMNG();
		m_Effect.Enter(this);

		m_Item = new ItemMNG();
		m_Item.Enter(this);

		m_ShowItem = new ShowItemState();
		m_ShowItem.Enter(this);
		
		m_ShowEat = new ShowEat();
		m_ShowEat.Enter(this);
		
		if(m_MoveButton == true)
		{
			setControlSize(1.0f);				//<! ��ȿ�� - ȭ���ػ󵵿� ���� ��Ʈ�ѷ� ũ�� ���� ����, Default : 1.0f, Max : 2.0f
			onControlMode(EMInput.E_ONE_BTN);
			m_PauseButton.SetPos(new stEMVec2(230,420.0f));
			m_ReStartButton.SetPos(new stEMVec2(350.0f, 420.0f));
		}
	}

	@Override
	public void update(float dt) {
		switch (m_GameState) {
			case GAME_NONE :
				m_Wolf.OnPause();
				if (m_ShowStage.Finish() == false) {
					m_ShowStage.Update(dt);
				} else if (m_ShowStage.Finish() == true) {
					m_ReadyGo.Go();
					m_ReadyGo.Update(dt);
					if (m_ReadyGo.Finish() == true) {
						m_Wolf.OffPause();
						m_GameState = GAME_PLAY;
						m_BackGameState = m_GameState;
					}
				}
				break;
			case GAME_PLAY :
				m_NowTime = (int) (System.currentTimeMillis() - m_StartTime);

				if (m_MoveButton == false)
					m_Sheep.Update(dt, m_NowTime);
				else {
					ButtonMove();
				}

				m_Wolf.Update(dt);

				m_Effect.Update(dt);

				m_Item.Update(dt);

				m_ShowItem.Update(dt);
				
				m_ShowEat.Update(dt);

				m_Sheep.SetGrowState(!m_GrowButton.GetGrowOnOff());

				WinLoseCheck();

				ItemCheck();

				Battle();
				break;
			case GAME_PAUSE :
				break;
			case GAME_HELP :
				break;
			case GAME_WIN :
				m_Effect.Clear();
				m_Finish.Win(dt);
				break;
			case GAME_LOSE :
				m_Effect.Clear();
				EM2DEngine.D_SCENE.changeSceneFade("GameOver");
				// m_Finish.Lose(dt);
				break;
		}

		super.update(dt);
	}
	
	public void ButtonMove()
	{
		float _MoveX = 0.0f;
		float _MoveY = 0.0f;
		if(m_bCotrolTouchLeft)
		{
			if(m_pControlLeft.getWindowName() == "Control_Left")
			{
				int id = m_pControlLeft.getID();
				switch(id)
				{
				case EMInput.E_BTN_CONTROL:
					float distance = EMMath.dot2Distance(m_pControlLeft.getButton(id).getPos(false), m_pControlLeft.getPos());
					float radian = (float)Math.atan2(
							m_pControlLeft.getButton(id).getPos(false).m_fY - m_pControlLeft.getPos().m_fY,
							m_pControlLeft.getButton(id).getPos(false).m_fX - m_pControlLeft.getPos().m_fX);
					
					_MoveX = (float)Math.cos(radian)*distance;
					_MoveY = -((float)Math.sin(radian)*distance);
					
					break;
				}
			}
		}
		m_Sheep.ButtonUpdate(m_NowTime, _MoveX, _MoveY);
	}

	public void ItemCheck() {
		EMPlane _iPlane = null;
		_iPlane = isCollision(E_SPHERE_VS_BOX, m_Sheep.GetPlane(), 2);
		if (_iPlane != null) {
			int _PlaneType = _iPlane.getType();
			if (_PlaneType == m_Item.ITEM_SIZEDOWN) {
				m_Sheep.NGrow();
				m_Sheep.NGrow();
				m_Sheep.NGrow();
				m_ShowEat.Eat(m_Sheep.GetPlane().getPosVec2(), m_Item.ITEM_SIZEDOWN);
			}
			if (_PlaneType == m_Item.ITEM_UNBEATABLE) {
				m_ShowItem.Show(1, 3000);
				m_Sheep.Unbeatable();
				m_ShowEat.Eat(m_Sheep.GetPlane().getPosVec2(), m_Item.ITEM_UNBEATABLE);
			}
			if(_PlaneType == m_Item.ITEM_SIZEUP) {
				for(int i=0; i<20; i++)
				{
					m_Sheep.Grow();
				}
				m_ShowEat.Eat(m_Sheep.GetPlane().getPosVec2(), m_Item.ITEM_SIZEUP);
			}
			m_Item.Using(_iPlane);
		}
	}

	public void Battle() {
		EMPlane _tPlane = null;
		_tPlane = isCollision(E_SPHERE_VS_SPHERE, m_Sheep.GetPlane(), 4);
		if (_tPlane != null) {
			int _PlaneType = _tPlane.getType();
			if (m_Sheep.GetUnbeatableState() == false) {
				if (m_Sheep.GetGrowState() == true) {
					m_Sheep.Lose();
				} else {
					if (_PlaneType == m_Wolf.WOLF)
						;
					else if (_PlaneType == m_Wolf.WOLF_STAY) {
						m_ShowItem.Show(0, 4000);
						m_Sheep.Poison();
					} else if (_PlaneType == m_Wolf.WOLF_GROW)
						;
					else if (_PlaneType == m_Wolf.WOLF_POWER) {
						m_Sheep.NGrow();
					}
					m_Sheep.NGrow();
				}
			}
			m_Wolf.Fight(_tPlane);
			m_Effect.CreateEffect(m_Sheep.GetPlane().getPosVec2(),
					_tPlane.getPosVec2(), _tPlane.getType(),
					m_Effect.EFFECT_COLLISION);
			if (HMRenderer.m_MusicState == true) {
				if (EM2DEngine.D_SOUNDMNG.isPlay("fight") == false) {
					try {
						EM2DEngine.D_SOUNDMNG
								.commit("fight", "sound/fight.wav");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					EM2DEngine.D_SOUNDMNG.play("fight", false);
				}
			}
			// EM2DEngine.D_SOUNDMNG.play("FightWav", false);
			// if(EM2DEngine.D_SOUNDMNG.isPlay("Fight") == false)
			// EM2DEngine.D_SOUNDMNG.play("Fight", false);
		}
	}

	public void WinLoseCheck() {
		if (m_Wolf.GetWolfAllDieState() == true) {
			m_Sheep.OnPause();
			m_Sheep.Win();
			m_Wolf.OnPause();
			m_Effect.Clear();
			m_GameState = GAME_WIN;
			// EM2DEngine.D_SOUNDMNG.play("WinWav", false);
		}
		if (m_Sheep.GetLifeState() == false) {
			m_Sheep.OnPause();
			m_Wolf.OnPause();
			m_Effect.Clear();
			m_GameState = GAME_LOSE;
			// EM2DEngine.D_SOUNDMNG.play("LoseWav", false);
			// if(EM2DEngine.D_SOUNDMNG.isPlay("Lose") == false)
			// EM2DEngine.D_SOUNDMNG.play("Lose", false);
		}
	}

	@Override
	public void render(GL10 gl) {
		// EM2DEngine.D_CAMERA.setPos(new stEMVec3(0.0f,0.0f,100.0f));

		super.render(gl); // !< ��ȿ�� - �� super �� �� ������ ���ڸ� ����� �� - ���ڿ� ������Ʈ�� ������.
	}

	@Override
	public void exit() {

		if(EM2DEngine.D_SOUNDMNG.isPlay("GameBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("GameBG");
		
		destroy();

		super.exit();
	}
	
	public boolean touchButton(stEMVec2 stPos, EMPlane TouchPlane)
	{
		stEMVec2 min = new stEMVec2(TouchPlane.getBoundingBox().stLB.m_fX, 
				TouchPlane.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(TouchPlane.getBoundingBox().stRT.m_fX, 
				TouchPlane.getBoundingBox().stRT.m_fY);
		
		EMBBox box = new EMBBox(min, max);
		boolean touchReset = box.contains(new EMVector.stEMVec2(stPos.m_fX, stPos.m_fY));
		
		return touchReset;
	}

	@Override
	public void touchDownEvent(stTouchInfo stPos) {
		// TODO Auto-generated method stub

		stEMVec2 _stPos = new stEMVec2(stPos.m_fX,stPos.m_fY);
		if(touchButton(_stPos,m_GrowButton.m_GrowButton[0]) == true)
		{
			m_GrowButton.Click();
		}
		if(touchButton(_stPos,m_PauseButton.m_PauseButton) == true)
		{
			m_PauseButton.PauseClick();
		}
		if(touchButton(_stPos,m_PauseButton.m_PauseToGameButton) == true)
		{
			if(m_PauseButton.m_PauseToGameButton.getShow() == true)
				m_PauseButton.PauseToGameClick();
		}
		if(touchButton(_stPos,m_PauseButton.m_PauseToMenuButton) == true)
		{
			if(m_PauseButton.m_PauseToMenuButton.getShow() == true)
				m_PauseButton.PauseToMenuClick();
		}
		if(touchButton(_stPos,m_ReStartButton.m_ReStartButton) == true)
		{
			m_ReStartButton.ReStartClick();
		}
		if(touchButton(_stPos,m_Finish.m_NextGameButton) == true)
		{
			if(m_Finish.m_NextGameButton.getShow() == true)
				m_Finish.NextGameClick();
		}
		
//		EMPlane _Plane = null;
//		_Plane = AABBvsRay(stPos.m_fX, stPos.m_fY, 0);
//		if (_Plane != null) {
//			if (_Plane.getName() == "GrowButton") {
//				m_GrowButton.Click();
//			}
//			if (_Plane.getName() == "NextGameButton") {
//				m_Finish.NextGameClick();
//				// EM2DEngine.D_SCENE.changeSceneFade(m_NextScene);
//			}
//			if (_Plane.getName() == "PauseButton") {
//				m_PauseButton.PauseClick();
//				/*
//				 * m_Sheep.OnPause(); m_Wolf.OnPause(); m_PauseButton.OnPause();
//				 * m_GameState = GAME_PAUSE;
//				 */
//			}
//			if (_Plane.getName() == "PauseToGameButton") {
//				m_PauseButton.PauseToGameClick();
//				/*
//				 * m_Wolf.OffPause(); m_PauseButton.OffPause(); m_GameState =
//				 * GAME_PLAY;
//				 */
//			}
//			if (_Plane.getName() == "PauseToMenuButton") {
//				m_PauseButton.PauseToMenuClick();
//				// EM2DEngine.D_SCENE.changeSceneFade("GameMenu");
//			}
//			if (_Plane.getName() == "ReStartButton") {
//				m_ReStartButton.ReStartClick();
//				// EM2DEngine.D_SCENE.changeSceneFade(EM2DEngine.D_SCENE.getChangeSceneName());
//			}
//		}

		super.touchDownEvent(stPos);
	}

	@Override
	public void touchUpEvent(stTouchInfo stPos, int pointerIndex) {
		// TODO Auto-generated method stub

		if (m_Finish.NextGameNClick() == true) {
			EM2DEngine.D_SCENE.changeSceneFade(m_NextScene);
		}
		if (m_PauseButton.PauseNClick() == true) {
			m_Sheep.OnPause();
			m_Wolf.OnPause();
			m_PauseButton.OnPause();
			m_GameState = GAME_PAUSE;
		}
		if (m_PauseButton.PauseToGameNClick() == true) {
			m_PauseButton.OffPause();
			m_Wolf.OffPause();
			m_GameState = m_BackGameState;
		}
		if (m_PauseButton.PauseToMenuNClick() == true) {
			m_PauseButton.OffPause();
			EM2DEngine.D_SCENE.changeSceneFade("GameMenu");
		}
		if (m_ReStartButton.ReStartNClick() == true) {
			EM2DEngine.D_SCENE.changeSceneFade(EM2DEngine.D_SCENE
					.getChangeSceneName());
		}

		m_GrowButton.NClick();

		/*
		 * EMPlane _Plane = null; _Plane = AABBvsRay(stPos.m_fX,stPos.m_fY, 0);
		 * if(_Plane != null) { if(_Plane.getName() == "ReGameButton") {
		 * EM2DEngine
		 * .D_SCENE.changeSceneFade(EM2DEngine.D_SCENE.getChangeSceneName()); }
		 * if(_Plane.getName() == "NextGameButton") {
		 * EM2DEngine.D_SCENE.changeSceneFade(m_NextScene); }
		 * if(_Plane.getName() == "PauseButton") { m_PauseButton.NClick();
		 * m_Sheep.OnPause(); m_Wolf.OnPause(); m_PauseButton.OnPause();
		 * m_GameState = GAME_PAUSE; } if(_Plane.getName() == "PauseToGame") {
		 * m_Wolf.OffPause(); m_PauseButton.OffPause(); m_GameState = GAME_PLAY;
		 * } if(_Plane.getName() == "PauseToMenu") {
		 * EM2DEngine.D_SCENE.changeSceneFade("GameMenu"); } if(_Plane.getName()
		 * == "ReStartButton") {
		 * EM2DEngine.D_SCENE.changeSceneFade(EM2DEngine.D_SCENE
		 * .getChangeSceneName()); } }
		 */

		// m_PauseButton.OffPause();

		super.touchUpEvent(stPos, pointerIndex);
	}

	public void CreateTile(stEMVec2 stPos, stEMVec2 stSize, float fZRot,
			String ComName) {
		BodyDef _bDef;
		Body _Body;
		PolygonShape _Shape;

		EMPlane _Tile;

		_bDef = new BodyDef();
		_bDef.type = BodyType.STATIC;
		_bDef.position = new Vec2(stPos.m_fX, stPos.m_fY);

		_Body = getWorldPt().createBody(_bDef);

		_Shape = new PolygonShape();
		_Shape.setAsBox(stSize.m_fX, stSize.m_fY);
		_Body.createFixture(_Shape, 1.0f);

		_Tile = new EMPlane();
		_Tile.setTexture(this, "image/sheep/sheep.png");
		_Tile.setFrustumCulling(false);
		_Tile.setBlend(true);
		_Tile.setType(0);
		_Tile.setZRot(fZRot);
		_Tile.setShow(false);
		_Tile.connectBody(_Body);

		commit(9, ComName, _Tile);
	}

}
