package kdh.and.was.game;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMBBox;
import homi.JEMEngine.EMColor;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMText;
import homi.JEMEngine.EMVector;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.EMVector.stEMVec3;
import homi.JEMEngine.InterFace.EMInput.stTouchInfo;
import homi.JEMEngine.Scene.Scene;

import java.io.IOException;

import javax.microedition.khronos.opengles.GL10;

import kdh.and.was.activity.HMRenderer;
import kdh.and.was.effect.EffectMNG;
import kdh.and.was.item.ItemMNG;
import kdh.and.was.sheep.Sheep;
import kdh.and.was.show.ShowEat;
import kdh.and.was.show.ShowItemState;
import kdh.and.was.ui.BackGround;
import kdh.and.was.ui.Grow;
import kdh.and.was.wolf.WolfMNG;

import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.BodyType;

public class TutorGame extends Scene
{		
	public final int 				TUTOR_MOVE = 1;
	public final int 				TUTOR_GROW_TEST = 2;
	public final int 				TUTOR_GROW = 3;
	public final int 				TUTOR_ITEM_SIZEDOWN = 4;
	public final int 				TUTOR_ITEM_SIZEUP = 5;
	public final int				TUTOR_ITEM_UNBEATABLE = 6;
	public final int 				TUTOR_ITEM_UNBEATABLE_EX = 7;
	public final int 				TUTOR_ATTACK_WOLF_READY = 8;
	public final int 				TUTOR_ATTACK_WOLF = 9;
	public final int 				TUTOR_ATTACK_WOLF_STAY_READY = 10;
	public final int 				TUTOR_ATTACK_WOLF_STAY = 11;
	public final int 				TUTOR_ATTACK_WOLF_GROW_READY = 112;
	public final int 				TUTOR_ATTACK_WOLF_GROW = 13;
	public final int 				TUTOR_ATTACK_WOLF_POWER_READY = 14;
	public final int 				TUTOR_ATTACK_WOLF_POWER = 15;
	
	public int 						m_TutorStage;
	
	public EMText					m_TutorExplain;
	
	public BackGround			m_BackGround;
	
	public Grow					m_GrowButton;
	
	public Sheep				m_Sheep;
	public WolfMNG				m_Wolf;
	public EffectMNG			m_Effect;
	public ItemMNG				m_Item;
	
	public ShowItemState m_ShowItem;
	public ShowEat m_ShowEat;
	
	public double				m_StartTime;
	public static int			m_NowTime;
	
	public int 					m_Tutor_Move_Time;
	public int 					m_Tutor_Grow_Test_Time;
	public int 					m_Tutor_Grow_Time;
	public int 					m_Tutor_Unbeatable_Time;
	public int 					m_Tutor_Attack_Wolf_Ready_Time;
	public int 					m_Tutor_Attack_Wolf_Stay_Ready_Time;
	public int 					m_Tutor_Attack_Wolf_Grow_Ready_Time;
	public int 					m_Tutor_Attack_Wolf_Power_Ready_Time;
	
	@Override
	public void enter()
	{	
			try {
				EM2DEngine.D_SOUNDMNG.commit("GameBG", "sound/game.wav");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(HMRenderer.m_MusicState == true)
				EM2DEngine.D_SOUNDMNG.play("GameBG", true);
		
		if(EM2DEngine.D_SOUNDMNG.isPlay("MenuBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("MenuBG");
		
		EM2DEngine.D_CAMERA.setPos(new stEMVec3(0.0f,0.0f,100.0f));
		
		startPhysic(new stEMVec2(0.0f,0.0f));
		
		CreateTile(new stEMVec2(0.0f,55.0f), new stEMVec2(100.0f,2.0f), 0.0f, "Tile01");
		CreateTile(new stEMVec2(0.0f,-55.0f), new stEMVec2(100.0f,2.0f), 0.0f, "Tile02");
		CreateTile(new stEMVec2(95.0f,0.0f), new stEMVec2(100.0f,2.0f), 90.0f, "Tile03");
		CreateTile(new stEMVec2(-95.0f,0.0f), new stEMVec2(100.0f,2.0f), 90.0f, "Tile04");
		
		ClassEnter();

		m_StartTime = System.currentTimeMillis();
		m_NowTime = 0;
		
		m_Tutor_Move_Time = 5000;
		m_Tutor_Grow_Test_Time = 5000;
		m_Tutor_Grow_Time = 10000;
		m_Tutor_Unbeatable_Time = 0;
		m_Tutor_Attack_Wolf_Ready_Time = 0;
		m_Tutor_Attack_Wolf_Stay_Ready_Time = 0;
		m_Tutor_Attack_Wolf_Grow_Ready_Time = 0;
		m_Tutor_Attack_Wolf_Power_Ready_Time = 0;
		
		m_TutorStage = TUTOR_MOVE;
		
		m_Sheep.CreateSheep(new stEMVec2(0.0f,0.0f), 15.0f);
		
		super.enter();
	}
	
	public void ClassEnter()
	{
		m_TutorExplain = new EMText("chungbinM.ttf", "û��Mü ��¿�");			
		m_TutorExplain.setColor(new EMColor(0, 0, 0, 255));			//!< ���� r,g,b,a
		m_TutorExplain.setPos(50.0f, 50.0f);								//!< �����ġ x,y
		m_TutorExplain.setSize(1.5f);										//!< �⺻ ������� 20�� ����� ����
		commit(0, "ToturExplain", m_TutorExplain);
		m_TutorExplain.setOutPutString("������￩ ĳ���͸� �����ϼ� �ֽ��ϴ�.");
		
		m_BackGround = new BackGround();
		m_BackGround.Enter(this);

		m_GrowButton = new Grow();
		m_GrowButton.Enter(this);

		m_Sheep = new Sheep();
		m_Sheep.Enter(this);
		
		m_Wolf = new WolfMNG();
		m_Wolf.Enter(this);
		
		m_Effect = new EffectMNG();
		m_Effect.Enter(this);
		
		m_Item = new ItemMNG();
		m_Item.Enter(this);
		
		m_ShowItem = new ShowItemState();
		m_ShowItem.Enter(this);
		
		m_ShowEat = new ShowEat();
		m_ShowEat.Enter(this);
	}

	@Override
	public void update(float dt) 
	{		
		m_NowTime = (int)(System.currentTimeMillis() - m_StartTime);	

		m_ShowEat.Update(dt);
		
		switch(m_TutorStage)
		{
		case TUTOR_MOVE:
			m_Sheep.Update(dt,m_NowTime);
			if(m_NowTime > m_Tutor_Move_Time)
			{
				//m_Tutor_Grow_Test_Time = m_NowTime + 5000;
				m_TutorExplain.setOutPutString("�׷ο��ư�� ���� ĳ���� ������ ������ֽ��ϴ�.");
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_TutorStage = TUTOR_GROW_TEST;
			}
			break;
		case TUTOR_GROW_TEST:
			m_Sheep.Update(dt, m_NowTime);
			m_Sheep.SetGrowState(!m_GrowButton.GetGrowOnOff());
			
			if(m_NowTime > m_Tutor_Grow_Test_Time)
			{
				m_TutorExplain.setOutPutString("�׷ο��ư�� ���� ĳ���� ������ ������ֽ��ϴ�.");
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_Item.CreateItem(m_Item.ITEM_SIZEDOWN);
				m_Item.m_ItemList.get(1).m_Item.setShow(false);
				m_TutorStage = TUTOR_GROW;
			}
			break;
		case TUTOR_GROW:
			m_Sheep.Update(dt,m_NowTime);
			m_Sheep.SetGrowState(!m_GrowButton.GetGrowOnOff());

			if(m_NowTime > m_Tutor_Grow_Time)
			{
				m_TutorExplain.setOutPutString("������������ ������ ĳ������ ũ�Ⱑ �پ��ϴ�.");
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_Item.CreateItem(m_Item.ITEM_SIZEDOWN);
				m_TutorStage = TUTOR_ITEM_SIZEDOWN;
			}
			break;
		case TUTOR_ITEM_SIZEDOWN:
			m_Sheep.Update(dt,m_NowTime);
			ItemCheck();
			break;
		case TUTOR_ITEM_SIZEUP:
			m_Sheep.Update(dt, m_NowTime);
			ItemCheck();
			break;
		case TUTOR_ITEM_UNBEATABLE:
			m_Sheep.Update(dt,m_NowTime);
			ItemCheck();
			break;
		case TUTOR_ITEM_UNBEATABLE_EX:
			m_Sheep.Update(dt, m_NowTime);
			m_Sheep.GetPlane().setPos(-40.0f,0.0f);
			m_ShowItem.Update(dt);
			if(m_NowTime > m_Tutor_Unbeatable_Time)
			{
				m_TutorExplain.setOutPutString("ĳ���Ͱ� �ڶ�� ���߿� �����ϰ� ������ ���� �����˴ϴ�.");
				m_Wolf.CreateWolf(new stEMVec2(40.0f,0.0f), 15.0f, m_Wolf.WOLF);
				m_Wolf.OnPause();
				m_Sheep.OnPause();
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_Tutor_Attack_Wolf_Ready_Time = m_NowTime + 5000;
				m_TutorStage = TUTOR_ATTACK_WOLF_READY;
			}
			break;
		case TUTOR_ATTACK_WOLF_READY:
			m_Sheep.Update(dt,m_NowTime);
			m_Sheep.OnPause();
			m_Effect.Clear();
//			m_Effect.Update(dt);
			if(m_NowTime > m_Tutor_Attack_Wolf_Ready_Time)
			{
				m_TutorExplain.setOutPutString("����� ������ �̰ܺ�����.");
				m_Wolf.OffPause();
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_TutorStage = TUTOR_ATTACK_WOLF;
			}
			break;
		case TUTOR_ATTACK_WOLF:
			m_Sheep.Update(dt,m_NowTime);
			m_Sheep.SetGrowState(!m_GrowButton.GetGrowOnOff());
			m_Wolf.Update(dt);
			
			m_Effect.Update(dt);
			
			WinLoseCheck();
			
			Battle();
			break;
		case TUTOR_ATTACK_WOLF_STAY_READY:
			m_Sheep.Update(dt,m_NowTime);
			m_Sheep.OnPause();
			m_Effect.Clear();
			m_ShowItem.Update(dt);
			if(m_NowTime > m_Tutor_Attack_Wolf_Stay_Ready_Time)
			{
				m_TutorExplain.setOutPutString("����� ������ �̰ܺ�����.");
				m_Wolf.OffPause();
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_TutorStage = TUTOR_ATTACK_WOLF_STAY;
			}
			break;
		case TUTOR_ATTACK_WOLF_STAY:
			m_Sheep.Update(dt,m_NowTime);
			m_Sheep.SetGrowState(!m_GrowButton.GetGrowOnOff());
			m_Wolf.Update(dt);
			
			m_ShowItem.Update(dt);
			
			m_Effect.Update(dt);
			
			WinLoseCheck();
			
			Battle();
			break;
		case TUTOR_ATTACK_WOLF_GROW_READY:
			m_Sheep.Update(dt,m_NowTime);
			m_Sheep.OnPause();
			m_Effect.Clear();
			m_ShowItem.Update(dt);
			if(m_NowTime > m_Tutor_Attack_Wolf_Grow_Ready_Time)
			{
				m_TutorExplain.setOutPutString("����� ������ �̰ܺ�����.");
				m_Wolf.OffPause();
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_TutorStage = TUTOR_ATTACK_WOLF_GROW;
			}
			break;
		case TUTOR_ATTACK_WOLF_GROW:
			m_Sheep.Update(dt,m_NowTime);
			m_Sheep.SetGrowState(!m_GrowButton.GetGrowOnOff());
			m_Wolf.Update(dt);
			
			m_Effect.Update(dt);
			
			WinLoseCheck();
			
			Battle();
			break;
		case TUTOR_ATTACK_WOLF_POWER_READY:
			m_Sheep.Update(dt,m_NowTime);
			m_Sheep.OnPause();
			m_Effect.Clear();
			if(m_NowTime > m_Tutor_Attack_Wolf_Power_Ready_Time)
			{
				m_TutorExplain.setOutPutString("����� ������ �̰ܺ�����.");
				m_Wolf.OffPause();
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_TutorStage = TUTOR_ATTACK_WOLF_POWER;
			}
			break;
		case TUTOR_ATTACK_WOLF_POWER:
			m_Sheep.Update(dt,m_NowTime);
			m_Sheep.SetGrowState(!m_GrowButton.GetGrowOnOff());
			m_Wolf.Update(dt);
			
			m_Effect.Update(dt);
			
			WinLoseCheck();
			
			Battle();
			break;
		}				
		super.update(dt);
	}
	
	public void ItemCheck()
	{
		EMPlane _iPlane = null;
		_iPlane = isCollision(E_SPHERE_VS_BOX, m_Sheep.GetPlane(), 2);
		if(_iPlane != null)
		{
			int _PlaneType = _iPlane.getType();
			if(_PlaneType == m_Item.ITEM_SIZEDOWN)
			{
				m_Sheep.NGrow();
				m_Sheep.NGrow();
				m_Sheep.NGrow();
				m_Sheep.NGrow();
				m_Sheep.NGrow();
				m_Sheep.NGrow();
				m_TutorExplain.setOutPutString("���������� ������ ĳ������ ũ�Ⱑ Ŀ���ϴ�.");
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_Item.CreateItem(m_Item.ITEM_SIZEUP);
				m_ShowEat.Eat(m_Sheep.GetPlane().getPosVec2(), m_Item.ITEM_SIZEDOWN);
				m_TutorStage = TUTOR_ITEM_SIZEUP;
			}
			if(_PlaneType == m_Item.ITEM_UNBEATABLE)
			{
				m_Sheep.Unbeatable();
				m_ShowItem.Show(1, 3000);
				m_TutorExplain.setOutPutString("      ĳ������ ���°� ������ܿ� ǥ�õ˴ϴ�.");
				m_Sheep.OnPause();
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_Tutor_Unbeatable_Time = m_NowTime + 5000;
				m_ShowEat.Eat(m_Sheep.GetPlane().getPosVec2(), m_Item.ITEM_UNBEATABLE);
				m_TutorStage = TUTOR_ITEM_UNBEATABLE_EX;
			}
			if(_PlaneType == m_Item.ITEM_SIZEUP) {
				for(int i=0; i<20; i++)
				{
					m_Sheep.Grow();
				}
				
				m_TutorExplain.setOutPutString("���Ǿ������� ������ ĳ���Ͱ� �����ð� ������ �˴ϴ�.");
				m_Sheep.GetPlane().setPos(-40.0f,0.0f);
				m_ShowEat.Eat(m_Sheep.GetPlane().getPosVec2(), m_Item.ITEM_SIZEUP);
				m_Item.CreateItem(m_Item.ITEM_UNBEATABLE);
				m_TutorStage = TUTOR_ITEM_UNBEATABLE;
			}
			m_Item.Using(_iPlane);
		}
	}
	
	public void Battle()
	{
		EMPlane _tPlane = null;
		_tPlane = isCollision(E_SPHERE_VS_SPHERE, m_Sheep.GetPlane(), 4);
		if(_tPlane != null)
		{
			int _PlaneType = _tPlane.getType();
			if(m_Sheep.GetUnbeatableState() == false)
			{
				if(m_Sheep.GetGrowState() == true)
				{
					//m_Sheep.Lose();
				}
				else
				{
					if(_PlaneType == m_Wolf.WOLF) ;
					else if(_PlaneType == m_Wolf.WOLF_STAY)
					{
						m_Sheep.Poison();
						m_ShowItem.Show(0, 4000);
					}
					else if(_PlaneType == m_Wolf.WOLF_GROW) ;
					else if(_PlaneType == m_Wolf.WOLF_POWER)
					{
						m_Sheep.NGrow();
					}
					m_Sheep.NGrow();
				}
			}
			m_Wolf.Fight(_tPlane);
			m_Effect.CreateEffect(m_Sheep.GetPlane().getPosVec2(),
					_tPlane.getPosVec2(),	_tPlane.getType(), m_Effect.EFFECT_COLLISION);
			if (HMRenderer.m_MusicState == true) {
				if (EM2DEngine.D_SOUNDMNG.isPlay("fight") == false) {
					try {
						EM2DEngine.D_SOUNDMNG
								.commit("fight", "sound/fight.wav");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					EM2DEngine.D_SOUNDMNG.play("fight", false);
				}
			}
			//EM2DEngine.D_SOUNDMNG.play("FightWav", false);
			//if(EM2DEngine.D_SOUNDMNG.isPlay("Fight") == false)
				//EM2DEngine.D_SOUNDMNG.play("Fight", false);
		}
	}
	
	public void WinLoseCheck()
	{
		if(m_Wolf.GetWolfAllDieState() == true)
		{
			switch(m_TutorStage)
			{
				case TUTOR_ATTACK_WOLF:
					m_TutorExplain.setOutPutString("������� ���� �����ߵ��� ���������� ũ�Ⱑ �پ��ϴ�.");
					m_Sheep.GetPlane().setPos(-40.0f,0.0f);
					m_Effect.Clear();
					m_Sheep.OnPause();
					m_Wolf.CreateWolf(new stEMVec2(40.0f,0.0f), 15.0f, m_Wolf.WOLF_STAY);
					m_Wolf.OnPause();
					m_Wolf.SetWolfAllDieState();
					m_Tutor_Attack_Wolf_Stay_Ready_Time = m_NowTime + 5000;
					m_TutorStage = TUTOR_ATTACK_WOLF_STAY_READY;
					break;
				case TUTOR_ATTACK_WOLF_STAY:
					m_TutorExplain.setOutPutString("���� �ð����� ũ�Ⱑ Ŀ���� �����Դϴ�.");
					m_Sheep.GetPlane().setPos(-40.0f,0.0f);
					m_Wolf.CreateWolf(new stEMVec2(40.0f,0.0f), 15.0f, m_Wolf.WOLF_GROW);
					m_Wolf.OnPause();
					m_Effect.Clear();
					m_Sheep.OnPause();
					m_Wolf.SetWolfAllDieState();
					m_Tutor_Attack_Wolf_Grow_Ready_Time = m_NowTime + 5000;
					m_TutorStage = TUTOR_ATTACK_WOLF_GROW_READY;
					break;
				case TUTOR_ATTACK_WOLF_GROW:
					m_TutorExplain.setOutPutString("�ٸ� ���뺸�� ���� ���� ������� �� ���� ũ�Ⱑ �پ��ϴ�.");
					m_Sheep.GetPlane().setPos(-40.0f,0.0f);
					m_Wolf.CreateWolf(new stEMVec2(40.0f,0.0f), 15.0f, m_Wolf.WOLF_POWER);
					m_Wolf.OnPause();
					m_Effect.Clear();
					m_Sheep.OnPause();
					m_Wolf.SetWolfAllDieState();
					m_Tutor_Attack_Wolf_Power_Ready_Time = m_NowTime + 5000;
					m_TutorStage = TUTOR_ATTACK_WOLF_POWER_READY;
					break;
				case TUTOR_ATTACK_WOLF_POWER:
					EM2DEngine.D_SCENE.changeSceneFade("GameMenu");
					break;
			}
			//EM2DEngine.D_SOUNDMNG.play("WinWav", false);
		}
		if(m_Sheep.GetLifeState() == false)
		{
			m_Sheep.OnPause();
			m_Wolf.OnPause();
			m_Effect.Clear();
			EM2DEngine.D_SCENE.changeSceneFade("GameMenu");
			//EM2DEngine.D_SOUNDMNG.play("LoseWav", false);
			//if(EM2DEngine.D_SOUNDMNG.isPlay("Lose") == false)
				//EM2DEngine.D_SOUNDMNG.play("Lose", false);
		}
	}

	@Override
	public void render(GL10 gl) 
	{
		//EM2DEngine.D_CAMERA.setPos(new stEMVec3(0.0f,0.0f,100.0f));
		
		super.render(gl);		//!< ��ȿ�� - �� super �� �� ������ ���ڸ� ����� �� - ���ڿ� ������Ʈ�� ������.
	}

	@Override
	public void exit() 
	{
		if(EM2DEngine.D_SOUNDMNG.isPlay("GameBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("GameBG");
		
		destroy();
		
		super.exit();
	}
	
	public boolean touchButton(stEMVec2 stPos, EMPlane TouchPlane)
	{
		stEMVec2 min = new stEMVec2(TouchPlane.getBoundingBox().stLB.m_fX, 
				TouchPlane.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(TouchPlane.getBoundingBox().stRT.m_fX, 
				TouchPlane.getBoundingBox().stRT.m_fY);
		
		EMBBox box = new EMBBox(min, max);
		boolean touchReset = box.contains(new EMVector.stEMVec2(stPos.m_fX, stPos.m_fY));
		
		return touchReset;
	}
	
	@Override
	public void touchDownEvent(stTouchInfo stPos) {
		// TODO Auto-generated method stub
		
		stEMVec2 _stPos = new stEMVec2(stPos.m_fX,stPos.m_fY);
		if(touchButton(_stPos,m_GrowButton.m_GrowButton[0]) == true)
		{
			m_GrowButton.Click();
		}

		super.touchDownEvent(stPos);
	}
	
	@Override
	public void touchUpEvent(stTouchInfo stPos, int pointerIndex) {
		// TODO Auto-generated method stub
		
		m_GrowButton.NClick();

		super.touchUpEvent(stPos, pointerIndex);
	}
	
	public void CreateTile(stEMVec2 stPos, stEMVec2 stSize, float fZRot, String ComName)
	{
		BodyDef _bDef;
		Body _Body;
		PolygonShape _Shape;
		
		EMPlane _Tile;
		
		_bDef = new BodyDef();
		_bDef.type = BodyType.STATIC;
		_bDef.position = new Vec2(stPos.m_fX,stPos.m_fY);
		
		_Body = getWorldPt().createBody(_bDef);
		
		_Shape = new PolygonShape();
		_Shape.setAsBox(stSize.m_fX,stSize.m_fY);
		_Body.createFixture(_Shape,1.0f);
		
		_Tile = new EMPlane();
		_Tile.setTexture(this, "image/sheep/sheep.png");
		_Tile.setFrustumCulling(false);
		_Tile.setBlend(true);
		_Tile.setType(0);
		_Tile.setZRot(fZRot);
		_Tile.setShow(false);
		_Tile.connectBody(_Body);
		
		commit(9,ComName, _Tile);
	}
	
}
