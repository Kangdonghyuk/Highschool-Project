package kdh.and.was.sys;

import homi.JEMEngine.EM2DEngine;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

//enum FILETYPE{
//	E_FILE_TOCEN,
//	E_FILE_ARRARY,
//}

//class File{
//	public String m_FileName;
//	public FILETYPE m_FileType;
//	
//	public void OnFile(String FileName, FILETYPE FileType)
//	{
//		m_FileName = FileName;
//		m_FileType = FileType;
//	}
//}

public class FileMNG{
	
//	public ArrayList<File> m_File;
//	
//	public void NewFile()
//	{
//		m_File = new ArrayList<File>();
//	}
//	
//	public void FileEnter(String FileName, FILETYPE FileType)
//	{
//		File _File = new File();
//		_File.OnFile(FileName, FileType);
//		
//		m_File.add(_File);
//	}
	
	public int[] FileArrayRead(String FileName,int FileMax)
	{
		int _Tocen[] = new int[FileMax];
		for(int i=0; i<FileMax; i++)
			_Tocen[i] = 0;
		
		FileInputStream fis;
		
		try {	
			int _Index = 0;
			fis = EM2DEngine.getContext().openFileInput(FileName);
			while((_Tocen[_Index++] = fis.read()) != -1) {}
			fis.close();
		} catch(FileNotFoundException e) {
			FileArrayWrite(FileName,_Tocen,FileMax);
		} catch(Exception e) {
			return _Tocen;
		}
		
		return _Tocen;
	}

	public int FileRead(String FileName)
	{
		int Tocen = 1;
		
		FileInputStream fis;
		
		try {
			fis = EM2DEngine.getContext().openFileInput(FileName);
			Tocen = fis.read();
			fis.close();
			if(Tocen == 0)
				Tocen = 1;
		} catch(FileNotFoundException e) {
			FileWrite(FileName,1);
		} catch(Exception e) {
			return 1;
		}
		
		return Tocen;
	}

	public void FileArrayWrite(String FileName, int[] Tocen, int FileMax)
	{
		FileOutputStream fos;
		try {
			int _Index = 0;
			fos = EM2DEngine.getContext().openFileOutput(FileName, EM2DEngine.getContext().MODE_PRIVATE);
			for(; _Index < FileMax; _Index++)
			{
				fos.write(Tocen[_Index]);
			}
//			fos.write(Tocen);
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void FileWrite(String FileName, int Tocen)
	{
		 FileOutputStream fos;
		try {
			fos = EM2DEngine.getContext().openFileOutput(FileName, EM2DEngine.getContext().MODE_PRIVATE);
			fos.write(Tocen);
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
