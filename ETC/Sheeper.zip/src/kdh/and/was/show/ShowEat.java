package kdh.and.was.show;

import java.util.ArrayList;

import kdh.and.was.item.ItemMNG;

import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

class EatItem
{
	public EMPlane m_EatItem;
	void Create(Scene scene,stEMVec2 stPos, int ItemType, int ID)
	{
		m_EatItem = new EMPlane();
		if(ItemType == ItemMNG.ITEM_SIZEDOWN)
			m_EatItem.setTexture(scene, "image/item/size_down.png");
		else if(ItemType == ItemMNG.ITEM_SIZEUP)
			m_EatItem.setTexture(scene, "image/item/size_up.png");
		else if(ItemType == ItemMNG.ITEM_UNBEATABLE)
			m_EatItem.setTexture(scene, "image/item/unbeatable.png");
		m_EatItem.setPos(stPos.m_fX, stPos.m_fY + 10);
		if(ItemType == ItemMNG.ITEM_SIZEDOWN)
			m_EatItem.setSize(0.08f,0.08f);
		else
			m_EatItem.setSize(0.15f,0.15f);
		m_EatItem.setFrustumCulling(false);
		m_EatItem.setBlend(true);
		m_EatItem.setType(0);
		m_EatItem.setShow(true);
		
		scene.commit(0,ID,"EatItem", m_EatItem);
	}
	
	void Update(float dt)
	{
		m_EatItem.moveY(50.0f*dt);
		m_EatItem.setAlpha(m_EatItem.getAlpha() - 0.06f);
		
		if(m_EatItem.getAlpha() <= 0.1f)
		{
			m_EatItem.setShow(false);
		}
	}
}

public class ShowEat {
	
	public Scene m_NowScene;
	
	public ArrayList<EatItem> m_EatItem;
	
	public int m_ID;

	public void Enter(Scene scene)
	{
		m_NowScene = scene;
		
		m_EatItem = new ArrayList<EatItem>();
		
		m_ID = 0;
	}
	
	public void Update(float dt)
	{
		for(int i=0; i<m_EatItem.size(); i++)
		{
			m_EatItem.get(i).Update(dt);
			if(m_EatItem.get(i).m_EatItem.getShow() == false)
			{
				m_EatItem.remove(i);
			}
		}
	}
	
	public void Eat(stEMVec2 stPos, int ItemType)
	{
		EatItem _EatItem = new EatItem();
		_EatItem.Create(m_NowScene,stPos, ItemType, m_ID++);
		
		m_EatItem.add(_EatItem);
	}
}
