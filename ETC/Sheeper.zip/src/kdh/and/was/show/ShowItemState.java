package kdh.and.was.show;

import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class ShowItemState {
	
	public static final int ITEM_POISON = 0;
	public static final int ITEM_UNBEATABLE = 1;
	
	public ShowItem[] m_ShowItem;

	public void Enter(Scene scene)
	{
		m_ShowItem = new ShowItem[2];
		m_ShowItem[ITEM_POISON] = new ShowItem();
		m_ShowItem[ITEM_UNBEATABLE] = new ShowItem();
		
		m_ShowItem[ITEM_POISON].Enter(scene, ITEM_POISON);
		m_ShowItem[ITEM_UNBEATABLE].Enter(scene, ITEM_UNBEATABLE);
	}
	
	public void Update(float dt)
	{
		m_ShowItem[ITEM_POISON].Update(dt);
		m_ShowItem[ITEM_UNBEATABLE].Update(dt);
	}
	
	public void Show(int ItemType, int ItemTime)
	{
		if(ItemType == ITEM_POISON)
		{
			if(m_ShowItem[ITEM_POISON].GetShowState() == true)
			{
				m_ShowItem[ITEM_POISON].Show(m_ShowItem[ITEM_POISON].m_Item.getPosVec2(), ItemTime);
			}
			else
			{
				if(m_ShowItem[ITEM_UNBEATABLE].GetShowState() == true)
				{
					if(m_ShowItem[ITEM_UNBEATABLE].m_Item.getPosVec2().m_fX == -80)
					{
						m_ShowItem[ITEM_POISON].Show(new stEMVec2(-60.0f,50.0f), ItemTime);
					}
					else
						m_ShowItem[ITEM_POISON].Show(new stEMVec2(-80.0f,50.0f), ItemTime);
				}
				else
					m_ShowItem[ITEM_POISON].Show(new stEMVec2(-80.0f,50.0f), ItemTime);
			}
		}
		else if(ItemType == ITEM_UNBEATABLE)
		{
			if(m_ShowItem[ITEM_UNBEATABLE].GetShowState() == true)
			{
				m_ShowItem[ITEM_UNBEATABLE].Show(m_ShowItem[ITEM_UNBEATABLE].m_Item.getPosVec2(), ItemTime);
			}
			else
			{
				if(m_ShowItem[ITEM_POISON].GetShowState() == true)
				{
					if(m_ShowItem[ITEM_POISON].m_Item.getPosVec2().m_fX == -80)
					{
						m_ShowItem[ITEM_UNBEATABLE].Show(new stEMVec2(-60.0f,50.0f), ItemTime);
					}
					else
						m_ShowItem[ITEM_UNBEATABLE].Show(new stEMVec2(-80.0f,50.0f), ItemTime);
				}
				else
					m_ShowItem[ITEM_UNBEATABLE].Show(new stEMVec2(-80.0f,50.0f), ItemTime);
			}
		}
	}
	
}
