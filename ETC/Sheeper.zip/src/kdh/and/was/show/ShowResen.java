package kdh.and.was.show;

import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class ShowResen {

	public EMPlane m_Resen;
	
	public boolean m_ResenReady;
	public boolean m_ResenState;
	
	public int m_ResenPosCount;
	
	public int m_ResenTime;
	
	public void Enter(Scene scene)
	{
		m_Resen = new EMPlane();
		m_Resen.setTexture(scene, "image/button/grow.png");
		m_Resen.setPos(0.0f,0.0f);
		m_Resen.setSize(0.2f,0.2f);
		m_Resen.setFrustumCulling(false);
		m_Resen.setBlend(true);
		m_Resen.setType(0);
		m_Resen.setShow(false);
		
		scene.commit(0,"Resen", m_Resen);
		
		m_ResenReady = false;
		m_ResenState = false;
		
		m_ResenPosCount = 0;
		m_ResenTime = 1000;
	}
	
	public void Update(int NowTime)
	{
		if(NowTime > m_ResenTime)
		{
			m_Resen.setShow(true);
			m_ResenReady = true;
		}
		if(m_ResenReady == true)
		{
			switch(m_ResenPosCount)
			{
				case 0:
					m_Resen.setPos(-80.0f,0.0f);
					break;
				case 1:
					m_Resen.setPos(0.0f,40.0f);
					break;
				case 2:
					m_Resen.setPos(80.0f,0.0f);
					break;
				case 3:
					m_Resen.setPos(0.0f,-40.0f);
					break;
			}
			m_Resen.setAlpha(m_Resen.getAlpha() - 0.05f);
			if(m_Resen.getAlpha() <= 0.01f)
			{
				m_ResenPosCount++;
				if(m_ResenPosCount > 3)
					m_ResenPosCount = 0;
				m_Resen.setShow(false);
				m_Resen.setAlpha(1.0f);
				m_ResenReady = false;
				m_ResenState = true;
				m_ResenTime = NowTime + 4000;
			}
		}
	}
	
	public boolean GetResen()
	{
		return m_ResenState;
	}
	
	public stEMVec2 GetResenPos(int NowTime)
	{
		m_ResenState = false;
		m_ResenTime = NowTime + 4000;
		return m_Resen.getPosVec2();
	}
}
