package kdh.and.was.show;

import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class ShowItem {
	
	public EMPlane m_Item;
	
	public boolean m_ShowState;
	
	public int m_ItemTime;

	public void Enter(Scene scene, int ItemType)
	{
		m_Item = new EMPlane();
		if(ItemType == ShowItemState.ITEM_POISON)
			m_Item.setTexture(scene, "image/item/speed_up.png");
		else if(ItemType == ShowItemState.ITEM_UNBEATABLE)
			m_Item.setTexture(scene, "image/item/unbeatable.png");
		m_Item.setPos(0.0f,0.0f);
		if(ItemType == ShowItemState.ITEM_POISON)
			m_Item.setSize(0.07f,0.07f);
		else if(ItemType == ShowItemState.ITEM_UNBEATABLE)
			m_Item.setSize(0.15f,0.15f);
		m_Item.setFrustumCulling(false);
//		m_Item.setOrtho2D(true);
		m_Item.setBlend(true);
		m_Item.setType(0);
		m_Item.setShow(false);
		
		scene.commit(0,ItemType,"Item", m_Item);
		
		m_ShowState = false;
		
		m_ItemTime = 0;
	}
	
	public void Update(float dt)
	{
		if(m_ShowState == true)
		{
			float _100 = 40.0f;
			m_Item.setAlpha(m_Item.getAlpha() - (_100/m_ItemTime));
			if(m_Item.getAlpha() <= 0.01f)
			{
				m_Item.setShow(false);
				m_ShowState = false;
			}
		}
	}
	
	public void Show(stEMVec2 stPos, int ItemTime)
	{
		m_Item.setShow(true);
		m_Item.setPos(stPos);
		m_Item.setAlpha(1.0f);
		m_ItemTime = ItemTime;
		m_ShowState = true;
	}
	
	public boolean GetShowState()
	{
		return m_ShowState;
	}
}
