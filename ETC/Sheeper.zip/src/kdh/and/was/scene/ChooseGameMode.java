package kdh.and.was.scene;

import java.io.IOException;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMBBox;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.InterFace.EMInput.stTouchInfo;
import homi.JEMEngine.Scene.Scene;

import javax.microedition.khronos.opengles.GL10;

import kdh.and.was.activity.HMRenderer;
import kdh.and.was.ui.BackGround;
import kdh.and.was.ui.ToBack;

public class ChooseGameMode extends Scene {

	public BackGround m_BackGround;

	public ToBack m_ToBack;

	public EMPlane[] m_ChooseGameMode;
	public EMPlane m_ChooseMode;

	public boolean m_bChooseMode;

	@Override
	public void enter() {

		try {
			EM2DEngine.D_SOUNDMNG
					.commit("ChooseGameBG", "sound/choosegame.wav");
			EM2DEngine.D_SOUNDMNG.commit("ChooseBG", "sound/choose.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (HMRenderer.m_MusicState == true)
			EM2DEngine.D_SOUNDMNG.play("ChooseGameBG", true);
		/*if (EM2DEngine.D_SOUNDMNG.isPlay("MenuBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("MenuBG");*/

		m_BackGround = new BackGround();
		m_BackGround.Enter(this);

		m_ToBack = new ToBack();
		m_ToBack.Enter(this);

		m_ChooseGameMode = new EMPlane[2];

		for (int i = 0; i < 2; i++) {
			m_ChooseGameMode[i] = new EMPlane();
			if(i == 0)
				m_ChooseGameMode[i].setTexture(this, "image/show/stagemode.png");
			else
				m_ChooseGameMode[i].setTexture(this, "image/show/rankmode.png");
			m_ChooseGameMode[i].setPos(400.0f, 240.0f, -300.0f);
			m_ChooseGameMode[i].setSize(0.38f, 0.45f);
			m_ChooseGameMode[i].setFrustumCulling(false);
			m_ChooseGameMode[i].setBlend(true);
			m_ChooseGameMode[i].setType(0);
			m_ChooseGameMode[i].setShow(true);

			commit(0, i, "ChooseGameMode[i]", m_ChooseGameMode[i]);
		}

		m_ChooseGameMode[0].setPos(-150.0f, 0.0f, -300.0f);
		m_ChooseGameMode[0].setZRot(-30.0f);
		m_ChooseGameMode[1].setPos(150.0f, 0.0f, -330.0f);
		m_ChooseGameMode[1].setZRot(30.0f);
		m_ChooseGameMode[1].setAlpha(0.7f);

		m_bChooseMode = false;
		m_ChooseMode = null;

		// TODO Auto-generated method stub
		super.enter();
	}

	static float Clamp(float value, float min, float max) {
		return Math.max(min, Math.min(max, value));
	}

	static float Lerp(float value1, float value2, float amount) {
		return (value1 + ((value2 - value1) * amount));
	}

	static public float SmoothStep(float value1, float value2, float amount) {
		float num = Clamp(amount, 0.0f, 1.0f);
		return Lerp(value1, value2, (num * num) * (3.0f - (2.0f * num)));
	}

	@Override
	public void update(float dt) {

		if (m_bChooseMode == true) {
			float _PosX = SmoothStep(m_ChooseMode.getPosVec2().m_fX, 0.0f,
					0.20f);
			float _SizeX = SmoothStep(m_ChooseMode.getSize().m_fX, 0.8f, 0.15f);
			float _SizeY = SmoothStep(m_ChooseMode.getSize().m_fY, 1.0f, 0.14f);
			float _RotZ = SmoothStep(m_ChooseMode.getZRot(), 0.0f, 0.18f);
			m_ChooseMode.setPos(_PosX, 0.0f);
			m_ChooseMode.setSize(_SizeX, _SizeY);
			m_ChooseMode.setZRot(_RotZ);

			if (m_ChooseMode.getSize().m_fX >= 0.75f) {
				if (m_ChooseMode == m_ChooseGameMode[0])
					EM2DEngine.D_SCENE.changeSceneFade("StageMenu");
				else if (m_ChooseMode == m_ChooseGameMode[1])
					EM2DEngine.D_SCENE.changeSceneFade("RankGame");
			}
		}

		// TODO Auto-generated method stub
		super.update(dt);
	}

	public boolean touchButton(stEMVec2 stPos, EMPlane TouchPlane) {
		stEMVec2 min = new stEMVec2(TouchPlane.getBoundingBox().stLB.m_fX,
				TouchPlane.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(TouchPlane.getBoundingBox().stRT.m_fX,
				TouchPlane.getBoundingBox().stRT.m_fY);

		EMBBox box = new EMBBox(min, max);
		boolean touchReset = box.contains(new EMVector.stEMVec2(stPos.m_fX,
				stPos.m_fY));

		return touchReset;
	}

	@Override
	public void touchDownEvent(stTouchInfo stPos) {
		// TODO Auto-generated method stub

		if (touchButton(new stEMVec2(stPos.m_fX, stPos.m_fY),
				m_ToBack.m_ToBackButton) == true) {
			m_ToBack.Click();

		}

		super.touchDownEvent(stPos);
	}

	@Override
	public void touchUpEvent(stTouchInfo stPos, int pointerIndex) {
		// TODO Auto-generated method stub

		if (m_ToBack.NClick() == true) {
			EM2DEngine.D_SCENE.changeSceneFade("GameMenu");
		}

		if (m_bChooseMode == false) {
			m_ChooseMode = AABBvsRay(stPos.m_fX, stPos.m_fY, 0);
			if (m_ChooseMode != null) {
				if (m_ChooseMode.getPosVec3().m_fZ == -300.0f) {
					m_ChooseGameMode[0].setShow(false);
					m_ChooseGameMode[1].setShow(false);
					m_ChooseMode.setShow(true);

					if (EM2DEngine.D_SOUNDMNG.isPlay("ChooseGameBG") == true)
						EM2DEngine.D_SOUNDMNG.stop("ChooseGameBG");
					if (HMRenderer.m_MusicState == true)
						EM2DEngine.D_SOUNDMNG.play("ChooseBG", false);

					m_bChooseMode = true;
				} else {
					m_ChooseGameMode[0].setPosZ(-330.0f);
					m_ChooseGameMode[1].setPosZ(-330.0f);
					m_ChooseMode.setPosZ(-300.0f);

					m_ChooseGameMode[0].setAlpha(0.7f);
					m_ChooseGameMode[1].setAlpha(0.7f);
					m_ChooseMode.setAlpha(1.0f);
					
					try {
						EM2DEngine.D_SOUNDMNG
								.commit("ChooseClickBG", "sound/chooseclick.wav");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if (HMRenderer.m_MusicState == true)
						EM2DEngine.D_SOUNDMNG.play("ChooseClickBG", false);

				}
			}
		}

		super.touchUpEvent(stPos, pointerIndex);
	}

	@Override
	public void render(GL10 gl) {
		// TODO Auto-generated method stub
		super.render(gl);
	}

	@Override
	public void exit() {

		if (EM2DEngine.D_SOUNDMNG.isPlay("ChooseGameBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("ChooseGameBG");
		// TODO Auto-generated method stub
		super.exit();
	}
}
