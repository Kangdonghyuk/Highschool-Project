package kdh.and.was.scene;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMBBox;
import homi.JEMEngine.EMNumber;
import homi.JEMEngine.EMNumber.eEMNumStyle;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.InterFace.EMInput.stTouchInfo;
import homi.JEMEngine.Scene.Scene;

import java.io.IOException;

import javax.microedition.khronos.opengles.GL10;

import kdh.and.was.activity.HMRenderer;
import kdh.and.was.sys.FileMNG;
import kdh.and.was.ui.ToBack;

public class StageMenu extends Scene {

	public final int 				MAX_STAGE = 50;
	
	public FileMNG					m_FileMNG;
	
	public ToBack					m_ToBack;
	
	public EMPlane					m_StageBG;
	
	public EMPlane					m_StageReset;
	public EMPlane					m_StageClear;
	public EMPlane					m_ToMenu;   //�޴��� ���ư��� ��ư �߰�
	
	public EMPlane					m_NextStage;
	public EMPlane					m_PrevStage;
	
	public EMPlane[] 				m_Stage;
	public boolean[]				m_StageLock;
	public EMNumber[]				m_StageNum;
	
	public float 					m_CmaPoX;
	public int 						m_ShowStageIndex;
	
	public int OpenStage;
	
	@Override
	public void enter() {
		// TODO Auto-generated method stub
		
		try {
			EM2DEngine.D_SOUNDMNG.commit("StageBG", "sound/stage.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		if(HMRenderer.m_MusicState == true)
			EM2DEngine.D_SOUNDMNG.play("StageBG", true);
		
		/*if(EM2DEngine.D_SOUNDMNG.isPlay("MenuBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("MenuBG");*/
		
		m_FileMNG = new FileMNG();
		
		OpenStage = m_FileMNG.FileRead("StageLock.txt");
		
		m_ToBack = new ToBack();
		m_ToBack.Enter(this);
		m_ToBack.SetPos(new stEMVec2(400.0f,240.0f));
		
		m_Stage = new EMPlane[MAX_STAGE];
		m_StageLock = new boolean[MAX_STAGE];
		m_StageNum = new EMNumber[MAX_STAGE];
		
		m_StageBG = new EMPlane();
		m_StageBG.setTexture(this, "image/show/menubg.png");
		m_StageBG.setPos(400.0f*EM2DEngine.getMagnifX(),240.0f*EM2DEngine.getMagnifY());
		m_StageBG.setSize(0.8f*EM2DEngine.getMagnifX(),1.0f*EM2DEngine.getMagnifY());
		m_StageBG.setFrustumCulling(false);
		m_StageBG.setBlend(true);
		m_StageBG.setOrtho2D(true);
		m_StageBG.setType(0);
		m_StageBG.setShow(true);
		
		commit(3, "StageBG", m_StageBG);
		
		m_StageReset = new EMPlane();
		m_StageReset.setTexture(this, "image/button/restart.png");
		m_StageReset.setPos(650.0f*EM2DEngine.getMagnifX(),30.0f*EM2DEngine.getMagnifY());
		m_StageReset.setSize(0.3f*EM2DEngine.getMagnifX(),0.3f*EM2DEngine.getMagnifY());
		m_StageReset.setFrustumCulling(false);
		m_StageReset.setBlend(true);
		m_StageReset.setOrtho2D(true);
		m_StageReset.setType(0);
		m_StageReset.setShow(true);
		
		commit(1, "StageReset", m_StageReset);
		
		m_StageClear = new EMPlane();
		m_StageClear.setTexture(this, "image/button/right.png");
		m_StageClear.setPos(150.0f*EM2DEngine.getMagnifX(),30.0f*EM2DEngine.getMagnifY());
		m_StageClear.setSize(0.3f*EM2DEngine.getMagnifX(),0.3f*EM2DEngine.getMagnifY());
		m_StageClear.setFrustumCulling(false);
		m_StageClear.setBlend(true);
		m_StageClear.setOrtho2D(true);
		m_StageClear.setType(0);
		m_StageClear.setShow(true);
		
		commit(1, "StageClear", m_StageClear);
		
		m_NextStage = new EMPlane();
		m_NextStage.setTexture(this, "image/button/right.png");
		m_NextStage.setPos(750.0f*EM2DEngine.getMagnifX(),240.0f*EM2DEngine.getMagnifY());
		m_NextStage.setSize(0.5f*EM2DEngine.getMagnifX(),0.5f*EM2DEngine.getMagnifY());
		m_NextStage.setFrustumCulling(false);
		m_NextStage.setBlend(true);
		m_NextStage.setOrtho2D(true);
		m_NextStage.setType(0);
		m_NextStage.setShow(true);
		
		commit(1, "NextStage", m_NextStage);
		
		m_PrevStage = new EMPlane();
		m_PrevStage.setTexture(this, "image/button/left.png");
		m_PrevStage.setPos(50.0f*EM2DEngine.getMagnifX(),240.0f*EM2DEngine.getMagnifY());
		m_PrevStage.setSize(0.5f*EM2DEngine.getMagnifX(),0.5f*EM2DEngine.getMagnifY());
		m_PrevStage.setFrustumCulling(false);
		m_PrevStage.setBlend(true);
		m_PrevStage.setOrtho2D(true);
		m_PrevStage.setType(0);
		m_PrevStage.setShow(true);
		
		commit(1, "PrevStage", m_PrevStage);
		
		for(int i=0; i<MAX_STAGE; i++)
		{
			m_Stage[i] = new EMPlane();
			if(i >= OpenStage)
				m_Stage[i].setTexture(this, "image/button/stage_lock.png");
			else
				m_Stage[i].setTexture(this, "image/button/stage_unlock.png");
			m_Stage[i].setPos(0 + (i*100),0.0f);
			m_Stage[i].setSize(0.5f,0.5f);
			m_Stage[i].setFrustumCulling(false);
			m_Stage[i].setBlend(true);
			m_Stage[i].setType(i+1);
			m_Stage[i].setShow(true);
			
			commit(2, i, "StageMenu", m_Stage[i]);
		}
		
		//int _xValue = 0;
		//int _yValue = 0;
		int _IndexValue = 0;
		
		for(int i = 0; i<5; i++)
		{
			for(int j=0; j<2; j++)
			{
				for(int t=0; t<5; t++)
				{
					m_Stage[_IndexValue].setPos(((i*200)+(-80 + (t*40))),
							30 - (j*60));
					
					_IndexValue++;
				}
			}
		}
		
		for(int i=0; i<MAX_STAGE; i++)
		{

			if(i >= OpenStage)
				m_StageLock[i] = true;
			else
				m_StageLock[i] = false;
		}
		
		for(int i=0; i<MAX_STAGE; i++)
		{
			m_StageNum[i] = new EMNumber(10);
			m_StageNum[i].setTexture(this, 10, 
					"image/number/0.png",
					"image/number/1.png",
					"image/number/2.png",
					"image/number/3.png",
					"image/number/4.png",
					"image/number/5.png",
					"image/number/6.png",
					"image/number/7.png",
					"image/number/8.png",
					"image/number/9.png");
			
			m_StageNum[i].setPos(m_Stage[i].getPosVec2().m_fX-3, m_Stage[i].getPosVec2().m_fY);
			m_StageNum[i].setStyle(eEMNumStyle.E_NUMSTYLE_BASIC);
			m_StageNum[i].setSize(0.05f,0.1f);
			
			m_StageNum[i].setNumber(i+1);
			
			commit(0, i, "ShowNum", m_StageNum[i]);
		}
		
		m_CmaPoX = 100.0f;
		m_ShowStageIndex = 0;
		
		super.enter();
	}
	
	static float Clamp(float value, float min, float max)
	{
		return Math.max(min, Math.min(max, value));
	}
	
	static float Lerp(float value1, float value2, float amount)
	{
		return (value1 + ((value2 - value1) * amount ));
	}
	
	static public float SmoothStep(float value1, float value2, float amount)
	{
		float num = Clamp(amount, 0.0f, 1.0f);
		return Lerp(value1, value2, (num * num) * (3.0f - (2.0f * num)));
	}
	
	@Override
	public void update(float dt) {
		// TODO Auto-generated method stub
		
		m_CmaPoX = (m_ShowStageIndex * 200);
		float _CmPoX = SmoothStep(EM2DEngine.D_CAMERA.getPosVec2().m_fX, m_CmaPoX, 0.15f);
		EM2DEngine.D_CAMERA.setPos(_CmPoX,0.0f);
		
		//float Pitch = EM2DEngine.getPitch();
		
		//EM2DEngine.D_CAMERA.moveX(-Pitch);
		
		/*for(int i=0; i<MAX_STAGE; i++)
		{
			m_StageLock[i].setPos(m_Stage[i].getPosVec2().m_fX, 0.0f);
			m_StageNum[i].setPos(m_Stage[i].getPosVec2().m_fX-10, 0.0f);
		}
		
		for(int i=0; i<MAX_STAGE; i++)
		{
			if(Pitch > 0)
			{
				for(int j=0; j<MAX_STAGE; j++)
				{
					if(m_Stage[j].getPosVec2().m_fX > 1000)
					{
						int t = j+1;
						if(t == MAX_STAGE)
						{
							t = 0;
							m_Stage[j].setPos(m_Stage[t].getPosVec2().m_fX - 100, 0.0f);
						}
						else if(t < MAX_STAGE)
						{
							m_Stage[j].setPos(m_Stage[t].getPosVec2().m_fX - 100, 0.0f);
						}
					}
				}
				m_Stage[i].moveX(Pitch*dt);
			}
			else if(Pitch < 0)
			{
				for(int j=0; j<MAX_STAGE; j++)
				{
					if(m_Stage[j].getPosVec2().m_fX < -1000)
					{
						int t = j-1;
						if(t == -1)
						{
							t = MAX_STAGE-1;
							m_Stage[j].setPos(m_Stage[t].getPosVec2().m_fX + 100, 0.0f);
						}
						else if(t > -1)
						{
							m_Stage[j].setPos(m_Stage[t].getPosVec2().m_fX + 100, 0.0f);
						}
					}
				}
				m_Stage[i].moveX(Pitch*dt);
			}
		}
		*/
		super.update(dt);
	}
	
	@Override
	public void render(GL10 gl) {
		// TODO Auto-generated method stub
		super.render(gl);
	}
	
	@Override
	public void exit() {
		
		if(EM2DEngine.D_SOUNDMNG.isPlay("StageBG") == true)
		{
			EM2DEngine.D_SOUNDMNG.stop("StageBG");
		}
		// TODO Auto-generated method stub
		super.exit();
	}
	
	public boolean touchResetButton(stEMVec2 stPos)
	{
		stEMVec2 min = new stEMVec2(m_StageReset.getBoundingBox().stLB.m_fX, 
				m_StageReset.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(m_StageReset.getBoundingBox().stRT.m_fX, 
				m_StageReset.getBoundingBox().stRT.m_fY);
		
		EMBBox box = new EMBBox(min, max);
		boolean touchStageReset = box.contains(new EMVector.stEMVec2(stPos.m_fX, stPos.m_fY));
		
		return touchStageReset;
	}
	
	public boolean touchClearButton(stEMVec2 stPos)
	{
		stEMVec2 min = new stEMVec2(m_StageClear.getBoundingBox().stLB.m_fX, 
				m_StageClear.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(m_StageClear.getBoundingBox().stRT.m_fX, 
				m_StageClear.getBoundingBox().stRT.m_fY);
		
		EMBBox box = new EMBBox(min, max);
		boolean touchStageClear = box.contains(new EMVector.stEMVec2(stPos.m_fX, stPos.m_fY));
		
		return touchStageClear;
	}
	
	public boolean touchNextStageButton(stEMVec2 stPos)
	{
		stEMVec2 min = new stEMVec2(m_NextStage.getBoundingBox().stLB.m_fX, 
				m_NextStage.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(m_NextStage.getBoundingBox().stRT.m_fX, 
				m_NextStage.getBoundingBox().stRT.m_fY);
		
		EMBBox box = new EMBBox(min, max);
		boolean touchNextStage = box.contains(new EMVector.stEMVec2(stPos.m_fX, stPos.m_fY));
		
		return touchNextStage;
	}
	
	public boolean touchPrevStageButton(stEMVec2 stPos)
	{
		stEMVec2 min = new stEMVec2(m_PrevStage.getBoundingBox().stLB.m_fX, 
				m_PrevStage.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(m_PrevStage.getBoundingBox().stRT.m_fX, 
				m_PrevStage.getBoundingBox().stRT.m_fY);
		
		EMBBox box = new EMBBox(min, max);
		boolean touchPrevStage = box.contains(new EMVector.stEMVec2(stPos.m_fX, stPos.m_fY));
		
		return touchPrevStage;
	}
	
	public boolean touchButton(stEMVec2 stPos, EMPlane TouchPlane)
	{
		stEMVec2 min = new stEMVec2(TouchPlane.getBoundingBox().stLB.m_fX, 
				TouchPlane.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(TouchPlane.getBoundingBox().stRT.m_fX, 
				TouchPlane.getBoundingBox().stRT.m_fY);
		
		EMBBox box = new EMBBox(min, max);
		boolean touchStage = box.contains(new EMVector.stEMVec2(stPos.m_fX, stPos.m_fY));
		
		return touchStage;
	}
	
	@Override
	public void touchDownEvent(stTouchInfo stPos) {
		// TODO Auto-generated method stub
		if(touchButton(new stEMVec2(stPos.m_fX,stPos.m_fY), m_ToBack.m_ToBackButton) == true)
		{
			m_ToBack.Click();
		}
		if(touchResetButton(new stEMVec2(stPos.m_fX,stPos.m_fY)) == true)
		{
			OpenStage = 1;
			m_FileMNG.FileWrite("StageLock.txt", OpenStage);
			for(int i=1; i<MAX_STAGE; i++)
			{
				m_Stage[i].setTexture(this, "image/button/stage_lock.png");
				m_StageLock[i] = true;
			}
		}
		if(touchClearButton(new stEMVec2(stPos.m_fX,stPos.m_fY)) == true)
		{
			m_FileMNG.FileWrite("StageLock.txt", OpenStage);
			m_Stage[OpenStage].setTexture(this, "image/button/stage_unlock.png");
			m_StageLock[OpenStage] = false;
			OpenStage++;
		}
		if(touchNextStageButton(new stEMVec2(stPos.m_fX,stPos.m_fY)) == true)
		{
			if(m_ShowStageIndex < 4)
				m_ShowStageIndex++;
		}
		if(touchPrevStageButton(new stEMVec2(stPos.m_fX,stPos.m_fY)) == true)
		{
			if(m_ShowStageIndex > 0)
				m_ShowStageIndex--;
		}
		
		EMPlane _Plane = null;
		/*_aPlane = AABBvsRay(stPos.m_fX,stPos.m_fY, 1);
		if(_aPlane != null)
		{
			if(_aPlane.getName() == "StageReset")
			{
				m_FileMNG.FileWrite("StageLock.txt", 1);
				for(int i=1; i<MAX_STAGE; i++)
				{
					m_StageLock[i].setShow(true);
				}
			}
		}*/
		//else
		//{
		_Plane = AABBvsRay(stPos.m_fX,stPos.m_fY,2);//(E_BOX_VS_BOX, m_StageSelect, 2);
		//}
		if(_Plane != null)
		{
			int _PlaneType = _Plane.getType();
			if(m_StageLock[_PlaneType-1] == false)
			{
				switch(_Plane.getType())
				{
				case 1:
					EM2DEngine.D_SCENE.changeSceneFade("Stage01");
					break;
				case 2:
					EM2DEngine.D_SCENE.changeSceneFade("Stage02");
					break;
				case 3:
					EM2DEngine.D_SCENE.changeSceneFade("Stage03");
					break;
				case 4:
					EM2DEngine.D_SCENE.changeSceneFade("Stage04");
					break;
				case 5:
					EM2DEngine.D_SCENE.changeSceneFade("Stage05");
					break;
				case 6:
					EM2DEngine.D_SCENE.changeSceneFade("Stage06");
					break;
				case 7:
					EM2DEngine.D_SCENE.changeSceneFade("Stage07");
					break;
				case 8:
					EM2DEngine.D_SCENE.changeSceneFade("Stage08");
					break;
				case 9:
					EM2DEngine.D_SCENE.changeSceneFade("Stage09");
					break;
				case 10:
					EM2DEngine.D_SCENE.changeSceneFade("Stage10");
					break;
				case 11:
					EM2DEngine.D_SCENE.changeSceneFade("Stage11");
					break;
				case 12:
					EM2DEngine.D_SCENE.changeSceneFade("Stage12");
					break;
				case 13:
					EM2DEngine.D_SCENE.changeSceneFade("Stage13");
					break;
				case 14:
					EM2DEngine.D_SCENE.changeSceneFade("Stage14");
					break;
				case 15:
					EM2DEngine.D_SCENE.changeSceneFade("Stage15");
					break;
				case 16:
					EM2DEngine.D_SCENE.changeSceneFade("Stage16");
					break;
				case 17:
					EM2DEngine.D_SCENE.changeSceneFade("Stage17");
					break;
				case 18:
					EM2DEngine.D_SCENE.changeSceneFade("Stage18");
					break;
				case 19:
					EM2DEngine.D_SCENE.changeSceneFade("Stage19");
					break;
				case 20:
					EM2DEngine.D_SCENE.changeSceneFade("Stage20");
					break;
				case 21:
					EM2DEngine.D_SCENE.changeSceneFade("Stage21");
					break;
				case 22:
					EM2DEngine.D_SCENE.changeSceneFade("Stage22");
					break;
				case 23:
					EM2DEngine.D_SCENE.changeSceneFade("Stage23");
					break;
				case 24:
					EM2DEngine.D_SCENE.changeSceneFade("Stage24");
					break;
				case 25:
					EM2DEngine.D_SCENE.changeSceneFade("Stage25");
					break;
				case 26:
					EM2DEngine.D_SCENE.changeSceneFade("Stage26");
					break;
				case 27:
					EM2DEngine.D_SCENE.changeSceneFade("Stage27");
					break;
				case 28:
					EM2DEngine.D_SCENE.changeSceneFade("Stage28");
					break;
				case 29:
					EM2DEngine.D_SCENE.changeSceneFade("Stage29");
					break;
				case 30:
					EM2DEngine.D_SCENE.changeSceneFade("Stage30");
					break;
				case 31:
					EM2DEngine.D_SCENE.changeSceneFade("Stage31");
					break;
				case 32:
					EM2DEngine.D_SCENE.changeSceneFade("Stage32");
					break;
				case 33:
					EM2DEngine.D_SCENE.changeSceneFade("Stage33");
					break;
				case 34:
					EM2DEngine.D_SCENE.changeSceneFade("Stage34");
					break;
				case 35:
					EM2DEngine.D_SCENE.changeSceneFade("Stage35");
					break;
				case 36:
					EM2DEngine.D_SCENE.changeSceneFade("Stage36");
					break;
				case 37:
					EM2DEngine.D_SCENE.changeSceneFade("Stage37");
					break;
				case 38:
					EM2DEngine.D_SCENE.changeSceneFade("Stage38");
					break;
				case 39:
					EM2DEngine.D_SCENE.changeSceneFade("Stage39");
					break;
				case 40:
					EM2DEngine.D_SCENE.changeSceneFade("Stage40");
					break;
				case 41:
					EM2DEngine.D_SCENE.changeSceneFade("Stage41");
					break;
				case 42:
					EM2DEngine.D_SCENE.changeSceneFade("Stage42");
					break;
				case 43:
					EM2DEngine.D_SCENE.changeSceneFade("Stage43");
					break;
				case 44:
					EM2DEngine.D_SCENE.changeSceneFade("Stage44");
					break;
				case 45:
					EM2DEngine.D_SCENE.changeSceneFade("Stage45");
					break;
				case 46:
					EM2DEngine.D_SCENE.changeSceneFade("Stage46");
					break;
				case 47:
					EM2DEngine.D_SCENE.changeSceneFade("Stage47");
					break;
				case 48:
					EM2DEngine.D_SCENE.changeSceneFade("Stage48");
					break;
				case 49:
					EM2DEngine.D_SCENE.changeSceneFade("Stage49");
					break;
				case 50:
					EM2DEngine.D_SCENE.changeSceneFade("Stage50");
					break;
				}
			}
		}
		
		super.touchDownEvent(stPos);
	}
	
	@Override
	public void touchUpEvent(stTouchInfo stPos, int pointerIndex) {
		// TODO Auto-generated method stub
		
		if(m_ToBack.NClick() == true)
		{
			EM2DEngine.D_SCENE.changeSceneFade("GameMenu");
		}
		
		super.touchUpEvent(stPos, pointerIndex);
	}
}
