package kdh.and.was.scene;

import java.io.IOException;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMBBox;
import homi.JEMEngine.EMMath;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.InterFace.EMInput.stTouchInfo;
import homi.JEMEngine.Scene.Scene;

import javax.microedition.khronos.opengles.GL10;

import kdh.and.was.activity.HMRenderer;

public class GameMenu extends Scene
{	
	public EMPlane m_BackGround;
	
	public EMPlane m_Name;
	public EMPlane m_Sheep;
	public EMPlane m_Wolf;
	
	public EMPlane[] m_Button;
	public EMPlane[] m_Cloud;
	
	public EMPlane m_SoundButton;
	public EMPlane m_KeyButton;
	
	public float m_TouchX1;
	public float m_TouchX2;
	public float[] m_CloudSpeedX = new float[5];
	
	public int m_ButtonCount;
	
	public int m_ShowCount;
	
	@Override
	public void enter() {
		
			try {
				EM2DEngine.D_SOUNDMNG.commit("MenuBG", "sound/menu.wav");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		if(HMRenderer.m_MusicState == true)
		{
			if(EM2DEngine.D_SOUNDMNG.isPlay("MenuBG") == false)
				EM2DEngine.D_SOUNDMNG.play("MenuBG", true);
		}
		
		m_BackGround = new EMPlane();
		m_BackGround.setTexture(this, "image/show/menubg.png");
		m_BackGround.setPos(400.0f*EM2DEngine.getMagnifX(),240.0f*EM2DEngine.getMagnifY(),-1.0f);
		m_BackGround.setSize(1.0f*EM2DEngine.getMagnifX(),1.0f*EM2DEngine.getMagnifY());
		m_BackGround.setFrustumCulling(false);
		m_BackGround.setBlend(true);
		m_BackGround.setOrtho2D(true);
		m_BackGround.setType(0);
		m_BackGround.setShow(true);
		
		commit(2,"BackGround", m_BackGround);
		
		m_SoundButton = new EMPlane();
		if(HMRenderer.m_MusicState == true)
			m_SoundButton.setTexture(this, "image/SoundOn.png");
		else
			m_SoundButton.setTexture(this, "image/SoundOff.png");
		m_SoundButton.setPos(720.0f*EM2DEngine.getMagnifX(),70.0f*EM2DEngine.getMagnifY());
		m_SoundButton.setSize(0.8f*EM2DEngine.getMagnifX(),0.8f*EM2DEngine.getMagnifY());
		m_SoundButton.setFrustumCulling(false);
		m_SoundButton.setBlend(true);
		m_SoundButton.setOrtho2D(true);
		m_SoundButton.setAlpha(1.0f);
		m_SoundButton.setType(0);
		m_SoundButton.setShow(false);
		
		commit(0,"SoundButton", m_SoundButton);
		
		m_KeyButton = new EMPlane();
		if(HMRenderer.m_MoveButton == true)
			m_KeyButton.setTexture(this, "image/bk.png");
		else 
			m_KeyButton.setTexture(this, "image/js.png");
		m_KeyButton.setPos(80.0f*EM2DEngine.getMagnifX(),70.0f*EM2DEngine.getMagnifY());
		m_KeyButton.setSize(1.5f*EM2DEngine.getMagnifX(),1.5f*EM2DEngine.getMagnifY());
		m_KeyButton.setFrustumCulling(false);
		m_KeyButton.setBlend(true);
		m_KeyButton.setOrtho2D(true);
		m_KeyButton.setAlpha(1.0f);
		m_KeyButton.setType(0);
		m_KeyButton.setShow(false);
		
		commit(0,"KeyButton", m_KeyButton);
		
		
		m_Name = new EMPlane();
		m_Name.setTexture(this, "image/show/menuname.png");
		m_Name.setPos(0,100.0f,0.0f);
		m_Name.setSize(0.1f,0.1f);
		m_Name.setFrustumCulling(false);
		m_Name.setBlend(true);
		m_Name.setType(0);
		m_Name.setShow(true);
		
		commit(0,"Name", m_Name);
		
		m_Sheep = new EMPlane();
		m_Sheep.setTexture(this, "image/show/menusheep.png");
		m_Sheep.setPos(-150.0f,-20.0f,0.0f);
		m_Sheep.setSize(0.06f,0.06f);
		m_Sheep.setFrustumCulling(false);
		m_Sheep.setBlend(true);
		m_Sheep.setType(0);
		m_Sheep.setShow(true);
		
		commit(1,"Sheep", m_Sheep);
		
		m_Wolf = new EMPlane();
		m_Wolf.setTexture(this, "image/show/menuwolf.png");
		m_Wolf.setPos(150.0f,-20.0f,0.0f);
		m_Wolf.setSize(0.06f,0.06f);
		m_Wolf.setFrustumCulling(false);
		m_Wolf.setBlend(true);
		m_Wolf.setType(0);
		m_Wolf.setShow(true);
		
		commit(1,"Wolf", m_Wolf);
		
		m_Button = new EMPlane[4];
		for(int i=0; i<4; i++)
		{
			m_Button[i] = new EMPlane();
			if(i == 0)
				m_Button[i].setTexture(this, "image/Play.png");
			else if(i == 1)
				m_Button[i].setTexture(this, "image/Credit.png");
			else if(i == 2)
				m_Button[i].setTexture(this, "image/Ranking.png");
			else if(i == 3)
				m_Button[i].setTexture(this, "image/HowToPlay.png");
			m_Button[i].setPos(400.0f * EM2DEngine.getMagnifX(),350.0f * EM2DEngine.getMagnifY());
			m_Button[i].setSize(1.0f * EM2DEngine.getMagnifX(),1.0f * EM2DEngine.getMagnifY());
			m_Button[i].setFrustumCulling(false);
			m_Button[i].setOrtho2D(true);
			m_Button[i].setBlend(true);
			m_Button[i].setType(0);
			m_Button[i].setShow(false);
			
			if(i == 0)
				commit(0,"StartButton", m_Button[i]);
			else if(i == 1)
				commit(0,"CreditButton", m_Button[i]);
			else if(i == 2)
				commit(0,"RankingButton", m_Button[i]);
			else if(i == 3)
				commit(0,"HowButton", m_Button[i]);
		}
		
		m_Cloud = new EMPlane[5];
		
		for(int i=0; i<5; i++)
		{
			m_Cloud[i] = new EMPlane();						//!< �����ڷ� Plane�� ����
			m_Cloud[i].setTexture(this, "image/Cloud.png");	//!< Plane���� ������ �Ǿ��� �ؽ���
			m_Cloud[i].setFrustumCulling(false);				//!< Plane�� ī�޶� �ٶ󺸴� ��ġ���� ��� ��� plane�� �׷����� �ʽ��ϴ�. false�� �ݴ�
			m_Cloud[i].setPos(-150.0f - (i * 100),30.0f);
			//m_pMain.setBoundingBoxCalc(true);				//!< FrustumCulling�� �Ϸ��� �� BoundingBoxCalc����� ������մϴ� 
			m_Cloud[i].setSize(0.2f,0.2f);
			m_Cloud[i].setBlend(true);//!< �������� �ϰ� �ʹٸ� true���ּ��� �⺻���� false�Դϴ�.
			m_Cloud[i].setShow(true);
			
			commit(1,i, "Cloud", m_Cloud[i]);
		}
		m_Cloud[1].setPosY(35.0f);
		m_Cloud[2].setPosY(30.0f);
		m_Cloud[3].setPosY(32.0f);
		m_Cloud[4].setPosY(40.0f);
		
		m_ButtonCount = 0;
		m_ShowCount = 0;
		
		m_TouchX1 = 0.0f;
		m_TouchX2 = 0.0f;
		
		for(int i=0; i<5; i++)
			m_CloudSpeedX[i] = EMMath.randomInt(50)+5;
		
		// TODO Auto-generated method stub
		super.enter();
	}
	
	static float Clamp(float value, float min, float max) {
		return Math.max(min, Math.min(max, value));
	}

	static float Lerp(float value1, float value2, float amount) {
		return (value1 + ((value2 - value1) * amount));
	}

	static public float SmoothStep(float value1, float value2, float amount) {
		float num = Clamp(amount, 0.0f, 1.0f);
		return Lerp(value1, value2, (num * num) * (3.0f - (2.0f * num)));
	}
	
	@Override
	public void update(float dt) {
		
		if(m_ShowCount == 0)
		{
			float _sX = SmoothStep(m_Sheep.getPosVec2().m_fX, -50.0f, 0.2f);
			m_Sheep.setPosX(_sX);
			if(m_Sheep.getPosVec2().m_fX >= -51.0f)
				m_ShowCount = 1;
		}
		if(m_ShowCount == 1)
		{
			float _wX = SmoothStep(m_Wolf.getPosVec2().m_fX, 50.0f, 0.2f);
			m_Wolf.setPosX(_wX);
			if(m_Wolf.getPosVec2().m_fX <= 51.0f)
				m_ShowCount = 2;
		}
		if(m_ShowCount == 2)
		{
			float _nY = SmoothStep(m_Name.getPosVec2().m_fY, 20.0f, 0.2f);
			m_Name.setPosY(_nY);
			if(m_Name.getPosVec2().m_fY <= 21.0f)
			{
				m_ShowCount = 3;
				m_SoundButton.setShow(true);
				m_KeyButton.setShow(true);
			}
		}
		if(m_ShowCount == 3)
		{
			for(int i=0; i<4; i++)
			{
				m_Button[i].setShow(false);
				m_Button[i].setPos(1900.0f,0.0f);
			}
			m_Button[m_ButtonCount].setShow(true);
			m_Button[m_ButtonCount].setPos(400.0f * EM2DEngine.getMagnifX(),350.0f * EM2DEngine.getMagnifY());
			
			for(int i=0; i<5; i++)
			{
				m_Cloud[i].moveX(m_CloudSpeedX[i]*dt);
				if(m_Cloud[i].getPosVec2().m_fX >= 150.0f)
				{
					m_CloudSpeedX[i] = EMMath.randomInt(50)+5;
					m_Cloud[i].setPosX(-150.0f);
				}
			}
		}

		// TODO Auto-generated method stub
		super.update(dt);
	}
	
	@Override
	public void render(GL10 gl) {
		
		
		EM2DEngine.D_CAMERA.setPos(0.0f,0.0f,100.0f);
		// TODO Auto-generated method stub
		super.render(gl);
	}
	
	@Override
	public void exit() {
		
		if(EM2DEngine.D_SOUNDMNG.isPlay("MenuBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("MenuBG");
		
		// TODO Auto-generated method stub
		super.exit();
	}
	
	public boolean touchButton(stEMVec2 stPos, EMPlane TouchPlane) {
		stEMVec2 min = new stEMVec2(TouchPlane.getBoundingBox().stLB.m_fX,
				TouchPlane.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(TouchPlane.getBoundingBox().stRT.m_fX,
				TouchPlane.getBoundingBox().stRT.m_fY);

		EMBBox box = new EMBBox(min, max);
		boolean touchReset = box.contains(new EMVector.stEMVec2(stPos.m_fX,
				stPos.m_fY));

		return touchReset;
	}
	
	@Override
	public void touchDownEvent(stTouchInfo stPos) {
		
		if(m_ShowCount != 3)
		{
			m_SoundButton.setShow(true);
			m_KeyButton.setShow(true);
			m_Sheep.setPosX(-51.0f);
			m_Wolf.setPosX(51.0f);
			m_Name.setPosY(21.0f);
			m_ShowCount = 3;
		}
		
		stEMVec2 _Pos = new stEMVec2(stPos.m_fX,stPos.m_fY);
		if(touchButton(_Pos,m_SoundButton))
		{
			m_SoundButton.setAlpha(0.5f);
			/*if(HMRenderer.m_MusicState == true)
			{
				try {
					EM2DEngine.D_SOUNDMNG.commit("ClickBG", "sound/ClickBG.wav");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				EM2DEngine.D_SOUNDMNG.play("ClickBG", false);
			}*/
		}
		else if(touchButton(_Pos,m_KeyButton))
		{
			m_KeyButton.setAlpha(0.5f);
			/*if(HMRenderer.m_MusicState == true)
			{
				try {
					EM2DEngine.D_SOUNDMNG.commit("ClickBG", "sound/ClickBG.wav");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				EM2DEngine.D_SOUNDMNG.play("ClickBG", false);
			}*/
		}
		else if(touchButton(_Pos,m_Button[0]))
		{
			if(HMRenderer.m_MusicState == true)
			{
				try {
					EM2DEngine.D_SOUNDMNG.commit("ClickBG", "sound/ClickBG.wav");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				EM2DEngine.D_SOUNDMNG.play("ClickBG", false);
			}
			m_Button[0].setTexture(this, "image/Play2.png");
			m_Button[0].setAlpha(0.9f);
		}
		else if(touchButton(_Pos,m_Button[1]))
		{
			if(HMRenderer.m_MusicState == true)
			{
				try {
					EM2DEngine.D_SOUNDMNG.commit("ClickBG", "sound/ClickBG.wav");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				EM2DEngine.D_SOUNDMNG.play("ClickBG", false);
			}
			m_Button[1].setTexture(this, "image/Credit2.png");
			m_Button[1].setAlpha(0.9f);
		}
		else if(touchButton(_Pos,m_Button[2]))
		{
			if(HMRenderer.m_MusicState == true)
			{
				try {
					EM2DEngine.D_SOUNDMNG.commit("ClickBG", "sound/ClickBG.wav");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				EM2DEngine.D_SOUNDMNG.play("ClickBG", false);
			}
			m_Button[2].setTexture(this, "image/Ranking2.png");
			m_Button[2].setAlpha(0.9f);
		}
		else if(touchButton(_Pos,m_Button[3]))
		{
			if(HMRenderer.m_MusicState == true)
			{
				try {
					EM2DEngine.D_SOUNDMNG.commit("ClickBG", "sound/ClickBG.wav");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				EM2DEngine.D_SOUNDMNG.play("ClickBG", false);
			}
			m_Button[3].setTexture(this, "image/HowToPlay2.png");
			m_Button[3].setAlpha(0.9f);
		}
		else
			m_TouchX1 = stPos.m_fX;
		// TODO Auto-generated method stub
		super.touchDownEvent(stPos);
	}
	
	@Override
	public void touchUpEvent(stTouchInfo stPos, int pointerIndex) {
		
		boolean _Touch = false;
		if(m_SoundButton.getAlpha() == 0.5f)
		{
			m_SoundButton.setAlpha(1.0f);
			_Touch = true;
			HMRenderer.m_MusicState = !HMRenderer.m_MusicState;
			if(HMRenderer.m_MusicState == true)
			{
				EM2DEngine.D_SOUNDMNG.play("MenuBG",true);
				m_SoundButton.setTexture(this, "image/SoundOn.png");
			}
			else
			{
				if(EM2DEngine.D_SOUNDMNG.isPlay("MenuBG") == true)
					EM2DEngine.D_SOUNDMNG.stop("MenuBG");
				m_SoundButton.setTexture(this, "image/SoundOff.png");
			}
		}
		else if(m_KeyButton.getAlpha() == 0.5f)
		{
			m_KeyButton.setAlpha(1.0f);
			_Touch = true;
			HMRenderer.m_MoveButton = !HMRenderer.m_MoveButton;
			if(HMRenderer.m_MoveButton == true)
				m_KeyButton.setTexture(this, "image/bk.png");
			else
				m_KeyButton.setTexture(this, "image/js.png");
		}
		else if(m_Button[0].getAlpha() == 0.9f)
		{
			m_Button[0].setTexture(this, "image/Play.png");
			m_Button[0].setAlpha(1.0f);
			_Touch = true;
			EM2DEngine.D_SCENE.changeSceneFade("ChooseGameMode");
		}
		else if(m_Button[1].getAlpha() == 0.9f)
		{
			m_Button[1].setTexture(this, "image/Credit.png");
			m_Button[1].setAlpha(1.0f);
			_Touch = true;
			EM2DEngine.D_SCENE.changeSceneFade("GameCredit");
		}
		else if(m_Button[2].getAlpha() == 0.9f)
		{
			m_Button[2].setTexture(this, "image/Ranking.png");
			m_Button[2].setAlpha(1.0f);
			_Touch = true;
			EM2DEngine.D_SCENE.changeSceneFade("GameRanking");
		}
		else if(m_Button[3].getAlpha() == 0.9f)
		{
			m_Button[3].setTexture(this, "image/HowToPlay.png");
			m_Button[3].setAlpha(1.0f);
			_Touch = true;
			EM2DEngine.D_SCENE.changeSceneFade("TutorGame");
		}
		if(_Touch == false)
		{	
			m_TouchX2 = stPos.m_fX;
			if(m_TouchX1 > m_TouchX2)
			{
				m_ButtonCount++;
				if(m_ButtonCount >= 4)
					m_ButtonCount = 0;
			}
			else if(m_TouchX1 < m_TouchX2)
			{
				m_ButtonCount--;
				if(m_ButtonCount <= -1)
					m_ButtonCount = 3;
			}
			m_TouchX1 = 0.0f;
			m_TouchX2 = 0.0f;
		}
		// TODO Auto-generated method stub
		super.touchUpEvent(stPos, pointerIndex);
	}
}
