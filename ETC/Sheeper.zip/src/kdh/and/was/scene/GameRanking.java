package kdh.and.was.scene;

import java.io.IOException;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMBBox;
import homi.JEMEngine.EMNumber;
import homi.JEMEngine.EMNumber.eEMNumStyle;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.InterFace.EMInput.stTouchInfo;
import homi.JEMEngine.Scene.Scene;

import javax.microedition.khronos.opengles.GL10;

import kdh.and.was.activity.HMRenderer;
import kdh.and.was.sys.FileMNG;
import kdh.and.was.ui.BackGround;
import kdh.and.was.ui.ToBack;

public class GameRanking extends Scene {

	public BackGround m_BackGround;
	public ToBack m_ToBackButton;
	
	public EMPlane m_RankSign;
	public EMPlane m_RankReset;
	
	public EMNumber []m_Rank;
	public EMNumber []m_ShowRank;
	
	public FileMNG m_FileMNG;
	
	public int []m_Ranking;
	
	@Override
	public void enter() {

		try {
			EM2DEngine.D_SOUNDMNG.commit("RankBG", "sound/menu.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		if(HMRenderer.m_MusicState == true)
		{
			if(EM2DEngine.D_SOUNDMNG.isPlay("RankBG") == false)
				EM2DEngine.D_SOUNDMNG.play("RankBG", true);
		}
		
		m_BackGround = new BackGround();
		m_BackGround.Enter(this);
		//m_BackGround.m_BackGround.setTexture(this, "image/show/backgroundrank.png");
		
		m_ToBackButton = new ToBack();
		m_ToBackButton.Enter(this);
		
		m_RankSign = new EMPlane();
		m_RankSign.setTexture(this, "image/show/ranksign.png");
		m_RankSign.setPos(400.0f*EM2DEngine.getMagnifX(),40.0f*EM2DEngine.getMagnifY());
		m_RankSign.setSize(0.8f*EM2DEngine.getMagnifX(),0.7f*EM2DEngine.getMagnifY());
		m_RankSign.setFrustumCulling(false);
		m_RankSign.setBlend(true);
		m_RankSign.setOrtho2D(true);
		m_RankSign.setType(0);
		m_RankSign.setShow(true);
		
		commit(0, "RankSign", m_RankSign);
		
		m_RankReset = new EMPlane();
		m_RankReset.setTexture(this, "image/button/restart.png");
		m_RankReset.setPos(700.0f*EM2DEngine.getMagnifX(),40.0f*EM2DEngine.getMagnifY());
		m_RankReset.setSize(0.5f*EM2DEngine.getMagnifX(),0.5f*EM2DEngine.getMagnifY());
		m_RankReset.setFrustumCulling(false);
		m_RankReset.setBlend(true);
		m_RankReset.setOrtho2D(true);
		m_RankReset.setType(0);
		m_RankReset.setShow(true);
		
		commit(0, "RankReset", m_RankReset);
		
		m_FileMNG = new FileMNG();
//		
//		m_Ranking = new int[10];
//		
		m_Ranking = m_FileMNG.FileArrayRead("RankNumber.txt", 5);
//		
		int _Tocen = HMRenderer.m_RankStage;
		
		if(m_Ranking[4] < _Tocen)
		{
			m_Ranking[4] = _Tocen;
		}
		
		HMRenderer.m_RankStage = 0;
		
		for(int i=0; i<5; i++)
		{
			for(int j=i; j<5; j++)
			{
				if(m_Ranking[i] < m_Ranking[j])
				{
					int _Temp = m_Ranking[j];
					m_Ranking[j] = m_Ranking[i];
					m_Ranking[i] = _Temp;
				}
			}
		}
		
		m_Rank = new EMNumber[5];
		for(int i=0; i<5; i++)
		{
			m_Rank[i] = new EMNumber(10);
			m_Rank[i].setTexture(this, 10, 
					"image/number/0.png",
					"image/number/1.png",
					"image/number/2.png",
					"image/number/3.png",
					"image/number/4.png",
					"image/number/5.png",
					"image/number/6.png",
					"image/number/7.png",
					"image/number/8.png",
					"image/number/9.png");
			
			m_Rank[i].setPos(0.0f, 30.0f - (i*18));
			m_Rank[i].setStyle(eEMNumStyle.E_NUMSTYLE_BASIC);
			m_Rank[i].setSize(0.1f, 0.1f);
			
			m_Rank[i].setNumber(m_Ranking[i]);
			
			commit(0,i, "Rank", m_Rank[i]);
		}
		
		m_ShowRank = new EMNumber[5];
		for(int i=0; i<5; i++)
		{
			m_ShowRank[i] = new EMNumber(10);
			m_ShowRank[i].setTexture(this, 10, 
					"image/number/0.png",
					"image/number/1.png",
					"image/number/2.png",
					"image/number/3.png",
					"image/number/4.png",
					"image/number/5.png",
					"image/number/6.png",
					"image/number/7.png",
					"image/number/8.png",
					"image/number/9.png");
			
			m_ShowRank[i].setPos(-20.0f, 30.0f - (i*18));
			m_ShowRank[i].setStyle(eEMNumStyle.E_NUMSTYLE_BASIC);
			m_ShowRank[i].setSize(0.1f, 0.1f);
			m_ShowRank[i].setColor(0.0f,0.0f,0.0f);
			
			m_ShowRank[i].setNumber(i+1);
			
			commit(0,i, "ShowRank", m_ShowRank[i]);
		}
		
		m_FileMNG.FileArrayWrite("RankNumber.txt", m_Ranking, 5);
		
		// TODO Auto-generated method stub
		super.enter();
	}
	
	@Override
	public void update(float dt) {
		// TODO Auto-generated method stub
		super.update(dt);
	}
	
	@Override
	public void render(GL10 gl) {
		// TODO Auto-generated method stub
		super.render(gl);
	}
	
	public boolean ButtenState(stEMVec2 stPos,EMPlane m_pButten)
	{
		stEMVec2 min = new stEMVec2(m_pButten.getBoundingBox().stLB.m_fX, 
				m_pButten.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(m_pButten.getBoundingBox().stRT.m_fX, 
				m_pButten.getBoundingBox().stRT.m_fY);
		
		EMBBox box = new EMBBox(min, max);
		boolean m_Butten = box.contains(new EMVector.stEMVec2(stPos.m_fX, stPos.m_fY));	
		return m_Butten;
	}
	
	@Override
	public void touchDownEvent(stTouchInfo stPos) {
		// TODO Auto-generated method stub

		if(ButtenState(new stEMVec2(stPos.m_fX,stPos.m_fY), m_ToBackButton.m_ToBackButton) == true)
		{
			m_ToBackButton.Click();
		}
		
		super.touchDownEvent(stPos);
	}
	
	@Override
	public void touchUpEvent(stTouchInfo stPos, int pointerIndex) {
		// TODO Auto-generated method stub

		if(m_ToBackButton.NClick() == true)
			EM2DEngine.D_SCENE.changeSceneFade("GameMenu");
		if(ButtenState(new stEMVec2(stPos.m_fX,stPos.m_fY), m_RankReset) == true)
		{
			for(int i=0; i<5; i++)
			{
				m_Ranking[i] = 0;
				m_Rank[i].setNumber(0);
			}
			m_FileMNG.FileArrayWrite("RankNumber.txt", m_Ranking, 5);
		}
		
		super.touchUpEvent(stPos, pointerIndex);
	}
	
	@Override
	public void exit() {
		
		if(EM2DEngine.D_SOUNDMNG.isPlay("RankBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("RankBG");
		// TODO Auto-generated method stub
		super.exit();
	}
}
