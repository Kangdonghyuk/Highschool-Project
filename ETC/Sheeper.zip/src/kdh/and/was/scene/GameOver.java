package kdh.and.was.scene;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMBBox;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.InterFace.EMInput.stTouchInfo;
import homi.JEMEngine.Scene.Scene;

import java.io.IOException;

import javax.microedition.khronos.opengles.GL10;

import kdh.and.was.activity.HMRenderer;
import kdh.and.was.ui.ReStart;
import kdh.and.was.ui.ToBack;

public class GameOver extends Scene{
	
	public ReStart					m_ReStartButton;
	public ToBack					m_ToBackButton;
	
	public EMPlane					m_GameOver;
	
	public boolean 					m_ButtonShowState;
	
	public int						m_ButtonShowTime;
	public int 						m_NowTime;
	
	public double					m_StartTime;
	
	@Override
	public void enter() {
		
			try {
				EM2DEngine.D_SOUNDMNG.commit("LoseBG", "sound/lose.wav");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(HMRenderer.m_MusicState == true)
				EM2DEngine.D_SOUNDMNG.play("LoseBG", true);
			
		/*if(EM2DEngine.D_SOUNDMNG.isPlay("GameBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("GameBG");*/
		// TODO Auto-generated method stub
		
		m_ReStartButton = new ReStart();
		m_ReStartButton.Enter(this);
		m_ReStartButton.m_ReStartButton.setShow(false);
		m_ReStartButton.m_ReStartButton.setSize(1.0f * EM2DEngine.getMagnifX(),1.0f * EM2DEngine.getMagnifY());
		m_ReStartButton.m_ReStartButton.setAlpha(0.0f);
		m_ReStartButton.SetPos(new stEMVec2(600.0f,240.0f));
		
		m_ToBackButton = new ToBack();
		m_ToBackButton.Enter(this);
		m_ToBackButton.m_ToBackButton.setShow(false);
		m_ToBackButton.m_ToBackButton.setSize(1.0f * EM2DEngine.getMagnifX(),1.0f * EM2DEngine.getMagnifY());
		m_ToBackButton.m_ToBackButton.setAlpha(0.0f);
		m_ToBackButton.SetPos(new stEMVec2(200.0f,240.0f));
		
		m_GameOver = new EMPlane();
		m_GameOver.setTexture(this, "image/show/gameover.png");
		m_GameOver.setPos(400.0f*EM2DEngine.getMagnifX(),240.0f*EM2DEngine.getMagnifY());
		m_GameOver.setSize(0.8f*EM2DEngine.getMagnifX(),1.0f*EM2DEngine.getMagnifY());
		m_GameOver.setOrtho2D(true);
		m_GameOver.setFrustumCulling(false);
		m_GameOver.setBlend(true);
		m_GameOver.setType(0);
		m_GameOver.setShow(true);
		
		commit(10,"GameOver", m_GameOver);
		
		m_StartTime = System.currentTimeMillis();
		
		m_ButtonShowState = false;
		
		m_ButtonShowTime = 2000;
		m_NowTime = 0;
		
		super.enter();
	}
	
	@Override
	public void update(float dt) {
		// TODO Auto-generated method stub
		
		m_NowTime = (int)(System.currentTimeMillis() - m_StartTime);
		
		if(m_ButtonShowState == true)
		{
			m_ReStartButton.m_ReStartButton.setAlpha(m_ReStartButton.m_ReStartButton.getAlpha() + 0.05f);
			m_ToBackButton.m_ToBackButton.setAlpha(m_ToBackButton.m_ToBackButton.getAlpha() + 0.05f);
		}
		else if(m_ButtonShowState == false)
		{
			if(m_NowTime > m_ButtonShowTime)
			{
				m_ReStartButton.m_ReStartButton.setShow(true);
				m_ToBackButton.m_ToBackButton.setShow(true);
				m_ButtonShowState = true;
			}
		}
		
		super.update(dt);
	}
	
	@Override
	public void render(GL10 gl) {
		// TODO Auto-generated method stub
		super.render(gl);
	}
	
	@Override
	public void exit() {
		
		if(EM2DEngine.D_SOUNDMNG.isPlay("LoseBG") == true)
			EM2DEngine.D_SOUNDMNG.stop("LoseBG");
		
		// TODO Auto-generated method stub
		super.exit();
	}
	
	public boolean touchButton(stEMVec2 stPos, EMPlane TouchPlane)
	{
		stEMVec2 min = new stEMVec2(TouchPlane.getBoundingBox().stLB.m_fX, 
				TouchPlane.getBoundingBox().stLB.m_fY);
		stEMVec2 max = new stEMVec2(TouchPlane.getBoundingBox().stRT.m_fX, 
				TouchPlane.getBoundingBox().stRT.m_fY);
		
		EMBBox box = new EMBBox(min, max);
		boolean touchReset = box.contains(new EMVector.stEMVec2(stPos.m_fX, stPos.m_fY));
		
		return touchReset;
	}
	
	@Override
	public void touchDownEvent(stTouchInfo stPos) {
		// TODO Auto-generated method stub
		
		if(touchButton(new stEMVec2(stPos.m_fX,stPos.m_fY),m_ToBackButton.m_ToBackButton) == true)
		{
			try {
				EM2DEngine.D_SOUNDMNG
						.commit("ChooseClickBG", "sound/chooseclick.wav");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (HMRenderer.m_MusicState == true)
				EM2DEngine.D_SOUNDMNG.play("ChooseClickBG", false);
			m_ToBackButton.Click();
		}
		if(touchButton(new stEMVec2(stPos.m_fX,stPos.m_fY),m_ReStartButton.m_ReStartButton) == true)
		{
			try {
				EM2DEngine.D_SOUNDMNG
						.commit("ChooseClickBG", "sound/chooseclick.wav");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (HMRenderer.m_MusicState == true)
				EM2DEngine.D_SOUNDMNG.play("ChooseClickBG", false);
			m_ReStartButton.ReStartClick();
		}
//		EMPlane _Plane = null;
//		_Plane = AABBvsRay(stPos.m_fX,stPos.m_fY, 0);
//		if(_Plane != null)
//		{
//			if(_Plane.getName() == "ReStartButton")
//			{
//				try {
//					EM2DEngine.D_SOUNDMNG
//							.commit("ChooseClickBG", "sound/chooseclick.wav");
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				if (HMRenderer.m_MusicState == true)
//					EM2DEngine.D_SOUNDMNG.play("ChooseClickBG", false);
//				m_ReStartButton.ReStartClick();
//			}
//		}
		
		super.touchDownEvent(stPos);
	}
	
	@Override
	public void touchUpEvent(stTouchInfo stPos, int pointerIndex) {
		// TODO Auto-generated method stub
		
		if(m_ToBackButton.NClick() == true)
			EM2DEngine.D_SCENE.changeSceneFade("GameMenu");
		else if(m_ReStartButton.ReStartNClick() == true)
			EM2DEngine.D_SCENE.changeSceneFade(HMRenderer.m_BackSceneName);
		
		super.touchUpEvent(stPos, pointerIndex);
	}
}
