package kdh.and.was.ui;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.Scene.Scene;

public class Grow {
	
	public Scene				m_NowScene;
	
	public EMPlane[]				m_GrowButton;
	
	public boolean				m_GrowOnOff;
	
	public void Enter(Scene scene)
	{
		m_NowScene = scene;
		
		m_GrowButton = new EMPlane[2];
		for(int i=0; i<2; i++)
		{
			m_GrowButton[i] = new EMPlane();
			m_GrowButton[i].setTexture(m_NowScene, "image/button/grow.png");
			m_GrowButton[i].setPos(720.0f * EM2DEngine.getMagnifX(),400.0f * EM2DEngine.getMagnifY());
			m_GrowButton[i].setSize(0.8f * EM2DEngine.getMagnifX(),0.8f * EM2DEngine.getMagnifY());
			m_GrowButton[i].setFrustumCulling(false);
			m_GrowButton[i].setOrtho2D(true);
			m_GrowButton[i].setBlend(true);
			m_GrowButton[i].setType(0);
			m_GrowButton[i].setShow(false);
		}
		scene.commit(0,"GrowButton", m_GrowButton[0]);
		scene.commit(0,"GrowButton2", m_GrowButton[1]);
		
		m_GrowButton[0].setAlpha(1.0f);
		m_GrowButton[1].setAlpha(0.5f);
		m_GrowButton[0].setShow(true);
		m_GrowButton[1].setShow(false);
		
		m_GrowOnOff = false;
	}

	public void Click()
	{
		m_GrowButton[0].setShow(false);
		m_GrowButton[1].setShow(true);
		//m_GrowButton.setAlpha(0.5f);
		//m_GrowButton.setSize(0.1f,0.1f);
		//m_GrowButton.setTexture(m_NowScene, "image/sheep/sheep.png");
		m_GrowOnOff = true;
	}
	
	public void NClick()
	{
		m_GrowButton[0].setShow(true);
		m_GrowButton[1].setShow(false);
		//m_GrowButton.setAlpha(1.0f);
		//m_GrowButton.setSize(0.3f,0.3f);
		//m_GrowButton.setTexture(m_NowScene, "image/sheep/sheep.png");
		m_GrowOnOff = false;
	}
	
	public boolean GetGrowOnOff()
	{
		return m_GrowOnOff;
	}
}
