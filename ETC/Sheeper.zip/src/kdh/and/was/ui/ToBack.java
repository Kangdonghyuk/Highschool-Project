package kdh.and.was.ui;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class ToBack {

	public EMPlane m_ToBackButton;
	
	public boolean m_ToBackButtonClick;
	
	public void Enter(Scene scene)
	{
		m_ToBackButton = new EMPlane();
		m_ToBackButton.setTexture(scene, "image/button/left.png");
		m_ToBackButton.setPos(60.0f * EM2DEngine.getMagnifX(),420.0f * EM2DEngine.getMagnifY());
		m_ToBackButton.setSize(0.5f * EM2DEngine.getMagnifX(),0.5f * EM2DEngine.getMagnifY());
		m_ToBackButton.setFrustumCulling(false);
		m_ToBackButton.setBlend(true);
		m_ToBackButton.setOrtho2D(true);
		m_ToBackButton.setType(0);
		m_ToBackButton.setShow(true);
		
		scene.commit(0,"ToBackButton", m_ToBackButton);
		
		m_ToBackButtonClick = false;
	}
	
	public void SetPos(stEMVec2 stPos)
	{
		m_ToBackButton.setPos(stPos.m_fX * EM2DEngine.getMagnifX(), stPos.m_fY * EM2DEngine.getMagnifY());
	}
	
	public void Click()
	{
		m_ToBackButton.setAlpha(0.5f);
		m_ToBackButtonClick = true;
	}
	
	public boolean NClick()
	{
		m_ToBackButton.setAlpha(1.0f);
		return m_ToBackButtonClick;
	}
}
