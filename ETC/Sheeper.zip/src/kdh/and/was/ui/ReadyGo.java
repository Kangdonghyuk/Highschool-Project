package kdh.and.was.ui;

import homi.JEMEngine.EMPlane;
import homi.JEMEngine.Scene.Scene;

public class ReadyGo {
	
	public EMPlane				m_Go;
	
	public boolean				m_Finish;
	public boolean				m_GoUpdating;
	
	public int					m_State;
	
	public void Enter(Scene scene)
	{
		m_Go = new EMPlane();
		m_Go.setTexture(scene, "image/show/go.png");
		m_Go.setPos(120.0f,0.0f);
		m_Go.setSize(0.3f,0.3f);
		m_Go.setFrustumCulling(false);
		m_Go.setBlend(true);
		m_Go.setType(0);
		m_Go.setShow(false);
			
		scene.commit(0,"Go", m_Go);
		
		m_GoUpdating = false;
		m_Finish = false;
		
		m_State = 0;
	}

	public void Go()
	{
		m_Go.setShow(true);
		m_GoUpdating = true;
	}
	
	public void Update(float dt)
	{
		if(m_GoUpdating == true)
		{
			if(m_State == 0)
			{
				m_Go.moveX(-200.0f*dt);
				//m_Go.moveZ(50.0f*dt);
				if(m_Go.getPosVec2().m_fX < 10)
					m_State = 1;
			}
			else if(m_State == 1)
			{
				m_Go.moveX(-50.0f*dt);
				if(m_Go.getPosVec2().m_fX < -10)
					m_State = 2;
			}
			else if(m_State == 2)
			{
				m_Go.moveX(-200.0f*dt);
				//m_Go.moveZ(-50.0f*dt);
				if(m_Go.getPosVec2().m_fX < -150)
					m_Finish = true;
			}
		}
	}
	
	public boolean Finish()
	{
		return m_Finish;
	}
}
