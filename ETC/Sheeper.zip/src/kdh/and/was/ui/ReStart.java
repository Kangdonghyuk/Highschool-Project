package kdh.and.was.ui;

import java.io.IOException;

import kdh.and.was.activity.HMRenderer;
import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class ReStart {

	public EMPlane					m_ReStartButton;
	
	public boolean					m_ReStart;
	
	public void Enter(Scene scene)
	{
		m_ReStartButton = new EMPlane();
		m_ReStartButton.setTexture(scene, "image/button/restart.png");
		m_ReStartButton.setPos(200.0f * EM2DEngine.getMagnifX(),420.0f * EM2DEngine.getMagnifY());
		m_ReStartButton.setSize(0.8f * EM2DEngine.getMagnifX(),0.8f * EM2DEngine.getMagnifY());
		m_ReStartButton.setFrustumCulling(false);
		m_ReStartButton.setOrtho2D(true);
		m_ReStartButton.setBlend(true);
		m_ReStartButton.setType(0);
		m_ReStartButton.setShow(true);
		
		scene.commit(0,"ReStartButton", m_ReStartButton);
		
		m_ReStart = false;
	}
	
	public void SetPos(stEMVec2 stPos)
	{
		m_ReStartButton.setPos(stPos.m_fX * EM2DEngine.getMagnifX(), stPos.m_fY * EM2DEngine.getMagnifY());
	}
	
	public void ReStartClick()
	{
		try {
			EM2DEngine.D_SOUNDMNG
					.commit("ChooseClickBG", "sound/chooseclick.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (HMRenderer.m_MusicState == true)
			EM2DEngine.D_SOUNDMNG.play("ChooseClickBG", false);
		m_ReStartButton.setAlpha(0.5f);
		m_ReStart = true;
	}
	
	public boolean ReStartNClick()
	{
		return m_ReStart;
	}
}
