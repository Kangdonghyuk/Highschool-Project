package kdh.and.was.ui;

import homi.JEMEngine.EMNumber;
import homi.JEMEngine.EMNumber.eEMNumStyle;
import homi.JEMEngine.Scene.Scene;

public class ShowStage {

	public EMNumber				m_ShowStage;
	
	public int					m_State;
	
	public boolean				m_Finish;
	
	public void Enter(Scene scene)
	{
		m_ShowStage = new EMNumber(10);
		m_ShowStage.setTexture(scene, 10, 
				"image/number/0.png",
				"image/number/1.png",
				"image/number/2.png",
				"image/number/3.png",
				"image/number/4.png",
				"image/number/5.png",
				"image/number/6.png",
				"image/number/7.png",
				"image/number/8.png",
				"image/number/9.png");
		
		m_ShowStage.setPos(120.0f, 0.0f);
		m_ShowStage.setStyle(eEMNumStyle.E_NUMSTYLE_BASIC);
		m_ShowStage.setSize(0.3f, 0.5f);
		
		m_ShowStage.setNumber(0);
		
		scene.commit(0, "ShowStage", m_ShowStage);
		
		m_State = 0;
		
		m_Finish = false;
	}
	
	public void SetStage(int Stage)
	{
		m_ShowStage.setNumber(Stage);
	}
	
	public void Update(float dt)
	{
		if(m_State == 0)
		{
			m_ShowStage.moveX(-200.0f*dt);
			if(m_ShowStage.getPosVec2().m_fX < 10)
				m_State = 1;
		}
		else if(m_State == 1)
		{
			m_ShowStage.moveX(-50.0f*dt);
			if(m_ShowStage.getPosVec2().m_fX < -10)
				m_State = 2;
		}
		else if(m_State == 2)
		{
			m_ShowStage.moveX(-200.0f*dt);
			if(m_ShowStage.getPosVec2().m_fX < -150)
			{
				m_ShowStage.setShow(false);
				m_Finish = true;
			}
		}
	}
	
	public boolean Finish()
	{
		return m_Finish;
	}
}
