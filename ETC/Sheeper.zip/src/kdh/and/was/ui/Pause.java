package kdh.and.was.ui;

import java.io.IOException;

import kdh.and.was.activity.HMRenderer;
import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class Pause {
	
	public Scene				m_NowScene;
	
	public EMPlane				m_PauseButton;
	
	public EMPlane				m_PauseSign;
	
	public EMPlane				m_PauseToGameButton;
	public EMPlane				m_PauseToMenuButton;
	
	public boolean				m_PauseClick;
	public boolean 				m_PauseToGame;
	public boolean				m_PauseToMenu;
	public boolean				m_PauseOnOff;
	
	public void Enter(Scene scene)
	{
		m_NowScene = scene;
		
		m_PauseButton = new EMPlane();
		m_PauseButton.setTexture(m_NowScene, "image/button/pause.png");
		m_PauseButton.setPos(80.0f * EM2DEngine.getMagnifX(),420.0f * EM2DEngine.getMagnifY());
		m_PauseButton.setSize(0.8f * EM2DEngine.getMagnifX(),0.8f * EM2DEngine.getMagnifY());
		m_PauseButton.setFrustumCulling(false);
		m_PauseButton.setOrtho2D(true);
		m_PauseButton.setBlend(true);
		m_PauseButton.setType(0);
		m_PauseButton.setShow(true);
		
		scene.commit(0,"PauseButton", m_PauseButton);
		
		m_PauseSign = new EMPlane();
		m_PauseSign.setTexture(m_NowScene, "image/button/pausesign.png");
		m_PauseSign.setPos(400.0f * EM2DEngine.getMagnifX(),240.0f * EM2DEngine.getMagnifY());
		m_PauseSign.setSize(0.6f * EM2DEngine.getMagnifX(),0.5f * EM2DEngine.getMagnifY());
		m_PauseSign.setFrustumCulling(false);
		m_PauseSign.setOrtho2D(true);
		m_PauseSign.setBlend(true);
		m_PauseSign.setType(0);
		m_PauseSign.setShow(false);
		
		scene.commit(0,"PauseSign", m_PauseSign);
		
		//////////////////////////////////////
		
		m_PauseToGameButton = new EMPlane();
		m_PauseToGameButton.setTexture(m_NowScene, "image/button/pausetogame.png");
		m_PauseToGameButton.setPos(300 * EM2DEngine.getMagnifX(),240.0f * EM2DEngine.getMagnifY());
		m_PauseToGameButton.setSize(1.0f * EM2DEngine.getMagnifX(),1.0f * EM2DEngine.getMagnifY());
		m_PauseToGameButton.setFrustumCulling(false);
		m_PauseToGameButton.setOrtho2D(true);
		m_PauseToGameButton.setBlend(true);
		m_PauseToGameButton.setType(0);
		m_PauseToGameButton.setShow(false);
		
		scene.commit(0,"PauseToGameButton", m_PauseToGameButton);
		
		
		m_PauseToMenuButton = new EMPlane();
		m_PauseToMenuButton.setTexture(m_NowScene, "image/button/pausetomenu.png");
		m_PauseToMenuButton.setPos(500.0f * EM2DEngine.getMagnifX(),240.0f * EM2DEngine.getMagnifY());
		m_PauseToMenuButton.setSize(1.0f * EM2DEngine.getMagnifX(),1.0f * EM2DEngine.getMagnifY());
		m_PauseToMenuButton.setFrustumCulling(false);
		m_PauseToMenuButton.setOrtho2D(true);
		m_PauseToMenuButton.setBlend(true);
		m_PauseToMenuButton.setType(0);
		m_PauseToMenuButton.setShow(false);
		
		scene.commit(0,"PauseToMenuButton", m_PauseToMenuButton);
		
		m_PauseClick = false;
		m_PauseToGame = false;
		m_PauseToMenu = false;
		m_PauseOnOff = false;
	}
	
	public void SetPos(stEMVec2 stPos)
	{
		m_PauseButton.setPos(stPos.m_fX * EM2DEngine.getMagnifX(), stPos.m_fY * EM2DEngine.getMagnifY());
	}
	
	public void PauseClick()
	{
		try {
			EM2DEngine.D_SOUNDMNG
					.commit("ChooseClickBG", "sound/chooseclick.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (HMRenderer.m_MusicState == true)
			EM2DEngine.D_SOUNDMNG.play("ChooseClickBG", false);
		m_PauseClick = true;
		m_PauseButton.setAlpha(0.5f);
	}
	
	public void PauseToGameClick()
	{
		try {
			EM2DEngine.D_SOUNDMNG
					.commit("ChooseClickBG", "sound/chooseclick.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (HMRenderer.m_MusicState == true)
			EM2DEngine.D_SOUNDMNG.play("ChooseClickBG", false);
		m_PauseToGameButton.setAlpha(0.5f);
		m_PauseToGame = true;
	}
	
	public void PauseToMenuClick()
	{
		try {
			EM2DEngine.D_SOUNDMNG
					.commit("ChooseClickBG", "sound/chooseclick.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (HMRenderer.m_MusicState == true)
			EM2DEngine.D_SOUNDMNG.play("ChooseClickBG", false);
		m_PauseToMenuButton.setAlpha(0.5f);
		m_PauseToMenu = true;
	}
	
	public boolean PauseToMenuNClick()
	{
		m_PauseToMenuButton.setAlpha(1.0f);
		return m_PauseToMenu;
	}
	
	public boolean PauseToGameNClick()
	{
		m_PauseToGameButton.setAlpha(1.0f);
		return m_PauseToGame;
	}
	
	public boolean PauseNClick()
	{
		m_PauseButton.setAlpha(1.0f);
		return m_PauseClick;
	}
	
	public void OnPause()
	{
		m_PauseSign.setShow(true);
		m_PauseToGameButton.setShow(true);
		m_PauseToMenuButton.setShow(true);
		m_PauseButton.setAlpha(0.5f);
		m_PauseClick = false;
		m_PauseOnOff = true;
	}
	
	public void OffPause()
	{
		m_PauseSign.setShow(false);
		m_PauseToGameButton.setShow(false);
		m_PauseToMenuButton.setShow(false);
		m_PauseButton.setAlpha(1.0f);
		m_PauseOnOff = false;
		m_PauseToGame = false;
		m_PauseToMenu = false;
	}
	
	public boolean GetPauseOnOff()
	{
		return m_PauseOnOff;
	}
}
