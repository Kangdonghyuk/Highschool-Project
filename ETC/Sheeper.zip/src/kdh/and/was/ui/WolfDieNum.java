package kdh.and.was.ui;

import homi.JEMEngine.EMNumber;
import homi.JEMEngine.EMNumber.eEMNumStyle;
import homi.JEMEngine.Scene.Scene;

public class WolfDieNum {

	public EMNumber m_WolfDieNum;
	
	public void Enter(Scene scene)
	{
		m_WolfDieNum = new EMNumber(10);
		m_WolfDieNum.setTexture(scene, 10, 
				"image/number/0.png",
				"image/number/1.png",
				"image/number/2.png",
				"image/number/3.png",
				"image/number/4.png",
				"image/number/5.png",
				"image/number/6.png",
				"image/number/7.png",
				"image/number/8.png",
				"image/number/9.png");
		
		m_WolfDieNum.setPos(0.0f, 50.0f);
		m_WolfDieNum.setStyle(eEMNumStyle.E_NUMSTYLE_BASIC);
		m_WolfDieNum.setSize(0.1f, 0.1f);
		
		m_WolfDieNum.setNumber(0);
		
		scene.commit(0, "WolfDieNum", m_WolfDieNum);
	}
	
	public void SetWolfDieNum(int WolfDieNum)
	{
		m_WolfDieNum.setNumber(WolfDieNum);
	}
}
