package kdh.and.was.ui;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.Scene.Scene;

public class BackGround {

	public EMPlane				m_BackGround;
	
	public void Enter(Scene scene)
	{
		m_BackGround = new EMPlane();
		m_BackGround.setTexture(scene, "image/show/background.png");
		m_BackGround.setPos(400.0f*EM2DEngine.getMagnifX(),240.0f*EM2DEngine.getMagnifY());
		m_BackGround.setSize(0.78f*EM2DEngine.getMagnifX(),0.47f*EM2DEngine.getMagnifY());
		m_BackGround.setFrustumCulling(false);
		m_BackGround.setBlend(true);
		m_BackGround.setOrtho2D(true);
		m_BackGround.setType(0);
		m_BackGround.setShow(true);
		
		scene.commit(12,"BackGround", m_BackGround);
	}
}
