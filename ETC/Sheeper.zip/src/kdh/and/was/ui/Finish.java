package kdh.and.was.ui;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.Scene.Scene;

public class Finish {
	
	public EMPlane					m_NextGameButton;
	public EMPlane					m_Win;
	
	public boolean					m_NextGmae;
	
	public int 						m_State;

	public void Enter(Scene scene)
	{
		m_NextGameButton = new EMPlane();
		m_NextGameButton.setTexture(scene, "image/button/right.png");
		m_NextGameButton.setPos(400.0f * EM2DEngine.getMagnifX(),240.0f * EM2DEngine.getMagnifY());
		m_NextGameButton.setSize(1.0f * EM2DEngine.getMagnifX(),1.0f * EM2DEngine.getMagnifX());
		m_NextGameButton.setFrustumCulling(false);
		m_NextGameButton.setOrtho2D(true);
		m_NextGameButton.setBlend(true);
		m_NextGameButton.setType(0);
		m_NextGameButton.setShow(false);
		
		scene.commit(0,"NextGameButton", m_NextGameButton);
		
		///////////////////////////////
		m_Win = new EMPlane();
		m_Win.setTexture(scene, "image/show/win.png");
		m_Win.setPos(120.0f,0.0f);
		m_Win.setSize(0.2f,0.2f);
		m_Win.setFrustumCulling(false);
		m_Win.setBlend(true);
		m_Win.setType(0);
		m_Win.setShow(false);
		
		scene.commit(1,"Win", m_Win);
		
		m_State = 0;
		
		m_NextGmae = false;
	}
	
	public void Win(float dt)
	{
		
		if(m_State == 0)
		{
			m_Win.setShow(true);
			m_Win.moveX(-200.0f*dt);
			//m_Go.moveZ(50.0f*dt);
			if(m_Win.getPosVec2().m_fX < 10)
				m_State = 1;
		}
		else if(m_State == 1)
		{
			m_Win.moveX(-50.0f*dt);
			if(m_Win.getPosVec2().m_fX < -10)
				m_State = 2;
		}
		else if(m_State == 2)
		{
			m_Win.moveX(-200.0f*dt);
			//m_Go.moveZ(-50.0f*dt);
			if(m_Win.getPosVec2().m_fX < -150)
			{
				m_Win.setShow(false);
				m_NextGameButton.setShow(true);
			}
		}
	}
	
	public void NextGameClick()
	{
		m_NextGameButton.setAlpha(0.5f);
		m_NextGmae = true;
	}
	
	public boolean NextGameNClick()
	{
		return m_NextGmae;
	}
}
