package kdh.and.was.effect;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;
import kdh.and.was.game.RankGame;
import kdh.and.was.game.RootGame;
import kdh.and.was.game.TutorGame;
import kdh.and.was.wolf.WolfMNG;

public class Effect {
	
	public EMPlane[]			m_Wolf_Fur = new EMPlane[3];
	public EMPlane[]			m_Sheep_Fur = new EMPlane[3];
	
	public int 					m_EffectLifeTime;
	
	public int 					m_ID;
	
	public void CreateEffect(Scene scene,stEMVec2 EffectPos, int ID, int Wolf_Type, int EffectType)
	{
		m_ID = ID;
		
		for(int i=0; i<3; i++)
		{
			m_Wolf_Fur[i] = new EMPlane();
			switch(Wolf_Type)
			{
			case WolfMNG.WOLF:
				m_Wolf_Fur[i].setTexture(scene, "image/effect/wolf_fur.png");
				break;
			case WolfMNG.WOLF_GROW:
				m_Wolf_Fur[i].setTexture(scene, "image/effect/sheep_fur.png");
				break;
			case WolfMNG.WOLF_POWER:
				m_Wolf_Fur[i].setTexture(scene, "image/effect/wolf_power_fur.png");
				break;
			case WolfMNG.WOLF_STAY:
				m_Wolf_Fur[i].setTexture(scene, "image/effect/wolf_stay_fur.png");
				break;
			}
			m_Wolf_Fur[i].setPos(EffectPos.m_fX,EffectPos.m_fY);
			m_Wolf_Fur[i].setSize(0.1f, 0.1f);
			m_Wolf_Fur[i].setFrustumCulling(false);
			m_Wolf_Fur[i].setBlend(true);
			m_Wolf_Fur[i].setType(EffectType);
			m_Wolf_Fur[i].setShow(true);
			
			scene.commit(3, m_ID+i, "Wolf_Fur", m_Wolf_Fur[i]);
		}
		
		for(int i=0; i<2; i++)
		{
			m_Sheep_Fur[i] = new EMPlane();
			m_Sheep_Fur[i].setTexture(scene, "image/effect/sheep_fur.png");
			m_Sheep_Fur[i].setPos(EffectPos.m_fX,EffectPos.m_fY);
			m_Sheep_Fur[i].setSize(0.1f,0.1f);
			m_Sheep_Fur[i].setFrustumCulling(false);
			m_Sheep_Fur[i].setBlend(true);
			m_Sheep_Fur[i].setType(EffectType);
			m_Sheep_Fur[i].setShow(true);
			
			scene.commit(3, m_ID+i, "Sheep_Fur", m_Sheep_Fur[i]);
		}
		
	/*	m_Wolf_Fur[0].setPosY((EffectPos.m_fY + 5) * EM2DEngine.getMagnifY());
		m_Wolf_Fur[1].setPosX((EffectPos.m_fX + 5) * EM2DEngine.getMagnifX());
		m_Wolf_Fur[2].setPos(
				(EffectPos.m_fX - 3) * EM2DEngine.getMagnifX(), 
				(EffectPos.m_fY - 3) * EM2DEngine.getMagnifY());
		
		m_Sheep_Fur[0].setPos(
				(EffectPos.m_fX + 3) * EM2DEngine.getMagnifX(), 
				(EffectPos.m_fY - 3) * EM2DEngine.getMagnifY());
		m_Wolf_Fur[1].setPosX((EffectPos.m_fX - 5) * EM2DEngine.getMagnifX());*/
		
		if(EM2DEngine.D_SCENE.getChangeSceneName() == "TutorGame")
			m_EffectLifeTime = TutorGame.m_NowTime + 200;
		else if(EM2DEngine.D_SCENE.getChangeSceneName() == "RankGame")
			m_EffectLifeTime = RankGame.m_NowTime + 200;
		else
			m_EffectLifeTime = RootGame.m_NowTime + 200;
		
	}
	
	public void Update(float dt)
	{
		m_Wolf_Fur[0].moveY(50.0f*dt);
		m_Wolf_Fur[1].moveX(50.0f*dt);
		m_Wolf_Fur[2].moveX(-50.0f*dt);
		m_Wolf_Fur[2].moveY(-50.0f*dt);
		
		m_Sheep_Fur[0].moveX(50.0f*dt);
		m_Sheep_Fur[0].moveY(-50.0f*dt);
		m_Sheep_Fur[1].moveX(-50.0f*dt);
	}
	
	public void Destory()
	{
		for(int i=0; i<3; i++)
		{
			m_Wolf_Fur[i].setShow(false);
			m_Wolf_Fur[i].destroy();
		}
		
		for(int i=0; i<2; i++)
		{
			m_Sheep_Fur[i].setShow(false);
			m_Sheep_Fur[i].destroy();
		}
	}
}
