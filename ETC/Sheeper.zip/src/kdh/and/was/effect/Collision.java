package kdh.and.was.effect;

import homi.JEMEngine.EMMath;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class Collision extends Effect {
	
	public void CreateEffect(Scene scene, stEMVec2 SheepPos, stEMVec2 WolfPos,
			int ID, int Wolf_Type, int EffectType) {
		// TODO Auto-generated method stub
		
		stEMVec2 _SheepPos2D = EMMath.worldToScreen(new stEMVec2(SheepPos.m_fX,SheepPos.m_fY));
		stEMVec2 _WolfPos2D = EMMath.worldToScreen(new stEMVec2(WolfPos.m_fX,WolfPos.m_fY));
		
		float _EfcPosX = 0;//(Math.abs(_SheepPos2D.m_fX - _WolfPos2D.m_fX) / 2);
		float _EfcPosY = 0;//(Math.abs(_SheepPos2D.m_fY - _WolfPos2D.m_fY) / 2);
		
		if(_SheepPos2D.m_fX > _WolfPos2D.m_fX)
			_EfcPosX = _SheepPos2D.m_fX - (_SheepPos2D.m_fX - _WolfPos2D.m_fX)/2;
		else
			_EfcPosX = _WolfPos2D.m_fX - (_WolfPos2D.m_fX - _SheepPos2D.m_fX)/2;
		
		if(_SheepPos2D.m_fY > _WolfPos2D.m_fY)
			_EfcPosY = _SheepPos2D.m_fY - (_SheepPos2D.m_fY - _WolfPos2D.m_fY)/2;
		else
			_EfcPosY = _WolfPos2D.m_fY - (_WolfPos2D.m_fY - _SheepPos2D.m_fY)/2;
		
		stEMVec2 _EffectPos = EMMath.screenToWorld(_EfcPosX,_EfcPosY);		
		
		super.CreateEffect(scene, _EffectPos, ID, Wolf_Type, EffectType);
	}
	
	public void Update(float dt)
	{
		super.Update(dt);
	}
	
	public void Destory()
	{
		super.Destory();
	}
}
