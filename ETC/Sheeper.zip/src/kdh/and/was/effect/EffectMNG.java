package kdh.and.was.effect;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

import java.util.ArrayList;

import kdh.and.was.game.RankGame;
import kdh.and.was.game.RootGame;
import kdh.and.was.game.TutorGame;

public class EffectMNG {

	public static final int				EFFECT_COLLISION = 0;
	
	public Scene						m_NowScene;
	
	public ArrayList<Effect> 			m_EffectList;
	
	public int							m_ID;
	
	public void Enter(Scene scene)
	{
		m_NowScene = scene;
		
		m_EffectList = new ArrayList<Effect>();
		
		m_ID = 0;
	}
	
	public void CreateEffect(stEMVec2 SheepPos, stEMVec2 WolfPos,int Wolf_Type, int Effect_Type)
	{
		
		switch(Effect_Type)
		{
		case EFFECT_COLLISION:
			Collision _Collision = new Collision();
			_Collision.CreateEffect(m_NowScene, SheepPos, WolfPos, m_ID, Wolf_Type, Effect_Type);
			
			m_EffectList.add(_Collision);
			break;
		}
		
		m_ID += 3;
	}
	
	public void Update(float dt)
	{
		for(int _list = 0; _list < m_EffectList.size(); _list++)
		{
			m_EffectList.get(_list).Update(dt);
			int _NowTime = 0;
			if(EM2DEngine.D_SCENE.getChangeSceneName() == "TutorGame")
				_NowTime = TutorGame.m_NowTime;
			else if(EM2DEngine.D_SCENE.getChangeSceneName() == "RankGame")
				_NowTime = RankGame.m_NowTime;
			else
				_NowTime = RootGame.m_NowTime;
			if(_NowTime > m_EffectList.get(_list).m_EffectLifeTime)
			{
				m_EffectList.get(_list).Destory();
				m_EffectList.remove(_list);
			}
		}
	}
	
	public void Clear()
	{
		for(int _list = 0; _list < m_EffectList.size(); _list++)
		{
			m_EffectList.get(_list).Destory();
			m_EffectList.remove(_list);
		}
	}
}
