package kdh.and.was.item;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMMath;
import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

import java.util.ArrayList;

import kdh.and.was.game.RankGame;
import kdh.and.was.game.RootGame;
import kdh.and.was.game.TutorGame;

public class ItemMNG {

	public static final int ITEM_SIZEDOWN = 0;
	public static final int ITEM_UNBEATABLE = 1;
	public static final int ITEM_SIZEUP = 2;

	public Scene m_NowScene;

	public ArrayList<Item> m_ItemList;

	public int m_ID;
	public int m_ItemTime;

	public void Enter(Scene scene) {
		m_NowScene = scene;

		m_ItemList = new ArrayList<Item>();

		m_ItemTime = 2000;

		{
			SizeDown _SizeDown = new SizeDown();
			_SizeDown.CreateItem(m_NowScene, new stEMVec2(1000.0f, 0.0f), m_ID,
					ITEM_SIZEDOWN);

			m_ItemList.add(_SizeDown);
		}
	}

	public void CreateItem(int ItemType) {
		switch (ItemType) {
			case ITEM_SIZEDOWN :
				SizeDown _SizeDown = new SizeDown();
				_SizeDown.CreateItem(m_NowScene, new stEMVec2(50.0f, 0), m_ID,
						ITEM_SIZEDOWN);
				m_ItemList.add(_SizeDown);
				break;
			case ITEM_UNBEATABLE :
				Unbeatable _Unbeatable = new Unbeatable();
				_Unbeatable.CreateItem(m_NowScene, new stEMVec2(50.0f, 0),
						m_ID, ITEM_UNBEATABLE);
				m_ItemList.add(_Unbeatable);
				break;
			case ITEM_SIZEUP :
				SizeUp _SizeUp = new SizeUp();
				_SizeUp.CreateItem(m_NowScene, new stEMVec2(50.0f, 0.0f), m_ID,
						ITEM_SIZEUP);
				m_ItemList.add(_SizeUp);
				break;
		}
	}

	public void Update(float dt) {
		int _NowTime;
		if(EM2DEngine.D_SCENE.getChangeSceneName() == "TutorGame")
			_NowTime = TutorGame.m_NowTime;
		else if(EM2DEngine.D_SCENE.getChangeSceneName() == "RankGame")
			_NowTime = RankGame.m_NowTime;
		else
			_NowTime = RootGame.m_NowTime;
		if (_NowTime > m_ItemTime) {
			int _ItemType = EMMath.randomInt(10);

			if (_ItemType >= 9) {
				_ItemType = ITEM_UNBEATABLE;
			}
			else if(_ItemType >= 6)
			{
				_ItemType = ITEM_SIZEUP;
			}
			else if (_ItemType >= 0) {
				_ItemType = ITEM_SIZEDOWN;
			}

			switch (_ItemType) {
				case ITEM_SIZEDOWN :
					SizeDown _SizeDown = new SizeDown();
					_SizeDown.CreateItem(
							m_NowScene,
							new stEMVec2(EMMath.randomInt(160) - 80, EMMath
									.randomInt(90) - 45), m_ID, ITEM_SIZEDOWN);
					m_ItemList.add(_SizeDown);
					break;
				case ITEM_UNBEATABLE :
					Unbeatable _Unbeatable = new Unbeatable();
					_Unbeatable
							.CreateItem(m_NowScene,
									new stEMVec2(EMMath.randomInt(160) - 80,
											EMMath.randomInt(90) - 45), m_ID,
									ITEM_UNBEATABLE);
					m_ItemList.add(_Unbeatable);
					break;
				case ITEM_SIZEUP :
					SizeUp _SizeUp = new SizeUp();
					_SizeUp.CreateItem(
							m_NowScene,
							new stEMVec2(EMMath.randomInt(160) - 80, EMMath
									.randomInt(90) - 45), m_ID, ITEM_SIZEUP );
					m_ItemList.add(_SizeUp);
					break;
			}

			m_ItemTime = _NowTime + 2000;
		}

		for (int _list = 0; _list < m_ItemList.size(); _list++) {
			m_ItemList.get(_list).m_Item.setAlpha(m_ItemList.get(_list).m_Item
					.getAlpha() - 0.01f);
			if (m_ItemList.get(_list).m_Item.getAlpha() <= 0.1f) {
				m_ItemList.get(_list).Destory();
				m_ItemList.remove(_list);
			}
		}

		m_ID++;
	}

	public void Using(EMPlane Plane) {
		for (int _list = 0; _list < m_ItemList.size(); _list++) {
			if (m_ItemList.get(_list).m_Item == Plane) {
				m_ItemList.get(_list).Destory();
				m_ItemList.remove(_list);
			}
		}
	}
}
