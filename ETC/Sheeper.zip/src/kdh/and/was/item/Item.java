package kdh.and.was.item;

import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class Item {

	public EMPlane				m_Item;
	
	public int 					m_ID;
	
	public void CreateItem(Scene scene, stEMVec2 ItemPos, int ID, int ItemType)
	{
		m_ID = ID;
		
		m_Item = new EMPlane();
		switch(ItemType)
		{
		case ItemMNG.ITEM_SIZEDOWN:
			m_Item.setTexture(scene, "image/item/size_down.png");
			break;
		case ItemMNG.ITEM_UNBEATABLE:
			m_Item.setTexture(scene, "image/item/unbeatable.png");
			break;
		case ItemMNG.ITEM_SIZEUP:
			m_Item.setTexture(scene, "image/item/size_up.png");
			break;
		}
		m_Item.setPos(ItemPos.m_fX, ItemPos.m_fY);
		if(ItemType == ItemMNG.ITEM_SIZEDOWN)
			m_Item.setSize(0.08f,0.08f);
		else
			m_Item.setSize(0.15f,0.15f);
		m_Item.setFrustumCulling(false);
		m_Item.setBlend(true);
		m_Item.setType(ItemType);
		m_Item.setShow(true);
		
		scene.commit(2,m_ID,"Item", m_Item);
	}
	
	public void Destory()
	{
		m_Item.setShow(false);
		m_Item.destroy();
	}
}
