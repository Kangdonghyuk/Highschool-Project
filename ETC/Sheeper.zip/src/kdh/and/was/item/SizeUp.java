package kdh.and.was.item;

import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class SizeUp extends Item {

	public void CreateItem(Scene scene, stEMVec2 ItemPos, int ID, int ItemType)
	{
		super.CreateItem(scene, ItemPos, ID, ItemType);
	}
	
	public void Destory()
	{
		super.Destory();
	}
}
