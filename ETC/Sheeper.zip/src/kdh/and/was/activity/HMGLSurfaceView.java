package kdh.and.was.activity;

import homi.JEMEngine.EM2DEngine;
import android.content.Context;
import android.hardware.SensorManager;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class HMGLSurfaceView extends GLSurfaceView
{
	private HMRenderer m_stdRender;
	
	public HMGLSurfaceView(Context context, SensorManager sensorMng) 
    {
        super(context);
        
        m_stdRender = new HMRenderer(context, sensorMng);
        setRenderer(m_stdRender);
    }

    public boolean onTouchEvent(final MotionEvent event)
    {
    	queueEvent(new Runnable() 
    	{
            public void run() 
            {
            	EM2DEngine.D_WORLD.touchEvent(event);
            }
    	});

    	try
    	{
			Thread.sleep(50);
		}
    	catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
        return true;
    }
}
