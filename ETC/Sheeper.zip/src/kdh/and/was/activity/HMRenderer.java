package kdh.and.was.activity;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMColor;
import homi.JEMEngine.EMVector.stEMVec3;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import kdh.and.was.game.RankGame;
import kdh.and.was.game.TutorGame;
import kdh.and.was.scene.ChooseGameMode;
import kdh.and.was.scene.GameCredit;
import kdh.and.was.scene.GameMenu;
import kdh.and.was.scene.GameOver;
import kdh.and.was.scene.GameRanking;
import kdh.and.was.scene.KGLogo;
import kdh.and.was.scene.StageMenu;
import kdh.and.was.scene.TeamLogo;
import kdh.and.was.stage.Stage01;
import kdh.and.was.stage.Stage02;
import kdh.and.was.stage.Stage03;
import kdh.and.was.stage.Stage04;
import kdh.and.was.stage.Stage05;
import kdh.and.was.stage.Stage06;
import kdh.and.was.stage.Stage07;
import kdh.and.was.stage.Stage08;
import kdh.and.was.stage.Stage09;
import kdh.and.was.stage.Stage10;
import kdh.and.was.stage.Stage11;
import kdh.and.was.stage.Stage12;
import kdh.and.was.stage.Stage13;
import kdh.and.was.stage.Stage14;
import kdh.and.was.stage.Stage15;
import kdh.and.was.stage.Stage16;
import kdh.and.was.stage.Stage17;
import kdh.and.was.stage.Stage18;
import kdh.and.was.stage.Stage19;
import kdh.and.was.stage.Stage20;
import kdh.and.was.stage.Stage21;
import kdh.and.was.stage.Stage22;
import kdh.and.was.stage.Stage23;
import kdh.and.was.stage.Stage24;
import kdh.and.was.stage.Stage25;
import kdh.and.was.stage.Stage26;
import kdh.and.was.stage.Stage27;
import kdh.and.was.stage.Stage28;
import kdh.and.was.stage.Stage29;
import kdh.and.was.stage.Stage30;
import kdh.and.was.stage.Stage31;
import kdh.and.was.stage.Stage32;
import kdh.and.was.stage.Stage33;
import kdh.and.was.stage.Stage34;
import kdh.and.was.stage.Stage35;
import kdh.and.was.stage.Stage36;
import kdh.and.was.stage.Stage37;
import kdh.and.was.stage.Stage38;
import kdh.and.was.stage.Stage39;
import kdh.and.was.stage.Stage40;
import kdh.and.was.stage.Stage41;
import kdh.and.was.stage.Stage42;
import kdh.and.was.stage.Stage43;
import kdh.and.was.stage.Stage44;
import kdh.and.was.stage.Stage45;
import kdh.and.was.stage.Stage46;
import kdh.and.was.stage.Stage47;
import kdh.and.was.stage.Stage48;
import kdh.and.was.stage.Stage49;
import kdh.and.was.stage.Stage50;
import android.content.Context;
import android.hardware.SensorManager;
import android.opengl.GLSurfaceView;

public class HMRenderer implements GLSurfaceView.Renderer
{
	private int m_nWidth;		// ��ȿ�� - ����̽� ȭ���ػ�
	private int m_nHeight;	
	
	private boolean m_bChangeLoop;		// ��ȿ�� - 06.13 : Ȩ��ư ���� �ٽ� ���� ���� �� 
										// onSurfaceChanged �޼��尡 �� �� ȣ���� �ȴ�.
										// �׷��� �Ǹ� ������Ʈ���� enter ������ �� �� �Ͼ�� ��
										// ������������ �ߺ��Ǵ� ���� ���� ���� Flag 
	
	public static boolean			m_MusicState;
	
	public static boolean			m_MoveButton;
	
	public static String			m_BackSceneName;
	
	public static int 				m_RankStage;
	
	public HMRenderer(Context context, SensorManager sensorMng)
	{
		EM2DEngine.setContext(context);									// ��ȿ�� - �� �ʿ�!
		EM2DEngine.setAssetMng(context.getResources().getAssets());		// ��ȿ�� - �� �ʿ�!
		EM2DEngine.setSensorMng(sensorMng, SensorManager.SENSOR_DELAY_UI);	// ��ȿ�� - �����̿�
	}

	// ���� ��ġ
	public void onSurfaceCreated(GL10 gl, EGLConfig config)
	{
		m_nWidth = EM2DEngine.getWidth();		// ��ȿ�� - ����̽� ȭ���ػ�
		m_nHeight = EM2DEngine.getHeight();
		
		m_MusicState = true;
		m_MoveButton = false;
		
		m_BackSceneName = "GameMenu";
		
		m_RankStage = 0;
		
		if(EM2DEngine.getRestartFlag())
    	{
    		m_bChangeLoop = false;
    	}
		
		EM2DEngine.D_WORLD.worldInit(gl, m_nWidth, m_nHeight);		// ��ȿ�� - ��ü ���� ȭ�� ����
		EM2DEngine.D_WORLD.setBackColor(gl, new EMColor(0.4f, 0.4f, 0.4f, 1.0f, true));	// 4������ : Alpha, 5������ : clamp
		EM2DEngine.D_WORLD.setLoopState(true);				// ��ȿ�� - GameState ����
		EM2DEngine.D_WORLD.setFpsShowFlag(false);			// FPS Text ��� ����
		EM2DEngine.D_WORLD.setBoundingBoxShowFlag(false);
		EM2DEngine.D_WORLD.setMaxFrame(45.0f);
		//EM2DEngine.D_WORLD.commit(new EMGrid());
		EM2DEngine.D_SCENE.commit(new KGLogo(), "KGLogo");
		EM2DEngine.D_SCENE.commit(new TeamLogo(), "TeamLogo");
		EM2DEngine.D_SCENE.commit(new GameMenu(), "GameMenu");
		EM2DEngine.D_SCENE.commit(new GameCredit(), "GameCredit");
		EM2DEngine.D_SCENE.commit(new ChooseGameMode(), "ChooseGameMode");
		EM2DEngine.D_SCENE.commit(new GameRanking(), "GameRanking");
	

		EM2DEngine.D_SCENE.commit(new GameOver(), "GameOver");
		EM2DEngine.D_SCENE.commit(new StageMenu(), "StageMenu");
					
					
		EM2DEngine.D_SCENE.commit(new RankGame(), "RankGame");
		EM2DEngine.D_SCENE.commit(new TutorGame(), "TutorGame");
				  	
		EM2DEngine.D_SCENE.commit(new Stage01("Stage02",1), "Stage01");
		EM2DEngine.D_SCENE.commit(new Stage02("Stage03",2), "Stage02");
		EM2DEngine.D_SCENE.commit(new Stage03("Stage04",3), "Stage03");
		EM2DEngine.D_SCENE.commit(new Stage04("Stage05",4), "Stage04");
		EM2DEngine.D_SCENE.commit(new Stage05("Stage06",5), "Stage05");
		EM2DEngine.D_SCENE.commit(new Stage06("Stage07",6), "Stage06");
		EM2DEngine.D_SCENE.commit(new Stage07("Stage08",7), "Stage07");
		EM2DEngine.D_SCENE.commit(new Stage08("Stage09",8), "Stage08");
		EM2DEngine.D_SCENE.commit(new Stage09("Stage10",9), "Stage09");
		EM2DEngine.D_SCENE.commit(new Stage10("Stage11",10), "Stage10");
		EM2DEngine.D_SCENE.commit(new Stage11("Stage12",11), "Stage11");
		EM2DEngine.D_SCENE.commit(new Stage12("Stage13",12), "Stage12");
		EM2DEngine.D_SCENE.commit(new Stage13("Stage14",13), "Stage13");
		EM2DEngine.D_SCENE.commit(new Stage14("Stage15",14), "Stage14");
		EM2DEngine.D_SCENE.commit(new Stage15("Stage16",15), "Stage15");
		EM2DEngine.D_SCENE.commit(new Stage16("Stage17",16), "Stage16");
		EM2DEngine.D_SCENE.commit(new Stage17("Stage18",17), "Stage17");
		EM2DEngine.D_SCENE.commit(new Stage18("Stage19",18), "Stage18");
		EM2DEngine.D_SCENE.commit(new Stage19("Stage20",19), "Stage19");
		EM2DEngine.D_SCENE.commit(new Stage20("Stage21",20), "Stage20");
		EM2DEngine.D_SCENE.commit(new Stage21("Stage22",21), "Stage21");
		EM2DEngine.D_SCENE.commit(new Stage22("Stage23",22), "Stage22");
		EM2DEngine.D_SCENE.commit(new Stage23("Stage24",23), "Stage23");
		EM2DEngine.D_SCENE.commit(new Stage24("Stage25",24), "Stage24");
		EM2DEngine.D_SCENE.commit(new Stage25("Stage26",25), "Stage25");
		EM2DEngine.D_SCENE.commit(new Stage26("Stage27",26), "Stage26");
		EM2DEngine.D_SCENE.commit(new Stage27("Stage28",27), "Stage27");
		EM2DEngine.D_SCENE.commit(new Stage28("Stage29",28), "Stage28");
		EM2DEngine.D_SCENE.commit(new Stage29("Stage30",29), "Stage29");
		EM2DEngine.D_SCENE.commit(new Stage30("Stage31",30), "Stage30");
		EM2DEngine.D_SCENE.commit(new Stage31("Stage32",31), "Stage31");
		EM2DEngine.D_SCENE.commit(new Stage32("Stage33",32), "Stage32");
		EM2DEngine.D_SCENE.commit(new Stage33("Stage34",33), "Stage33");
		EM2DEngine.D_SCENE.commit(new Stage34("Stage35",34), "Stage34");
		EM2DEngine.D_SCENE.commit(new Stage35("Stage36",35), "Stage35");
		EM2DEngine.D_SCENE.commit(new Stage36("Stage37",36), "Stage36");
		EM2DEngine.D_SCENE.commit(new Stage37("Stage38",37), "Stage37");
		EM2DEngine.D_SCENE.commit(new Stage38("Stage39",38), "Stage38");
		EM2DEngine.D_SCENE.commit(new Stage39("Stage40",39), "Stage39");
		EM2DEngine.D_SCENE.commit(new Stage40("Stage41",40), "Stage40");
		EM2DEngine.D_SCENE.commit(new Stage41("Stage42",41), "Stage41");
		EM2DEngine.D_SCENE.commit(new Stage42("Stage43",42), "Stage42");
		EM2DEngine.D_SCENE.commit(new Stage43("Stage44",43), "Stage43");
		EM2DEngine.D_SCENE.commit(new Stage44("Stage45",44), "Stage44");
		EM2DEngine.D_SCENE.commit(new Stage45("Stage46",45), "Stage45");
		EM2DEngine.D_SCENE.commit(new Stage46("Stage47",46), "Stage46");
		EM2DEngine.D_SCENE.commit(new Stage47("Stage48",47), "Stage47");
		EM2DEngine.D_SCENE.commit(new Stage48("Stage49",48), "Stage48");
		EM2DEngine.D_SCENE.commit(new Stage49("Stage50",49), "Stage49");
		EM2DEngine.D_SCENE.commit(new Stage50("Stage01",50), "Stage50");
		
		//EM2DEngine.D_SCENE.changeSceneFade("KGLogo");
		
		EM2DEngine.D_CAMERA.setPos(new stEMVec3(0.0f,0.0f,100.0f));		
	}
		
	// ȭ�� ���
	public void onDrawFrame(GL10 gl)
    {
		EM2DEngine.D_WORLD.runLoop(gl);
    }

	// ȭ�� ��ȭ�� ��
    public void onSurfaceChanged(GL10 gl, int w, int h)
    {
    	if(EM2DEngine.getRestartFlag() && !m_bChangeLoop)
    	{
    		m_bChangeLoop = true;
    		EM2DEngine.D_SCENE.setEnterFlag(false);
    	}
    }
}
