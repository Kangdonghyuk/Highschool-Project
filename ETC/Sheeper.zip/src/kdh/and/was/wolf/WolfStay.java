package kdh.and.was.wolf;

import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class WolfStay extends Wolf {
	
	public void CreateWolf(Scene scene, stEMVec2 WolfPos, float WolfRadius,int WolfType, int ID)
	{
		super.CreateWolf(scene, WolfPos, WolfRadius, WolfType, ID);
		
		Shoot();
	}
	
	public void Update(float dt)
	{
		super.Update(dt);
	}
	
	public void Shoot()
	{
		super.Shoot();
	}
	
	public void Grow()
	{
		super.Grow();
	}
	
	public void NGrow()
	{
		super.NGrow();
	}
	
	public void Lose()
	{
		super.Lose();
	}
}
