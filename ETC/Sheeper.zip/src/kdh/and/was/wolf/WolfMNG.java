package kdh.and.was.wolf;

import homi.JEMEngine.EMPlane;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

import java.util.ArrayList;

public class WolfMNG {
	
	public static final int					WOLF = 0;
	public static final int					WOLF_STAY = 1;	
	public static final int					WOLF_GROW = 2;
	public static final int					WOLF_POWER = 3;

	public Scene						m_NowScene;
	
	public ArrayList<Wolf>				m_WolfList;
	
	public int							m_ID;
	public int							m_WolfAllDieNum;
	
	public boolean						m_WolfAllDieState;
	
	public void Enter(Scene scene)
	{
		m_NowScene = scene;
		
		m_WolfList = new ArrayList<Wolf>();
		
		m_ID = 0;
		
		m_WolfAllDieState = false;
		m_WolfAllDieNum = 0;
	}

	public void CreateWolf(stEMVec2 WolfPos, float WolfRadius, int WolfType)
	{
		stEMVec2 _WolfPos = WolfPos;
		float _WolfRadius = WolfRadius;
		
		switch(WolfType)
		{
		case WOLF:
			Wolf _Wolf = new Wolf();
			_Wolf.CreateWolf(m_NowScene, _WolfPos, _WolfRadius,WOLF, m_ID);
			
			m_WolfList.add(_Wolf);
			break;
		case WOLF_STAY:
			WolfStay _WolfStay = new WolfStay();
			_WolfStay.CreateWolf(m_NowScene, _WolfPos, _WolfRadius,WOLF_STAY, m_ID);
			
			m_WolfList.add(_WolfStay);
			break;
		case WOLF_GROW:
			WolfGrow _WolfGrow = new WolfGrow();
			_WolfGrow.CreateWolf(m_NowScene, _WolfPos, _WolfRadius,WOLF_GROW, m_ID);
			
			m_WolfList.add(_WolfGrow);
			break;
		case WOLF_POWER:
			WolfPower _WolfPower = new WolfPower();
			_WolfPower.CreateWolf(m_NowScene, _WolfPos, _WolfRadius,WOLF_POWER, m_ID);
			
			m_WolfList.add(_WolfPower);
			break;
		}
		
		
		m_ID++;
	}

	public void Fight(EMPlane Plane)
	{
		for(int _list = 0; _list < m_WolfList.size(); _list++)
		{
			if(m_WolfList.get(_list).m_Wolf == Plane)
			{
				m_WolfList.get(_list).NGrow();
			}
		}
	}
	
	public void Update(float dt)
	{
		for(int _list = 0; _list < m_WolfList.size(); _list++)
		{
			m_WolfList.get(_list).Update(dt);
			if(m_WolfList.get(_list).m_Wolf.getShow() == false)
			{
				m_WolfAllDieNum++;
				m_NowScene.destroyObject(4, m_WolfList.get(_list).m_Wolf.getName());
				m_WolfList.remove(_list);
				//m_WolfAllDieState = true;
			}
			if(m_WolfAllDieNum == m_ID)
			{
				m_WolfAllDieState = true;
			}
		}
	}
	
	public void OnPause()
	{
		for(int _list = 0; _list < m_WolfList.size(); _list++)
		{
			m_WolfList.get(_list).m_Wolf.moveX(0.0f);
			m_WolfList.get(_list).m_Wolf.moveY(0.0f);
		}
	}
	
	public void OffPause()
	{
		for(int _list = 0; _list < m_WolfList.size(); _list++)
		{
			m_WolfList.get(_list).Shoot();
		}
	}
	
	public int GetWolfDieNum()
	{
		return m_WolfAllDieNum;
	}
	
	public void SetWolfAllDieState()
	{
		m_WolfAllDieState = false;
	}
	
	public boolean GetWolfAllDieState()
	{
		return m_WolfAllDieState;
	}
}
