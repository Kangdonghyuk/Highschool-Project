package kdh.and.was.wolf;

import kdh.and.was.game.RankGame;
import kdh.and.was.game.RootGame;
import kdh.and.was.game.TutorGame;
import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;

public class WolfGrow extends Wolf {
	
	public int				m_GrowTime;
	
	public void CreateWolf(Scene scene, stEMVec2 WolfPos, float WolfRadius,int WolfType, int ID)
	{
		super.CreateWolf(scene, WolfPos, WolfRadius, WolfType, ID);
		
		Shoot();
		
		m_GrowTime = 1000;
	}
	
	public void Update(float dt)
	{		
		super.Update(dt);
		
		int _NowTime;
		if(EM2DEngine.D_SCENE.getChangeSceneName() == "TutorGame")
			_NowTime = TutorGame.m_NowTime;
		else if(EM2DEngine.D_SCENE.getChangeSceneName() == "RankGame")
			_NowTime = RankGame.m_NowTime + 200;
		else
			_NowTime = RootGame.m_NowTime;
		if(m_GrowTime < _NowTime)
		{
			Grow();
			m_GrowTime = _NowTime + 1000;
		}
	}
	
	public void Shoot()
	{
		super.Shoot();
	}
	
	public void Grow()
	{
		super.Grow();
	}
	
	public void NGrow()
	{
		super.NGrow();
	}
	
	public void Lose()
	{
		super.Lose();
	}
}
