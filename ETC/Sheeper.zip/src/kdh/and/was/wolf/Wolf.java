package kdh.and.was.wolf;

import homi.JEMEngine.EM2DEngine;
import homi.JEMEngine.EMAni;
import homi.JEMEngine.EMMath;
import homi.JEMEngine.EMVector.stEMVec2;
import homi.JEMEngine.Scene.Scene;
import kdh.and.was.game.RankGame;
import kdh.and.was.game.RootGame;
import kdh.and.was.game.TutorGame;

import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.BodyType;
import org.jbox2d.dynamics.FixtureDef;

public class Wolf {
	
	public final int			WOLF_NORMAL = 0;
	public final int 			WOLF_FIGHT = 1;
	public final int 			WOLF_WIN = 2;
	
	public final float			WOLF_MAX_SIZE_X = 45.0f;
	public final float			WOLF_MAX_SIZE_Y = 45.0f;
	
	public final float			WOLF_MIN_SIZE_X = 4.0f;
	public final float			WOLF_MIN_SIZE_Y = 4.0f;
	
	public final float			WOLF_ADD_SIZE_X = 0.8f;
	public final float			WOLF_ADD_SIZE_Y = 0.8f;
	
	public final float			WOLF_SUB_SIZE_X = 0.8f;
	public final float			WOLF_SUB_SIZE_Y = 0.8f;
	
	public final int			WOLF_MOVE_DIR_LEFT = 1;
	public final int			WOLF_MOVE_DIR_RIGHT = -1;
	public final int			WOLF_MOVE_DIR_UP = 2;
	public final int			WOLF_MOVE_DIR_DOWN = -2;
	public final int			WOLF_MOVE_DIR_UP_LEFT = 3;
	public final int			WOLF_MOVE_DIR_DOWN_LEFT = -3;
	public final int			WOLF_MOVE_DIR_UP_RIGHT = 4;
	public final int			WOLF_MOVE_DIR_DOWN_RIGHT = -4;
	
	public EMAni				m_Wolf;
	
	public BodyDef				m_bDef;
	public Body					m_Body;
	public CircleShape			m_Shape;
	public FixtureDef			m_FixDef;
	
	public stEMVec2				m_Wolf_Pos;

	public float 				m_Wolf_Speed_X;
	public float				m_Wolf_Speed_Y;
	
	public float				m_Radius;
	
	public int					m_Wolf_Move_Dir;
	public int					m_ID;
	public int					m_WolfType;
	public int 					m_WolfAniType;
	
	public int					m_Wolf_Move_Dir_Change_Time;
	public int 					m_FightTime;
	
	public void CreateWolf(Scene scene, stEMVec2 WolfPos, float WolfRadius,int WolfType, int ID)
	{
		m_ID = ID;
		m_WolfType = WolfType;
	
		m_Radius = WolfRadius;
		
		m_bDef = new BodyDef();
		m_bDef.type = BodyType.DYNAMIC;
		m_bDef.fixedRotation = true;
		m_bDef.position = new Vec2(WolfPos.m_fX,WolfPos.m_fY);
		
		m_Body = scene.getWorldPt().createBody(m_bDef);
		
		m_Shape = new CircleShape();
		m_Shape.m_radius = m_Radius;
		
		m_FixDef = new FixtureDef();
		m_FixDef.shape = m_Shape;
		m_FixDef.density = 1.0f;
		m_FixDef.restitution = 1.0f;
		
		m_Body.createFixture(m_FixDef);
		
		m_Wolf = new EMAni();
		m_Wolf.setCols(3);
		m_Wolf.setRows(3);
		switch(WolfType)
		{
		case WolfMNG.WOLF:
			m_Wolf.setTexture(scene, "image/wolf/wolf_normal.png",
					new stEMVec2(341.2f,335.5f),
					m_Wolf.getCols(),m_Wolf.getRows());
			break;
		case WolfMNG.WOLF_STAY:
			m_Wolf.setTexture(scene, "image/wolf/wolf_stay.png",
					new stEMVec2(341.2f,335.5f),
					m_Wolf.getCols(),m_Wolf.getRows());
			break;
		case WolfMNG.WOLF_GROW:
			m_Wolf.setTexture(scene, "image/wolf/wolf_grow.png",
					new stEMVec2(341.2f,335.5f),
					m_Wolf.getCols(),m_Wolf.getRows());
			break;
		case WolfMNG.WOLF_POWER:
			m_Wolf.setTexture(scene, "image/wolf/wolf_power.png",
					new stEMVec2(341.2f,335.5f),
					m_Wolf.getCols(),m_Wolf.getRows());
			break;
		}
		//m_Wolf.setPos(WolfPos);
		//m_Wolf.setSize(WolfSize);
		m_Wolf.setFrustumCulling(false);
		m_Wolf.setBlend(true);
		m_Wolf.setType(m_WolfType);
		m_Wolf.connectBody(m_Body);
		m_Wolf.setShow(true);
		
		m_Wolf.setMotion(WOLF_NORMAL, 3 ,0.4f, 0,1,2);
		m_Wolf.setMotion(WOLF_FIGHT, 1, 0.4f, 6);
		m_Wolf.setMotion(WOLF_WIN, 3, 0.4f, 3,4,5);
		
		m_Wolf.changeMotion(WOLF_NORMAL);
		
		scene.commit(4,m_ID,"Wolf", m_Wolf);
		
		m_WolfAniType = WOLF_NORMAL;
		
		m_Wolf_Pos = new stEMVec2();
		
		m_Wolf_Move_Dir = WOLF_MOVE_DIR_DOWN;
		m_Wolf_Move_Dir_Change_Time = 500;
		m_FightTime = 0;
		
		m_Wolf_Speed_X = 10.0f;
		m_Wolf_Speed_Y = 10.0f;
		
		float _radius = m_Wolf.getBody().getFixtureList().m_shape.m_radius;
		m_Wolf.getBody().getFixtureList().m_shape.m_radius = _radius - WOLF_SUB_SIZE_X; 
		
		Shoot();
	}
	
	public void Update(float dt)
	{
		
		/*if(Math.abs(m_Wolf.getPosVec2().m_fY) > 100.0f ||
		   Math.abs(m_Wolf.getPosVec2().m_fX) > 60.0f )
		{
			m_Wolf_Move_Dir = -m_Wolf_Move_Dir;
			m_Wolf.setPos(m_Wolf_Pos);
			//m_Wolf_Speed_X = -m_Wolf_Speed_X;
			//m_Wolf_Speed_Y = -m_Wolf_Speed_Y;
		}*/
		
		//m_Wolf_Pos.m_fX = m_Wolf.getPosVec2().m_fX;
		//m_Wolf_Pos.m_fY = m_Wolf.getPosVec2().m_fY;
		
		ChangeMotion();
	}
	
	public void ChangeMotion()
	{
		int _NowTime;
		if(EM2DEngine.D_SCENE.getChangeSceneName() == "TutorGame")
			_NowTime = TutorGame.m_NowTime;
		else if(EM2DEngine.D_SCENE.getChangeSceneName() == "RankGame")
			_NowTime = RankGame.m_NowTime;
		else
			_NowTime = RootGame.m_NowTime;
		if(_NowTime < m_FightTime)
		{
			if(m_WolfAniType != WOLF_FIGHT)
			{
				m_WolfAniType = WOLF_FIGHT;
				m_Wolf.changeMotion(m_WolfAniType);
			}
		}
		else
		{
			if(m_WolfAniType != WOLF_NORMAL)
			{
				m_WolfAniType = WOLF_NORMAL;
				m_Wolf.changeMotion(m_WolfAniType);
			}
		}
	}
	
	public void Shoot()
	{
			int _Dir = EMMath.randomInt(8)-4;
			switch(_Dir)
			{
			case 1:
				m_Wolf_Move_Dir = WOLF_MOVE_DIR_LEFT;
				break;
			case -1:
				m_Wolf_Move_Dir = WOLF_MOVE_DIR_RIGHT;
				break;
			case 2:
				m_Wolf_Move_Dir = WOLF_MOVE_DIR_DOWN;
				break;
			case -2:
				m_Wolf_Move_Dir = WOLF_MOVE_DIR_UP;
				break;
			case 3:
				m_Wolf_Move_Dir = WOLF_MOVE_DIR_UP_LEFT;
				break;
			case -3:
				m_Wolf_Move_Dir = WOLF_MOVE_DIR_DOWN_LEFT;
				break;
			case 4:
				m_Wolf_Move_Dir = WOLF_MOVE_DIR_UP_RIGHT;
				break;
			case -4:
				m_Wolf_Move_Dir = WOLF_MOVE_DIR_DOWN_RIGHT;
				break;
			}
		
		switch(m_Wolf_Move_Dir)
		{
		case WOLF_MOVE_DIR_LEFT:
			m_Wolf_Speed_X = 50.0f;
			m_Wolf_Speed_Y = 0.0f;
			break;
		case WOLF_MOVE_DIR_RIGHT:
			m_Wolf_Speed_X = -50.0f;
			m_Wolf_Speed_Y = 0.0f;
			break;
		case WOLF_MOVE_DIR_UP:
			m_Wolf_Speed_X = 0.0f;
			m_Wolf_Speed_Y = 50.0f;
			break;
		case WOLF_MOVE_DIR_DOWN:
			m_Wolf_Speed_X = 0.0f;
			m_Wolf_Speed_Y = -50.0f;
			break;
		case WOLF_MOVE_DIR_UP_LEFT:
			m_Wolf_Speed_X = -50.0f;
			m_Wolf_Speed_Y = 50.0f;
			break;
		case WOLF_MOVE_DIR_DOWN_LEFT:
			m_Wolf_Speed_X = -50.0f;
			m_Wolf_Speed_Y = -50.0f;
			break;
		case WOLF_MOVE_DIR_UP_RIGHT:
			m_Wolf_Speed_X = 50.0f;
			m_Wolf_Speed_Y = 50.0f;
			break;
		case WOLF_MOVE_DIR_DOWN_RIGHT:
			m_Wolf_Speed_X = 50.0f;
			m_Wolf_Speed_Y = -50.0f;
			break;
		}
		
		m_Wolf.moveX(m_Wolf_Speed_X);
		m_Wolf.moveY(m_Wolf_Speed_Y);
	}
	
	public void Grow()
	{
		stEMVec2 _WolfSize = m_Wolf.getSize();
		
		if(	_WolfSize.m_fX < WOLF_MAX_SIZE_X &&
				_WolfSize.m_fY < WOLF_MAX_SIZE_Y )
		{
			m_Wolf.setSize(new stEMVec2(
					_WolfSize.m_fX + WOLF_ADD_SIZE_X,
					_WolfSize.m_fY + WOLF_ADD_SIZE_Y
					));
		}
	}
	
	public void NGrow()
	{
		stEMVec2 _WolfSize = m_Wolf.getSize();
	
		m_Wolf.setSize(new stEMVec2(
				_WolfSize.m_fX - WOLF_SUB_SIZE_X,
				_WolfSize.m_fY - WOLF_SUB_SIZE_Y
				));
		
		//float radius = m_Wolf.getBody().getFixtureList().m_shape.m_radius;
		//m_Wolf.getBody().getFixtureList().m_shape.m_radius = radius - WOLF_SUB_SIZE_X; 
		
		if(m_Wolf.getSize().m_fX < WOLF_MIN_SIZE_X &&
				m_Wolf.getSize().m_fY < WOLF_MIN_SIZE_Y )
		{
			Lose();
		}
		
		m_FightTime = RootGame.m_NowTime + 400;
	}
	
	public void Lose()
	{
		m_Wolf.getBody().setActive(false);
		m_Wolf.setShow(false);
	}
}
