#include <windows.h>
#include <time.h>

#define DIR_UL 1
#define DIR_UR 2
#define DIR_DR 3
#define DIR_DL 4

#define MIR_CORNER 0
#define MIR_LEFT 1
#define MIR_UP 2
#define MIR_RIGHT 3
#define MIR_DOWN 4

int mx=0, my=0;
int life=100;
int score=0;

struct dot
{
	int x,y;
	int dir;
	int speed;
	dot *next;
};

int chk=0;

dot *head;

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass=TEXT("Mousemove");

int change_dir ( int direct, int code );
BOOL move();
BOOL chk_impact();
COORD VTR ( COORD pos );
COORD RTV ( COORD pos );
COORD PTC ( int x, int y );
BOOL update_mouse ( int x, int y);
BOOL Draw(HDC hdc);
BOOL CREATE();
BOOL init();
BOOL chk_outside();

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_CAPTION | WS_SYSMENU,350,100,560,600,NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while(GetMessage(&Message,NULL,0,0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	RECT a = {20,10,525,535};
	TCHAR str[30];


	switch (iMessage)
	{
		case WM_DESTROY:
			PostQuitMessage(0);
			return 0;
		case WM_CREATE:
			life=1;
			init();
			SetTimer(hWnd,1,100,NULL);
			for(int i=0 ; i<= 100 ; i++ ) CREATE();
			return 0;
		case WM_TIMER:
			if(chk==0)
				return 0;
			score++;

			if(!(score%10))
				for(int i=0; i<=10 ; i++ )CREATE();
			chk_impact();
			move();
			chk_outside();
			if(life==0)
				DestroyWindow(hWnd);
			InvalidateRect(hWnd,NULL,true);
			return 0;
		case WM_MOUSEMOVE:
			update_mouse(LOWORD(lParam),HIWORD(lParam));
			return 0;
		case WM_LBUTTONDOWN:
			chk=1;
			return 0;
		case WM_PAINT:
			hdc = BeginPaint(hWnd,&ps);
			if(chk==0)
			{
				Rectangle(hdc,a.left,a.top,a.right,a.bottom);
				wsprintf(str,L"�����Ϸ��� ���콺�� Ŭ���ϼ���!");
				TextOut(hdc,160,250,str,lstrlen(str));
			}
			else Draw(hdc);
			EndPaint(hWnd,&ps);
			return 0;
	}
 return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}

int change_dir ( int direct, int code )
{
	if( code==MIR_CORNER)
	{
		if(direct==DIR_UL) return DIR_DR;
		if(direct==DIR_UR) return DIR_DL;
		if(direct==DIR_DR) return DIR_UL;
		if(direct==DIR_DL) return DIR_UR;
	}
	if(code==MIR_LEFT)
	{
		if(direct == DIR_UL ) return DIR_UR;
		if(direct == DIR_DL ) return DIR_DR;
	}
	if(code==MIR_UP)
	{
		if(direct == DIR_UR ) return DIR_DR;
		if(direct == DIR_UL ) return DIR_DR;
	}
	if(code==MIR_RIGHT)
	{
		if(direct == DIR_DR ) return DIR_DL;
		if(direct == DIR_UR ) return DIR_UL;
	}
	if(code==MIR_DOWN)
	{
		if(direct == DIR_DL ) return DIR_UL;
		if(direct == DIR_DR ) return DIR_UR;
	}
	return direct;
}
BOOL move()
{
	
	dot *t=head->next;
	for (; t ; t=t->next)
	{
		if( rand() % 100 +1 > t->speed )
			continue;
		if(t->dir==DIR_UL) t->x--, t->y--;
		if(t->dir==DIR_UR) t->x++, t->y--;
		if(t->dir==DIR_DR) t->x++, t->y++;
		if(t->dir==DIR_DL) t->x--, t->y++;
	}
	return 0;
}
BOOL chk_impact()
{
	dot *t = head->next;
	for ( ; t ; t=t->next )
	{
		if( (t->x==mx) && ( t->y==my ) )
			life =0;
	}
	return 0;
}
COORD VTR ( COORD pos )
{
	COORD Newpos={pos.X*5+20,pos.Y*5+30};
	return Newpos;
}
COORD RTV ( COORD pos )
{
	COORD Newpos={(pos.X-20)/5,(pos.Y-30)/5};
	return Newpos;
}
COORD PTC ( int x, int y )
{
	COORD Newpos={x,y};
	return Newpos;
}
BOOL update_mouse ( int x, int y)
{
	COORD t=RTV(PTC(x,y));
	if(t.X<0 || t.Y<0 || t.X > 100 || t.Y > 100 )
		return 0;
	mx=t.X;
	my=t.Y;

	return 0;
}
BOOL Draw(HDC hdc)
{
	TCHAR str2[20];
	wsprintf(str2,L"%02d.%dsec %d:%d",score/10,score%10,mx,my);

	dot *t = head->next;
	Rectangle(hdc,20,30,525,535);
	COORD p;
	for ( ; t ; t=t->next )
	{
		p=VTR(PTC(t->x,t->y));
		Rectangle(hdc,p.X,p.Y,p.X+4,p.Y+4);
	}
	p=VTR(PTC(mx,my));
	Rectangle(hdc,p.X,p.Y,p.X+4,p.Y+4);
	Rectangle(hdc,p.X+1,p.Y+1,p.X+3,p.Y+3);
	TextOut(hdc,20,10,str2,lstrlen(str2));

	return 0;
}

BOOL CREATE()
{
	dot *t = new dot;
	t->x= rand() %99 + 1;
	t->y= rand() %99 + 1;
	t->speed = rand() % 41 + 60;
	t->next = head->next;
	t->dir=rand()%4+1;
	head -> next = t;
	return 0;
}
BOOL init()
{
	head = new dot;
	head->next=NULL;
	srand((unsigned)time(NULL));
	return 0;
}
BOOL chk_outside()
{
	dot *t=head->next;
	for( ; t ; t=t->next )
	{
		if( (t->x==0)   && (t->y==0  ) ) { t->dir=change_dir(t->dir,MIR_CORNER); continue; }
		if( (t->x==0)   && (t->y==100) ) { t->dir=change_dir(t->dir,MIR_CORNER); continue; }
		if( (t->x==100) && (t->y==0)   ) { t->dir=change_dir(t->dir,MIR_CORNER); continue; }
		if( (t->x==100) && (t->y==100) ) { t->dir=change_dir(t->dir,MIR_CORNER); continue; }
		if( t->x==0   ) t->dir = change_dir(t->dir,MIR_LEFT);
		if( t->y==0   ) t->dir = change_dir(t->dir,MIR_UP);
		if( t->x==100 ) t->dir = change_dir(t->dir,MIR_RIGHT);
		if( t->y==100 ) t->dir = change_dir(t->dir,MIR_DOWN);
	}
	return 0;
}