#include "stdafx.h"


CItemFire::CItemFire(void)
{
}


CItemFire::~CItemFire(void)
{
}

void CItemFire::Enter(CSceneGame* scene)
{
	m_pVectorFire = new CVectorFire;
	m_pVectorFire->Enter(scene);

	m_pFire = new CEMPlane;
	m_pFire->SetTexture(scene,"Data/fire.png");
	m_pFire->SetPos(450,0,0);
	m_pFire->SetBlend(true);
	m_pFire->SetShow(true);

	m_pFireAlpha = new CEMPlane;
	m_pFireAlpha->SetTexture(scene,"Data/alpha.png");
	m_pFireAlpha->SetPos(450,0,0);
	m_pFireAlpha->SetSize(0.0f,0.0f);
	m_pFireAlpha->SetBlend(true);
	//m_pFireAlpha->SetAlpha(0.0f);
	m_pFireAlpha->SetShow(true);

	scene->Commit(1,"fire",m_pFire);
	scene->Commit(0,"firealpha",m_pFireAlpha);

	m_bUsingItemState = false;
}

void CItemFire::Update(float dt, int nPassTime)
{
	m_nPassTime = nPassTime;

	if(m_bUsingItemState == true)
	{
		m_pFireAlpha->SetSize(
			stEMVec2(
				m_pFireAlpha->GetSize().m_fX - 0.05f*dt,
				m_pFireAlpha->GetSize().m_fY - 0.05f*dt
				)
			);
		if(m_pFireAlpha->GetSize().m_fX < 0.1f && m_pFireAlpha->GetSize().m_fY < 0.1f)
		{
			m_pFireAlpha->SetSize(0.0f,0.0f);
			m_bUsingItemState = false;
		}
	}

	m_pVectorFire->Update(dt,m_nPassTime);
}

void CItemFire::CreateFire(stEMVec2 stPos)
{
	m_pVectorFire->CreateFire(stPos);
}

void CItemFire::UsingItem()
{
	if(m_bUsingItemState == false)
	{
		m_pFireAlpha->SetSize(1.0f,1.0f);
		m_bUsingItemState = true;
		m_nCoolTime = m_nPassTime + 2000;
	}
}

bool CItemFire::GetUsingState()
{
	if(m_nPassTime > m_nCoolTime)
		return false;
	else
		return true;
}