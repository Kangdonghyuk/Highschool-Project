#include "stdafx.h"

void Credit::Enter(CSceneWork* pSceneWork)
{
	//!=========================================
	//!ī�޶�
	
	D_SOUNDMNG->Commit("EffectBG","Data/Button.wav");
	D_SOUNDMNG->Commit("GameBG","Data/Sleep Away.mp3");
	if(m_bSound==true)
	{
		D_SOUNDMNG->Play("GameBG",true,1.0f);	
	}

	m_Ap=0;
		m_Count=1;

	m_MoveSumX=0;
	m_MoveSumY=0;
	D_CAMERA->SetPos(m_stCamPos);
	//!=====================================================
		m_pBeckGround= new CEMPlane;
		m_pBeckGround->SetSize(1.f, 1.f);
		m_pBeckGround->SetTexture(this,"Data/���1.png");
		m_pBeckGround->SetPos(0.0f,0.0f);
		m_pBeckGround->SetBlend(true);
		m_pBeckGround->SetShow(true);
		Commit(1,"���",m_pBeckGround);

		m_Circle= new CEMPlane;
		m_Circle->SetSize(2.f, 2.f);
		m_Circle->SetTexture(this,"Data/��.png");
		m_Circle->SetPos(0.0f,0.0f);
		m_Circle->SetBlend(true);
		m_Circle->SetShow(false);
		Commit(0,"��",m_Circle);

	m_pBackButten= new CEMPlane;
	m_pBackButten->SetSize(0.5f, 0.5f);
	m_pBackButten->SetTexture(this,"Data/BackButten.png");
	m_pBackButten->SetPos(230.0f,-170.0f);
	m_pBackButten->SetBlend(true);
	m_pBackButten->SetShow(true);
	Commit(0,"�ڷΰ���",m_pBackButten);

	for(int i=0; i<3; i++)
	{
		m_Credit[i] = new CEMPlane;
		m_Credit[i]->SetSize(0.5f,0.5f);
		m_Credit[i]->SetPos(0.0f,0.0f);
		m_Credit[i]->SetBlend(true);
		m_Credit[i]->SetShow(true);
		m_Credit[i]->SetAlpha(0.0f);
	}
	m_Credit[0]->SetTexture(this,"Data/ant.png");
	m_Credit[1]->SetTexture(this,"Data/firefly.png");
	m_Credit[2]->SetTexture(this,"Data/ladybug.png");
	
	Commit(0,"���α׷���",m_Credit[0]);
	Commit(0,"��ȹ",m_Credit[1]);
	Commit(0,"�׷���",m_Credit[2]);
	//===========================================================
	g_ItemPen.Enter(this);

	CRootScene::Enter(pSceneWork);
}
void Credit::Update(CSceneWork* pSceneWork, float dt)
{
	g_ItemPen.SceneUpdate();
	if(m_Count==1)
	{
		if(m_Ap<1.0f)
		{
			m_Ap+=0.025f;
			m_Credit[0]->SetAlpha(m_Ap);
		}
		if(m_Ap>=1.0f)
		{
			m_Credit[0]->SetAlpha(1);	
			m_MoveSumX+=m_MoveX;
			m_MoveSumY+=m_MoveY;
			m_Credit[0]->MoveX(-m_MoveX*80*dt);
			m_Credit[0]->MoveY(m_MoveY*40*dt);
			if(m_MoveSumY>120)
			{
				m_MoveX=0;
				m_MoveY=0;
				if(m_Ap1<1.0f)
				{
					m_Credit[0]->SetSize(1.0f,1.0f);
					m_Credit[0]->SetTexture(this,"Data/������.png");	
					m_Ap1+=0.025f;
					m_Credit[0]->SetAlpha(m_Ap1);
				}
				else
				{
					if(m_Ap2<1.0f)
					{
						m_Ap2+=0.025f;
						m_Credit[0]->SetSize(1.0f,1.0f);
						m_Credit[0]->SetAlpha(m_Ap2);
						m_Credit[0]->SetTexture(this,"Data/������.png");
	
					}
					else
					{
						m_MoveSumX=0;
						m_MoveSumY=0;
						m_Ap=0;
						m_Ap1=0;
						m_Ap2=0;
						m_MoveX=1;
						m_MoveY=1;
						m_Count++;
					}
				}
			}
		}
	}
	if(m_Count==2)
	{
		if(m_Ap<1.0f)
		{
			m_Ap+=0.025f;
			m_Credit[1]->SetAlpha(m_Ap);
		}
		if(m_Ap>=1.0f)
		{
			m_Credit[1]->SetAlpha(1);	
			m_MoveSumX+=m_MoveX;
			m_MoveSumY+=m_MoveY;
			m_Credit[1]->MoveX(m_MoveX*80*dt);
			m_Credit[1]->MoveY(m_MoveY*40*dt);
			if(m_MoveSumY>120)
			{
				m_MoveX=0;
				m_MoveY=0;
				if(m_Ap1<1.0f)
				{
					m_Credit[1]->SetSize(1.0f,1.0f);
					m_Credit[1]->SetTexture(this,"Data/�����.png");	
					m_Ap1+=0.025f;
					m_Credit[1]->SetAlpha(m_Ap1);
				}
				else
				{
					if(m_Ap2<1.0f)
					{
						m_Ap2+=0.025f;
						m_Credit[1]->SetSize(1.0f,1.0f);
						m_Credit[1]->SetAlpha(m_Ap2);
						m_Credit[1]->SetTexture(this,"Data/�����.png");
	
					}
					else
					{
						m_MoveSumX=0;
						m_MoveSumY=0;
						m_Ap=0;
						m_Ap1=0;
						m_Ap2=0;
						m_MoveX=1;
						m_MoveY=1;
						m_Count++;
					}
				}
			}
		}
	}
	if(m_Count==3)
	{
		if(m_Ap<1.0f)
		{
			m_Ap+=0.025f;
			m_Credit[2]->SetAlpha(m_Ap);
		}
		if(m_Ap>=1.0f)
		{
			m_Credit[2]->SetAlpha(1);	
			m_MoveSumX+=m_MoveX;
			m_MoveSumY+=m_MoveY;
			m_Credit[2]->MoveX(m_MoveX*80*dt);
			m_Credit[2]->MoveY(-m_MoveY*40*dt);
		if(m_MoveSumY>120)
			{
				m_MoveX=0;
				m_MoveY=0;
				if(m_Ap1<1.0f)
				{
					m_Credit[2]->SetSize(1.0f,1.0f);
					m_Credit[2]->SetTexture(this,"Data/���Ⱝ.png");	
					m_Ap1+=0.025f;
					m_Credit[2]->SetAlpha(m_Ap1);
				}
				else
				{
					if(m_Ap2<1.0f)
					{
						m_Ap2+=0.025f;
						m_Credit[2]->SetSize(1.0f,1.0f);
						m_Credit[2]->SetAlpha(m_Ap2);
						m_Credit[2]->SetTexture(this,"Data/���Ⱝ.png");
	
					}
					else
					{
						m_MoveSumX=0;
						m_MoveSumY=0;
						m_Ap=0;
						m_Ap1=0;
						m_Ap2=0;
						m_MoveX=1;
						m_MoveY=1;
						m_Count++;
					}
				}
			}
		}
	}
	CEMPlane* pPlane = NULL;
	pPlane = AABBvsRay(D_INPUT->GetMouseMovePos().m_nX, D_INPUT->GetMouseMovePos().m_nY);
	if(pPlane != NULL)
	{
		if(pPlane->GetName()!="�ڷΰ���")
		m_pBackButten->SetSize(1.0f,1.0f);               
	}	
	CRootScene::Update(pSceneWork, dt);
}

void Credit::Render(CSceneWork* pSceneWork)
{


	CRootScene::Render(pSceneWork);
}

void Credit::Exit(CSceneWork* pSceneWork)
{
	Destroy();				//!< ���� ������ �޸� ������ ���� ����
	TwDeleteBar(m_pBar);	//!< ���� ����

	if(D_SOUNDMNG->IsPlay("GameBG") == true)
			D_SOUNDMNG->Stop("GameBG");

	CRootScene::Exit(pSceneWork);
}

void Credit::MouseDownEvent(stMouseInfo stPos, enumMouseButton eButton)
{
	D_SCENE->ChangeSceneFade("GameMenu");
}

void Credit::MouseUpEvent(stMouseInfo stPos, enumMouseButton eButton)
{
 	switch(eButton)
 	{
 	case E_MOUSE_LEFT:
 		{
 			CEMPlane* pPlane = AABBvsRay(stPos.m_nX, stPos.m_nY);
			if(pPlane)
			{
				if(pPlane->GetName()=="�ڷΰ���")
				D_SCENE->ChangeSceneFade("GameMenu",0.05f,0.05f);
			} 
 		}break;
 	}
}

void Credit::MouseMoveEvent(stMouseInfo stPos)
{
	CEMPlane* pPlane = AABBvsRay(stPos.m_nX, stPos.m_nY);
	if(pPlane)
	{
		if(pPlane->GetName()=="�ڷΰ���")
		{
			m_pBackButten->SetSize(1.5f,1.5f);
			if(m_bSound2==true)
			{
				if(m_SoundCount==0)
				{
					D_SOUNDMNG->Play("EffectBG",false,1.f);
					m_SoundCount++;
				}
			}
		}	
		if(pPlane->GetName()!="�ڷΰ���")
		{
			m_SoundCount=0;
		}
	}
}

HRESULT Credit::WindowMessage(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_LBUTTONDOWN:
		{
			int x = 0;
		}break;
	}
	return msg;
}


void Credit::BeginContact(b2Contact* contact)
{
	CEMPhysicRoot::BeginContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���


}

void Credit::EndContact(b2Contact* contact)
{
	CEMPhysicRoot::EndContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void Credit::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
{
	CEMPhysicRoot::PreSolve(contact, oldManifold);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void Credit::PostSolve(const b2Contact* contact, const b2ContactImpulse* impulse)
{
	CEMPhysicRoot::PostSolve(contact, impulse);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

