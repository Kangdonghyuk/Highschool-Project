#include "stdafx.h"


CItemPen::CItemPen(void)
{
}


CItemPen::~CItemPen(void)
{
}

void CItemPen::Enter(KGLogo* scene)
{
	m_pPen = new CEMPlane;
	m_pPen->SetTexture(scene,"Data/���� ��.png");
	m_pPen->SetLocalVec(25.0f,55.0f);
	m_pPen->SetPos(0,0,1);
	m_pPen->SetBlend(true);
	m_pPen->SetSize(1.0f,1.0f);
	m_pPen->SetShow(true);

	scene->Commit(0,"Pen1",m_pPen);
}

void CItemPen::Enter(GameMenu* scene)
{
	m_pPen = new CEMPlane;
	m_pPen->SetTexture(scene,"Data/���� ��.png");
	m_pPen->SetLocalVec(25.0f,45.0f);
	m_pPen->SetPos(0,0,0);
	m_pPen->SetBlend(true);
	m_pPen->SetSize(1.0f,1.0f);
	m_pPen->SetShow(true);

	scene->Commit(0,"Pen2",m_pPen);
}

void CItemPen::Enter(Credit* scene)
{
	m_pPen = new CEMPlane;
	m_pPen->SetTexture(scene,"Data/���� ��.png");
	m_pPen->SetLocalVec(25.0f,55.0f);
	m_pPen->SetPos(0,0,1);
	m_pPen->SetBlend(true);
	m_pPen->SetSize(1.0f,1.0f);
	m_pPen->SetShow(true);

	scene->Commit(0,"Pen3",m_pPen);
}

void CItemPen::Enter(TeamLogo* scene)
{
	m_pPen = new CEMPlane;
	m_pPen->SetTexture(scene,"Data/���� ��.png");
	m_pPen->SetLocalVec(25.0f,55.0f);
	m_pPen->SetPos(0,0,1);
	m_pPen->SetBlend(true);
	m_pPen->SetSize(1.0f,1.0f);
	m_pPen->SetShow(true);

	scene->Commit(0,"Pen4",m_pPen);
}

//void CItemPen::Enter(HowToPlay* scene)
//{
//	m_pPen = new CEMPlane;
//	m_pPen->SetTexture(scene,"Data/���� ��.png");
//	m_pPen->SetLocalVec(25.0f,55.0f);
//	m_pPen->SetPos(0,0,1);
//	m_pPen->SetBlend(true);
//	m_pPen->SetSize(1.0f,1.0f);
//	m_pPen->SetShow(true);
//
//	scene->Commit(0,"Pen5",m_pPen);
//}

void CItemPen::Enter(Rank* scene)
{
	m_pPen = new CEMPlane;
	m_pPen->SetTexture(scene,"Data/���� ��.png");
	m_pPen->SetLocalVec(25.0f,55.0f);
	m_pPen->SetPos(0,0,1);
	m_pPen->SetBlend(true);
	m_pPen->SetSize(1.0f,1.0f);
	m_pPen->SetShow(true);

	scene->Commit(0,"Pen",m_pPen);
}

void CItemPen::Enter(CSceneGame* scene)
{
	D_SOUNDMNG->Commit("LineDrawing","Data/DrawingLine.wav");
	D_SOUNDMNG->Stop("LineDrawing");

	m_pCSceneGame = scene;

	///////////////////////////////////////
	m_pPen = new CEMPlane;
	m_pPen->SetTexture(m_pCSceneGame,"Data/���� ��.png");
	m_pPen->SetLocalVec(25.0f,55.0f);
	m_pPen->SetPos(0,0,0);
	m_pPen->SetBlend(true);
	m_pPen->SetSize(1.0f,1.0f);
	m_pPen->SetShow(true);

	m_pCSceneGame->Commit(0,"Pen",m_pPen);
	/////////////////////////////////////
	for(int i=0; i<E_LINE_MAX; i++)
	{
		m_pPenColor[i] = new CEMPlane;
		m_pPenColor[i]->SetPos(-100 + (i*100),-200,0);
		m_pPenColor[i]->SetSize(1.0f,1.0f);
		m_pPenColor[i]->SetBlend(true);
		m_pPenColor[i]->SetShow(true);

		m_pCSceneGame->Commit(2,i,"PenColor",m_pPenColor[i]);
	}
	m_pPenColor[0]->SetTexture(m_pCSceneGame,"Data/���� ��.png");
	m_pPenColor[1]->SetTexture(m_pCSceneGame,"Data/���繫�� ��.png");
	m_pPenColor[2]->SetTexture(m_pCSceneGame,"Data/������ ��.png");
	//m_pPenColor[3]->SetTexture(m_pCSceneGame,"Data/pen4.png");
	//m_pPenColor[4]->SetTexture(m_pCSceneGame,"Data/pen5.png");

	///////////////////////////////////
	m_pPenColorPoint = new CEMPlane;
	m_pPenColorPoint->SetTexture(m_pCSceneGame,"Data/cpen.png");
	m_pPenColorPoint->SetPos(-200,-180,0);
	m_pPenColorPoint->SetSize(1.0f,1.0f);
	m_pPenColorPoint->SetShow(true);

	m_pCSceneGame->Commit(2,"PenPoint",m_pPenColorPoint);

	///////////////////////////////////
	m_pPenColorPointAni = new CEMAnimation(5);
	m_pPenColorPointAni->SetTexture(m_pCSceneGame,5,"Data/Kg.png","Data/Kg.png","Data/Kg.png",
		"Data/Kg.png","Data/Kg.png");
	m_pPenColorPointAni->SetPos(-200,-180,0);
	m_pPenColorPointAni->SetTime(0.05f);
	m_pPenColorPointAni->SetShow(false);

	//m_pCSceneGame->Commit(2,"PenPointAni",m_pPenColorPointAni);
	//m_pPenColorPointAni->SetLoopType(E_ANI_ONE,E_ANI_ENDING_TYPE_SHOW_FALSE);
	/////////////////////////////////
	m_pVectorLine = new CVectorLine;

	m_pVectorLine->Enter(m_pCSceneGame);

	m_eChoosePen = E_LINE_BLACK;

	/////////////////////////////////////
	m_pFire = new CItemFire;
	m_pAll = new CItemAll;

	m_pFire->Enter(m_pCSceneGame);
	m_pAll->Enter(m_pCSceneGame);
	/////////////////////////////////////
}

void CItemPen::SceneUpdate()
{
	stEMVec2 PenPos;
	PenPos = CEMMath::ScreenToWorld(D_INPUT->GetMouseMovePos().m_nX,
		D_INPUT->GetMouseMovePos().m_nY);
	m_pPen->SetPos(PenPos);
}

void CItemPen::Update(float dt, int nPassTime)
{
	stEMVec2 PenPos;
	PenPos = CEMMath::ScreenToWorld(D_INPUT->GetMouseMovePos().m_nX,
		D_INPUT->GetMouseMovePos().m_nY);
	m_pPen->SetPos(PenPos);

	for(int i=0; i<E_LINE_MAX; i++)
	{
		if(m_pPenColor[i]->GetPosVec2().m_fY > -250)
			m_pPenColor[i]->MoveY(-30.0f*dt);
	}
	m_pPenColorPoint->SetPos(-100 + ((-(m_eChoosePen)-1)*100),
		m_pPenColor[0]->GetPosVec2().m_fY + 10);
	m_pPenColorPointAni->SetPos(m_pPenColorPoint->GetPosVec2());

	m_pVectorLine->Update(dt);
	m_pFire->Update(dt,nPassTime);
	m_pAll->Update(dt,nPassTime);

	if(m_pAll->GetUsingState() == false && m_pFire->GetUsingState() == false)
	{
		switch(m_eChoosePen)
		{
		case E_LINE_BLACK:
			if(m_pPen->GetFileName() != "Data/���� ��.png")
				m_pPen->SetTexture(m_pCSceneGame,"Data/���� ��.png");
			break;
		case E_LINE_RED:
			if(m_pPen->GetFileName() != "Data/���繫�� ��.png")
				m_pPen->SetTexture(m_pCSceneGame,"Data/���繫�� ��.png");
			break;
		case E_LINE_GREEN:
			if(m_pPen->GetFileName() != "Data/������ ��.png")
				m_pPen->SetTexture(m_pCSceneGame,"Data/������ ��.png");
			break;
		}
	}
}

void CItemPen::Render()
{
	m_pVectorLine->Render();
}

void CItemPen::UsingItem(PENITEMTYPE ePenItemType)
{
	switch(ePenItemType)
	{
	case E_PEN_ITEM_FIRE:
		m_pPen->SetTexture(m_pCSceneGame,"Data/��Ÿ�� ��.png");
		m_pFire->UsingItem();
		break;
	case E_PEN_ITEM_ALL:
		m_pPen->SetTexture(m_pCSceneGame,"Data/���� ��.png");
		m_pAll->UsingItem();
		break;
	}
}

void CItemPen::UsingPen()
{
	/*switch(m_eChoosePen)
	{
	case E_LINE_BLACK:
	m_pPen->SetTexture(m_pCSceneGame,"Data/usingpen1.png");
	break;
	case E_LINE_RED:
	m_pPen->SetTexture(m_pCSceneGame,"Data/usingpen2.png");
	break;
	case E_LINE_GREEN:
	m_pPen->SetTexture(m_pCSceneGame,"Data/usingpen3.png");
	break;
	}*/
}

void CItemPen::StopUsingPen()
{
	/*switch(m_eChoosePen)
	{
	case E_LINE_BLACK:
	m_pPen->SetTexture(m_pCSceneGame,"Data/pen1.png");
	break;
	case E_LINE_RED:
	m_pPen->SetTexture(m_pCSceneGame,"Data/pen2.png");
	break;
	case E_LINE_GREEN:
	m_pPen->SetTexture(m_pCSceneGame,"Data/pen3.png");
	break;
	}*/

	D_SOUNDMNG->Stop("LineDrawing");
}

void CItemPen::ClosingPen()
{
	m_pPen->SetShow(false);
}

void CItemPen::ChoosePen(int nLineColor)
{
	switch(nLineColor)
	{
	case E_LINE_BLACK:
		m_pPen->SetTexture(m_pCSceneGame,"Data/���� ��.png");
		break;
	case E_LINE_RED:
		m_pPen->SetTexture(m_pCSceneGame,"Data/���繫�� ��.png");
		break;
	case E_LINE_GREEN:
		m_pPen->SetTexture(m_pCSceneGame,"Data/������ ��.png");
		break;
	}


	for(int i=0; i<E_LINE_MAX; i++)
	{
		m_pPenColor[i]->SetPos(m_pPenColor[i]->GetPosVec2().m_fX,
			-200);
	}

	m_pPenColorPointAni->SetLoopType(E_ANI_ONE,E_ANI_ENDING_TYPE_SHOW_FALSE);

	m_eChoosePen = (LINECOLOR)nLineColor;
}

void CItemPen::CreateLine(stEMVec2 stStart, stEMVec2 stEnd,
	float fLineWidth)
{
	if(abs(stStart.m_fX) < 400 && abs(stStart.m_fY) < 210 &&
		abs(stEnd.m_fX) < 400 && abs(stEnd.m_fY) < 210)
	{
		if(m_pFire->GetUsingState() == false && m_pAll->GetUsingState() == false)
		{
			CEMColor color;

			switch(m_eChoosePen)
			{
			case E_LINE_BLACK:
				color = CEMColor(0.0f,0.0f,0.0f,1.0f);
				break;
			case E_LINE_RED:
				color = CEMColor(1.0f,0.0f,0.0f,1.0f);
				break;
			case E_LINE_GREEN:
				color = CEMColor(0.0f,1.0f,0.0f,1.0f);
				break;
			case E_LINE_BLUE:
				color = CEMColor(0.0f,0.0f,1.0f,1.0f);
				break;
			case E_LINE_WHITE:
				color = CEMColor(1.0f,1.0f,1.0f,1.0f);
				break;
			}
			m_pVectorLine->CreateLine(stStart, stEnd,
				color, fLineWidth,m_eChoosePen);
			if(D_SOUNDMNG->IsPlay("LineDrawing") == false)
				D_SOUNDMNG->Play("LineDrawing",true,1.0f);
		}
		else if(m_pAll->GetUsingState() == true)
		{
			m_pVectorLine->CreateLine(stStart-4, stEnd-4,
				CEMColor(0.0f,0.0f,0.0f), 4.0f,E_LINE_WHITE);
			m_pVectorLine->CreateLine(stStart, stEnd,
				CEMColor(1.0f,0.0f,0.0f), 4.0f,E_LINE_WHITE);
			m_pVectorLine->CreateLine(stStart+4, stEnd+4,
				CEMColor(0.0f,1.0f,0.0f), 4.0f,E_LINE_WHITE);
			//m_pVectorLine->CreateLine(stStart,stEnd,
			//CEMColor(1.0f,1.0f,1.0f,1.0f),5.0f,E_LINE_WHITE);
		}
		else if(m_pFire->GetUsingState() == true)
		{
			m_pFire->CreateFire(stStart);
		}
	}
}

void CItemPen::DeleteLine()
{
	m_pVectorLine->DeleteLine();
}