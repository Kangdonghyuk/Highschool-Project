#include "stdafx.h"


CItemAll::CItemAll(void)
{
}


CItemAll::~CItemAll(void)
{
}

void CItemAll::Enter(CSceneGame* scene)
{
	m_pAll = new CEMPlane;
	m_pAll->SetTexture(scene,"Data/all.png");
	m_pAll->SetPos(450,-100,0);
	m_pAll->SetBlend(true);
	m_pAll->SetShow(true);

	m_pAllAlpha = new CEMPlane;
	m_pAllAlpha->SetTexture(scene,"Data/alpha.png");
	m_pAllAlpha->SetPos(450,-100,0);
	m_pAllAlpha->SetSize(0.0f,0.0f);
	m_pAllAlpha->SetBlend(true);
	m_pAllAlpha->SetShow(true);

	scene->Commit(1,"all",m_pAll);
	scene->Commit(0,"allalpha",m_pAllAlpha);

	m_bUsingItemState = false;
}

void CItemAll::Update(float dt, int nPassTime)
{
	m_nPassTime = nPassTime;

	if(m_bUsingItemState == true)
	{
		m_pAllAlpha->SetSize(
			stEMVec2(
				m_pAllAlpha->GetSize().m_fX - 0.08f*dt,
				m_pAllAlpha->GetSize().m_fY - 0.08f*dt
				)
			);
		if(m_pAllAlpha->GetSize().m_fX < 0.1f && m_pAllAlpha->GetSize().m_fY < 0.1f)
		{
			m_pAllAlpha->SetSize(0.0f,0.0f);
			m_bUsingItemState = false;
		}
	}
}

void CItemAll::UsingItem()
{
	if(m_bUsingItemState == false)
	{
		m_pAllAlpha->SetSize(1.0f,1.0f);
		m_bUsingItemState = true;
		m_nCoolTime = m_nPassTime + 3000;
	}
}

bool CItemAll::GetUsingState()
{
	if(m_nPassTime > m_nCoolTime)
		return false;
	else
		return true;
}
