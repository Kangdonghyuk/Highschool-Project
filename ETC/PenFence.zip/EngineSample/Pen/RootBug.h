#pragma once

#include "stdafx.h"

class CRootBug
{
private:
	CVectorBug* m_pVectorBug;
private:
	BUGNAME m_eBugName;
private:
	int m_nPassTime;
	int m_nSpawnTime;
	int m_nReSpawnTime;
public:
	CRootBug(void);
	~CRootBug(void);
public:
	void Enter(CSceneGame* scene, BUGNAME eBugName, int nReSpawnTime);
	void Update(float dt, int nPassTime);
	void Pause();
public:
	void CreateBug();
	void DeleteBug();
public:
	void SetItmeType(BUGITEMTYPE eBugItemType);
	int GetDieBugNum();
};

