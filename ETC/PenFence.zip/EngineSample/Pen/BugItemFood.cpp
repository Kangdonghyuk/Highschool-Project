#include "stdafx.h"


CBugItemFood::CBugItemFood(void)
{
}


CBugItemFood::~CBugItemFood(void)
{
}

void CBugItemFood::Enter(CSceneGame* scene)
{
	///////////////////////////////////////////////
	m_pFood = new CEMPlane;
	m_pFood->SetTexture(scene,"Data/����.png");
	m_pFood->SetPos(450,100,0);
	m_pFood->SetBlend(true);
	m_pFood->SetShow(true);
	
	m_pFoodAlpha = new CEMPlane;
	m_pFoodAlpha->SetTexture(scene,"Data/alpha.png");
	m_pFoodAlpha->SetPos(450,100,0);
	m_pFoodAlpha->SetSize(0.0f,0.0f);
	m_pFoodAlpha->SetBlend(true);
	//m_pFoodAlpha->SetAlpha(0.0f);
	m_pFoodAlpha->SetShow(true);

	
	scene->Commit(1,"food",m_pFood);
	scene->Commit(0,"foodalpha",m_pFoodAlpha);

	m_nCoolTime = 0;
	m_nPassTime = 0;
	m_bUsingItemState = false;
}

void CBugItemFood::Update(float dt, int  nPassTime)
{
	m_nPassTime = nPassTime;

	if(m_bUsingItemState == true)
	{
		m_pFoodAlpha->SetSize(
			stEMVec2(
				m_pFoodAlpha->GetSize().m_fX - 0.1f*dt,
				m_pFoodAlpha->GetSize().m_fY - 0.1f*dt
				)
			);
		if(m_pFoodAlpha->GetSize().m_fX < 0.1f && m_pFoodAlpha->GetSize().m_fY < 0.1f)
		{
			m_pFoodAlpha->SetSize(0.0f,0.0f);
			m_bUsingItemState = false;
		}
	}
}

void CBugItemFood::UseItem()
{
	if(m_bUsingItemState == false)
	{
		m_pFoodAlpha->SetSize(1.0f,1.0f);
		m_bUsingItemState = true;
		m_nCoolTime = m_nPassTime + 2000;
	}
}

BUGITEMTYPE CBugItemFood::GetUseItem()
{
	if(m_nPassTime > m_nCoolTime)
		return E_BUG_ITEM_NONE;
	else
		return E_BUG_ITEM_FOOD;
}