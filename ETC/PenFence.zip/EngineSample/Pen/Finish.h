#pragma once

#include "stdafx.h"

class CFinish
{
private:
	CSceneGame* m_pCSCeneGame;
private:
	CEMPlane* m_pTitle;
	CEMPlane* m_pNextGameButton;
	CEMPlane* m_pReGameButton;
	CEMPlane* m_pRankGameButton;
private:
	bool m_bButtonClickState;
public:
	CFinish(void);
	~CFinish(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
	void Render();
public:
	void Clear();
	void Fail();
public:
	bool GetFinishState();
};

