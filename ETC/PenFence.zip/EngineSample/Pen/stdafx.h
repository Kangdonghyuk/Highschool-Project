#pragma once


enum VIRTUALKEY_ {
	VK_0 = 0x30, VK_1, VK_2, VK_3, VK_4, VK_5, VK_6, VK_7, VK_8, VK_9,
	VK_A = 0x41, VK_B, VK_C, VK_D, VK_E, VK_F, VK_G, VK_H, VK_I, VK_J, VK_K, VK_L, 
	VK_M, VK_N, VK_O, VK_P, VK_Q, VK_R, VK_S, VK_T, VK_U, VK_V, VK_W, VK_X, VK_Y, VK_Z 
};

enum OBJECTTYPE
{
	E_LINE = 0,
	E_BUG,
	E_FIRE,
	E_ITEM,
	E_LEAF,
};

enum LINECOLOR
{
	E_LINE_BLACK = -1,
	E_LINE_RED = -2,
	E_LINE_GREEN = -3,
	E_LINE_BLUE = -4,
	E_LINE_WHITE = -5,
	E_LINE_MAX = 3,
};

enum BUGNAME
{
	E_ANT = -1,
	E_LADYBUG = -2,
	E_FIREFLY = -3,
	E_BUG_MAX = 3,
};

enum BUGMOVETYPE
{
	E_BUG_MOVE_LEFT = 1,
	E_BUG_MOVE_RIGHT,
	E_BUG_MOVE_UP,
	E_BUG_MOVE_DOWN,
	E_BUG_MOVE_LEFT_UP,
	E_BUG_MOVE_LEFT_DOWN,
	E_BUG_MOVE_RIGHT_UP,
	E_BUG_MOVE_RIGHT_DOWN,
	E_BUG_MOVE_MAX,
};

enum PENITEMTYPE
{
	E_PEN_ITEM_FIRE = 1,
	E_PEN_ITEM_ALL,
};

enum BUGITEMTYPE
{
	E_BUG_ITEM_NONE = 1,
	E_BUG_ITEM_FOOD,
};

enum GAMESTATE
{
	E_GAME_READY = 0,
	E_GAME_PLAY = 1,
	E_GAME_PAUSE,
	E_GAME_CLEAR,
	E_GAME_OVER,
};

#include <vector>

#include "EM2DEngine.h"
#include "UV.h"
////////////////////////////////
#include "TeamLogo.h"
#include "KGLogo.h"
#include "GameMenu.h"
#include "Rank.h"
#include "SceneGame.h"
#include "Credit.h"
#include "HowToPlay.h"
///////////////////////////////
#include "Pause.h"
#include "TimeBar.h"
#include "Score.h"
#include "Finish.h"
#include "BackGround.h"
////////////////////////////////
#include "VectorLine.h"
#include "VectorBug.h"
#include "VectorFire.h"
///////////////////////////////
#include "Leaf.h"
////////////////////////////////
#include "RootBug.h"
////////////////////////////////
#include "ItemFire.h"
#include "ItemAll.h"
#include "ItemPen.h"
///////////////////////////////
#include "BugItemFood.h"
///////////////////////////////
#include "Ant.h"
#include "LadyBug.h"
#include "FireFly.h"
////////////////////////////////
#include "BugMng.h"
////////////////////////////////
#include "EMSound.h"
#include "SoundMNG.h"


#define D_SOUNDMNG CSoundMNG::Instance()

#include <crtdbg.h>
#include <math.h>

extern CItemPen g_ItemPen;

extern int g_nRound;
extern bool m_bSound;
extern bool m_bSound2;
extern int	m_SoundCount;