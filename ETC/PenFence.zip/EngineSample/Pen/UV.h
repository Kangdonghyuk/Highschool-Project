#pragma once

#include "EM2DEngine.h"

class CUV
{
private:
	//!< �̹��� ũ��
	int m_nWidth;
	int m_nHeight;
	//!< UV ���� ��ġ
	int m_nX1;
	int m_nY1;
	//!< UV �� ��ġ
	int m_nX2;
	int m_nY2;

public:
	CUV()
	{
		m_nWidth = 0;
		m_nHeight = 0;
		m_nX1 = 0;
		m_nY1 = 0;
		m_nX2 = 0;
		m_nY2 = 0;
	}
	virtual ~CUV()
	{
		m_nWidth = 0;
		m_nHeight = 0;
		m_nX1 = 0;
		m_nY1 = 0;
		m_nX2 = 0;
		m_nY2 = 0;
	}

public:
	//!< �̹����� ��üũ�� (����, ����)
	void SetUV(int _nW, int _nH)
	{
		m_nWidth = _nW;
		m_nHeight = _nH;
		m_nX1 = 0;
		m_nY1 = 0;
		m_nX2 = _nW;
		m_nY2 = _nH;
	}
	//!< �̹��� ������ġ ���� (X, Y)
	bool SetStartPos(int _nX, int _nY)
	{
		if(_nX >= 0 && _nX <= m_nWidth)
		{
			m_nX1 = _nX;
		}
		else
		{
			return false;
		}

		if(_nY >= 0 && _nY <= m_nHeight)
		{
			m_nY1 = _nY;
		}
		else
		{
			return false;
		}

		return true;
	}
	//!< �̹��� ����ġ ���� (X, Y)
	bool SetEndPos(int _nX, int _nY)
	{
		if(_nX >= m_nX1 && _nX <= m_nWidth)
		{
			m_nX2 = _nX;
		}
		else
		{
			return false;
		}

		if(_nY >= m_nY1 && _nY <= m_nHeight)
		{
			m_nY2 = _nY;
		}
		else
		{
			return false;
		}

		return true;
	}

	stEMVec2 GetUVFirst()
	{
		stEMVec2 stVec2;

		stVec2.m_fX = (float)m_nX1 / m_nWidth;
		stVec2.m_fY = (float)(m_nHeight - m_nY2) / m_nHeight;

		return stVec2;
	}
	stEMVec2 GetUVLast()
	{
		stEMVec2 stVec2;

		stVec2.m_fX = (float)m_nX2 / m_nWidth;
		stVec2.m_fY = (float)(m_nHeight - m_nY1) / m_nHeight;

		return stVec2;
	}
	int GetWidthHalf()
	{
		return (m_nX2 - m_nX1) / 2;
	}
	int GetHeightHalf()
	{
		return (m_nY2 - m_nY1) / 2;
	}
};