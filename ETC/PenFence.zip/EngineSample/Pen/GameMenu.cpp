#include "stdafx.h"

bool	m_bSound;
bool	m_bSound2;
int		m_SoundCount;
void GameMenu::Enter(CSceneWork* pSceneWork)
{
	g_nRound = 3;
	//!ī�޶�
	D_SOUNDMNG->Commit("EffectBG","Data/Button.wav");
	D_SOUNDMNG->Commit("EffectBG2","Data/Button.wav");

	StartPhysic(stEMVec2(0.0f, -50.0f));
	if(m_bSound==true)
	{
		//D_SOUNDMNG->Play("GameBG",true,1.0f);
	}
	else
		D_SOUNDMNG->Stop("GameBG");
	D_CAMERA->SetPos(m_stCamPos);

	//m_Effect[ ] =	new CEMPlane;
	//m_Effect->SetPos( 
	for(m_n1=0; m_n1<4; m_n1++)
	{
		m_pButten[m_n1]= new CEMPlane;
		/*m_pButten[m_n1]->SetOrtho2D(true);*/
		m_pButten[m_n1]->SetSize(1.f, 1.f);
		m_pButten[m_n1]->SetPos(-450.0f+m_n1*90, -130.0f);
		m_pButten[m_n1]->SetBlend(true);
		m_pButten[m_n1]->SetShow(true);
	}
		m_pBackGround= new CEMPlane;
		m_pBackGround->SetSize(1.f, 1.f);
		m_pBackGround->SetTexture(this,"Data/���.png");
		m_pBackGround->SetPos(0.0f,0.0f);
		m_pBackGround->SetBlend(true);
		m_pBackGround->SetShow(true);

		m_pSoundButten= new CEMPlane;
		m_pSoundButten->SetSize(1.f, 1.f);
		m_pSoundButten->SetTexture(this,"Data/�Ҹ�.png");
		m_pSoundButten->SetPos(150.0f,-110.0f);
		m_pSoundButten->SetBlend(true);
		m_pSoundButten->SetShow(true);

		m_pSoundButten2= new CEMPlane;
		m_pSoundButten2->SetSize(1.f, 1.f);
		m_pSoundButten2->SetTexture(this,"Data/�Ҹ�.png");
		m_pSoundButten2->SetPos(200.0f,-110.0f);
		m_pSoundButten2->SetBlend(true);
		m_pSoundButten2->SetShow(true);
		
		m_pBackGround2= new CEMPlane;
		m_pBackGround2->SetSize(1.f, 1.f);
		m_pBackGround2->SetTexture(this,"Data/�޴�.png");
		m_pBackGround2->SetPos(-295.f,-105.f);
		m_pBackGround2->SetBlend(true);
		m_pBackGround2->SetShow(true);
		
		Commit(1,"�޴�1",m_pBackGround2);

	m_pButten[3]->SetTexture(this,"Data/������.png");
	m_pButten[2]->SetTexture(this,"Data/��ŷ.png");
	m_pButten[1]->SetTexture(this,"Data/����.png");
	m_pButten[0]->SetTexture(this,"Data/���ӽ���.png");

	Commit(0,"������",m_pButten[3]);
	Commit(0,"��ŷ",m_pButten[2]);
	Commit(0,"���ӹ��",m_pButten[1]);
	Commit(0,"���ӽ���",m_pButten[0]);
	
	Commit(2,"���",m_pBackGround);
	Commit(0,"�����ư",m_pSoundButten);
	Commit(0,"�����ư2",m_pSoundButten2);
	

	CreateName(0,b2_dynamicBody,stEMVec2(-185.0f,100.0f),stEMVec2(30.0f,40.0f),"Data/P1.png");
	CreateName(1,b2_dynamicBody,stEMVec2(-132.5f,100.0f),stEMVec2(30.0f,40.0f),"Data/E1.png");
	CreateName(2,b2_dynamicBody,stEMVec2(-80.0f,100.0f),stEMVec2(30.0f,40.0f),"Data/N1.png");
	CreateName(3,b2_dynamicBody,stEMVec2(-27.5f,100.0f),stEMVec2(30.0f,40.0f),"Data/F1.png");
	CreateName(4,b2_dynamicBody,stEMVec2(27.5f,100.0f),stEMVec2(30.0f,40.0f),"Data/E1.png");
	CreateName(5,b2_dynamicBody,stEMVec2(80.0f,100.0f),stEMVec2(30.0f,40.0f),"Data/N1.png");
	CreateName(6,b2_dynamicBody,stEMVec2(132.5f,100.0f),stEMVec2(30.0f,40.0f),"Data/C1.png");
	CreateName(7,b2_dynamicBody,stEMVec2(185.0f,100.0f),stEMVec2(30.0f,40.0f),"Data/E1.png");
	CreateName(8,b2_staticBody,stEMVec2(0.0f,10.0f),stEMVec2(200.0f,40.f),"Data/����.png");

	m_pName[8]->SetShow(false);

	g_ItemPen.Enter(this);

	CRootScene::Enter(pSceneWork);
}
void GameMenu::Update(CSceneWork* pSceneWork, float dt)
{
	CEMPlane* pPlane = NULL;
	pPlane = AABBvsRay(D_INPUT->GetMouseMovePos().m_nX, D_INPUT->GetMouseMovePos().m_nY);

	g_ItemPen.SceneUpdate();

	/*m_FS+=m_S;
	m_pButten[0]->MoveZ(-20.f*50*dt);
	if(m_FS>=275)
	{
		m_pButten[0]->MoveZ(20.f*50*dt);
		m_pButten[1]->MoveZ(-20.f*50*dt);
	}
	if(m_FS>=520)
	{
		m_pButten[1]->MoveZ(20.f*50*dt);
		m_pButten[2]->MoveZ(-20.f*50*dt);
	}
	if(m_FS>=760)
	{
		m_pButten[2]->MoveZ(20.f*50*dt);
		m_pButten[3]->MoveZ(-20.f*50*dt);
	}
	if(m_FS>=1000)
	{
		m_pButten[3]->MoveZ(20.f*50*dt);
		
	}*/
	if(m_pName[0]->GetPosVec2().m_fY<=100.0f&&m_pName[1]->GetPosVec2().m_fY<=100.0f&&m_pName[2]->GetPosVec2().m_fY<=100.0f
		&&m_pName[3]->GetPosVec2().m_fY<=100.0f&&m_pName[4]->GetPosVec2().m_fY<=100.0f&&m_pName[5]->GetPosVec2().m_fY<=100.0f
		&&m_pName[6]->GetPosVec2().m_fY<=100.0f&&m_pName[7]->GetPosVec2().m_fY<=100.0f)
	{
		if(m_Count==1)
		{
			m_pName[0]->MoveY(50*50*dt);
			m_pName[1]->MoveY(50*50*dt);	
			m_pName[2]->MoveY(50*50*dt);
			m_pName[3]->MoveY(50*50*dt);
			m_pName[4]->MoveY(50*50*dt);
			m_pName[5]->MoveY(50*50*dt);
			m_pName[6]->MoveY(50*50*dt);
			m_pName[7]->MoveY(50*50*dt);
			m_Count++;
		}
		else if(m_Count==2)
		{
			m_pName[i]->MoveY(50*50*dt);
			m_Count++;
		}
		else if(m_Count==3)
		{
			if(m_pName[i]->GetPosVec2().m_fY<100.0f)
			{
				m_pName[i+1]->MoveY(50*50*dt);
				m_Count++;
			}
		}
		else if(m_Count==4)
		{
			if(m_pName[i+1]->GetPosVec2().m_fY<100.0f)
			{
				m_pName[i+2]->MoveY(50*50*dt);
				m_Count++;
			}
		}
		else if(m_Count==5)
		{
			if(m_pName[i+2]->GetPosVec2().m_fY<100.0f)
			{
				m_pName[i+3]->MoveY(50*50*dt);
				m_Count++;
			}
		}
		else if(m_Count==6)
		{
			if(m_pName[i+3]->GetPosVec2().m_fY<100.0f)
			{
				m_pName[i+4]->MoveY(50*50*dt);
				m_Count++;
			}
		}
		else if(m_Count==7)
		{
			if(m_pName[i+4]->GetPosVec2().m_fY<100.0f)
			{
				m_pName[i+5]->MoveY(50*50*dt);
				m_Count++;
			}
		}
		else if(m_Count==8)
		{
			if(m_pName[i+5]->GetPosVec2().m_fY<100.0f)
			{
				m_pName[i+6]->MoveY(50*50*dt);
				m_Count++;
			}
		}
		else if(m_Count==9)
		{
			if(m_pName[i+6]->GetPosVec2().m_fY<100.0f)
			{
				m_pName[i+7]->MoveY(50*50*dt);	
				m_Count=1;
			}
		}		
	}
	if(pPlane != NULL)
	{
		if(pPlane->GetName() != "������")
		{
			m_pButten[3]->SetSize(1.0f,1.0f);
			m_pButten[3]->SetTexture(this,"Data/������.png");
		}
		if(pPlane->GetName() != "��ŷ")
		{
			m_pButten[2]->SetSize(1.0f,1.0f);
			m_pButten[2]->SetTexture(this,"Data/��ŷ.png");
		}
		if(pPlane->GetName() != "���ӹ��")
		{
			m_pButten[1]->SetSize(1.0f,1.0f);
			m_pButten[1]->SetTexture(this,"Data/����.png");
		}
		if(pPlane->GetName() != "���ӽ���")
		{
			m_pButten[0]->SetSize(1.0f,1.0f);
			m_pButten[0]->SetTexture(this,"Data/���ӽ���.png");
		}
		if(pPlane->GetName() != "�����ư")
		{
			m_pSoundButten->SetTexture(this,"Data/�Ҹ�.png");
		}
		if(pPlane->GetName() != "�����ư2")
		{
			m_pSoundButten2->SetTexture(this,"Data/�Ҹ�.png");
		}
	}
	CRootScene::Update(pSceneWork, dt);
}

void GameMenu::Render(CSceneWork* pSceneWork)
{
	CRootScene::Render(pSceneWork);
}

void GameMenu::Exit(CSceneWork* pSceneWork)
{
	Destroy();				//!< ���� ������ �޸� ������ ���� ����
	TwDeleteBar(m_pBar);	//!< ���� ����

	//if(D_SOUNDMNG->IsPlay("GameBG") == true)
			//D_SOUNDMNG->Stop("GameBG");
	m_FS=0;
	CRootScene::Exit(pSceneWork);
}
void GameMenu::MouseDownEvent(stMouseInfo stPos, enumMouseButton eButton)
{
	switch(eButton)
 	{
 	case E_MOUSE_LEFT:
 		{
 			CEMPlane* pPlane = AABBvsRay(stPos.m_nX, stPos.m_nY);
			if(pPlane)
			{
			
			}
 		}break;
 	}
}

void GameMenu::MouseUpEvent(stMouseInfo stPos, enumMouseButton eButton)
{
 	switch(eButton)
 	{
 	case E_MOUSE_LEFT:
 		{			
			CEMPlane* pPlane = AABBvsRay(stPos.m_nX, stPos.m_nY);
			if(pPlane)
			{
				if(pPlane->GetName()=="���ӽ���")
				{
				if(m_bSound2==true)
					{	
						D_SOUNDMNG->Play("EffectBG2",false,1.f);
					}
					D_SCENE->ChangeSceneFade("Game",0.05f,0.05f);
				}
				if(pPlane->GetName()=="���ӹ��")
				{
				if(m_bSound2==true)
					{	
						D_SOUNDMNG->Play("EffectBG2",false,1.f);
					}
					D_SCENE->ChangeSceneFade("HowToPlay",0.05f,0.05f);
				}
				if(pPlane->GetName()=="��ŷ")
				{
					if(m_bSound2==true)
					{	
						D_SOUNDMNG->Play("EffectBG2",false,1.f);
					}
					D_SCENE->ChangeSceneFade("Rank",0.05f,0.05f);
				}
				if(pPlane->GetName()=="������")
				{
					if(m_bSound2==true)
					{	
						D_SOUNDMNG->Play("EffectBG2",false,1.f);
					}
					D_SCENE->ChangeSceneFade("Credit",0.05f,0.05f);
				}
				if(pPlane->GetName()=="�����ư")
				{
					if(m_bSound==true)
					{
						m_bSound=false;
					}
					else if(m_bSound==false)
					{
						D_SOUNDMNG->Pause("GameBG",false);
						m_bSound=true;
					}
				}
				if(pPlane->GetName()=="�����ư2")
				{
					if(m_bSound2==true)
					{
						m_bSound2=false;
					}
					else if(m_bSound2==false)
					{
						m_bSound2=true;
					}
				}
			}
 		}break;
 	}
}

void GameMenu::MouseMoveEvent(stMouseInfo stPos)
{
	CEMPlane* pPlane = AABBvsRay(stPos.m_nX, stPos.m_nY);
	if(pPlane)
	{
		if(pPlane->GetName()=="���ӽ���")
		{
			m_pButten[0]->SetSize(1.5f,1.5f);
			m_pButten[0]->SetTexture(this,"Data/���ӽ���.png");
			if(m_bSound2==true)
			{
				if(m_SoundCount==0)
				{
					D_SOUNDMNG->Play("EffectBG",false,1.f);
					m_SoundCount++;
				}
			}
		}
		if(pPlane->GetName()=="���ӹ��")
		{
			m_pButten[1]->SetSize(1.5f,1.5f);
			m_pButten[1]->SetTexture(this,"Data/����.png");
			if(m_bSound2==true)
			{
				if(m_SoundCount==0)
				{
					D_SOUNDMNG->Play("EffectBG",false,1.f);
					m_SoundCount++;
				}
			}
		}
		if(pPlane->GetName()=="��ŷ")
		{
			m_pButten[2]->SetSize(1.5f,1.5f);
			m_pButten[2]->SetTexture(this,"Data/��ŷ.png");
			if(m_bSound2==true)
			{
				if(m_SoundCount==0)
				{
					D_SOUNDMNG->Play("EffectBG",false,1.f);
					m_SoundCount++;
				}
			}
		}
		if(pPlane->GetName()=="������")
		{
			m_pButten[3]->SetSize(1.5f,1.5f);
			m_pButten[3]->SetTexture(this,"Data/������.png");
			if(m_bSound2==true)
			{
				if(m_SoundCount==0)
				{
					D_SOUNDMNG->Play("EffectBG",false,1.f);
					m_SoundCount++;
				}
			}
		}
		if(pPlane->GetName() == "�����ư")
		{
			m_pSoundButten->SetTexture(this,"Data/�Ҹ�.png");
			if(m_bSound2==true)
			{
				if(m_SoundCount==0)
				{
					D_SOUNDMNG->Play("EffectBG",false,1.f);
					m_SoundCount++;
				}
			}
		}
		if(pPlane->GetName() == "�����ư2")
		{
			m_pSoundButten2->SetTexture(this,"Data/�Ҹ�.png");
			if(m_bSound2==true)
			{
				if(m_SoundCount==0)
				{
					D_SOUNDMNG->Play("EffectBG",false,1.f);
					m_SoundCount++;
				}
			}
		}
		if(pPlane->GetName()!="������"&&pPlane->GetName()!="���ӽ���"
			&&pPlane->GetName()!="���ӹ��"&&pPlane->GetName()!="�����ư"
			&&pPlane->GetName()!="��ŷ"&&pPlane->GetName()!="�����ư2")
				m_SoundCount=0;
	}
}

HRESULT GameMenu::WindowMessage(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_LBUTTONDOWN:
		{
			int x = 0;
		}break;
	}
	return msg;
}


void GameMenu::BeginContact(b2Contact* contact)
{
	CEMPhysicRoot::BeginContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void GameMenu::EndContact(b2Contact* contact)
{
	CEMPhysicRoot::EndContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}		

void GameMenu::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
{
	CEMPhysicRoot::PreSolve(contact, oldManifold);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void GameMenu::PostSolve(const b2Contact* contact, const b2ContactImpulse* impulse)
{
	CEMPhysicRoot::PostSolve(contact, impulse);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���
	
}
void GameMenu::CreateName(int i,b2BodyType type,stEMVec2 stPos, stEMVec2 stSize, stdEMString sFile)
{
	m_b2Def.type = type;
	m_b2Def.position = b2Vec2(stPos.m_fX, stPos.m_fY);
	m_b2Def.allowSleep = false;
	m_b2Def.fixedRotation = true;
	m_pb2Body = GetWorldPt()->CreateBody(&m_b2Def);

	m_b2Shape.SetAsBox(stSize.m_fX,stSize.m_fY);

	m_pb2Body->CreateFixture(&m_b2Shape,0.0f);


	m_pName[i] = new CEMPlane;
	m_pName[i]->SetBlend(true);
	m_pName[i]->ConnectBody(m_pb2Body);
	m_pName[i]->SetTexture(this,sFile);
	
	Commit(0,i,"����",m_pName[i]);
}