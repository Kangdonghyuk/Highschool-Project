#pragma once

#include "stdafx.h"

class Line
{
private:
	CSceneGame* m_pCSceneGame;
private:
	b2BodyDef m_b2Def;
	b2Body* m_pb2Body;
	b2Filter m_b2Filter;
	b2ChainShape m_b2Shape;
private:
	b2Vec2 m_stArrLinePos[2];
private:
	stEMVec2 m_stStartPos;
	stEMVec2 m_stEndPos;
private:
	CEMColor m_CLineColor;
private:
	float m_fLineWidth;
////////////////////////////////////////
public:
	void CreateLine(stEMVec2 stStart, stEMVec2 stEnd,
		CEMColor color, float fLineWidth);
	void CreateBody(CSceneGame* scene,int MaskBit);
public:
	void DrawLine();
public:
	void DeleteBody();
public:
	void SetLineAlpha(float Alpha);
	float GetLineAlpha();
};

class CVectorLine
{
private:
	CSceneGame* m_pCSceneGame;
private:
	vector<Line*> m_vLine;
	vector<Line*>::iterator m_vLineIt;
public:
	CVectorLine(void);
	~CVectorLine(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt);
	void Render();
public:
	void CreateLine(stEMVec2 stStart, stEMVec2 stEnd,
		CEMColor color, float fLineWidth,int MaskBit);
	void DeleteLine();
};

