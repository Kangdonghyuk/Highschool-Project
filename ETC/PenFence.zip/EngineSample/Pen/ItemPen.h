#pragma once

#include "stdafx.h"

class CItemPen 
{
private:
	CSceneGame* m_pCSceneGame;
private:
	CVectorLine* m_pVectorLine;
	CItemFire* m_pFire;
	CItemAll* m_pAll;
private:
	LINECOLOR m_eChoosePen;
	CEMPlane* m_pPen;
	CEMPlane* m_pPenColor[E_LINE_MAX];
	CEMPlane* m_pPenColorPoint;
	CEMAnimation* m_pPenColorPointAni;
private:
	int m_nPassTime;
public:
	CItemPen(void);
	~CItemPen(void);
public:
	void Enter(KGLogo* scene);
	void Enter(GameMenu* scene);
	void Enter(Credit* scene);
	void Enter(TeamLogo* scene);
	void Enter(Rank* scene);
	/*void Enter(HowToPlay* scene);*/
	void Enter(CSceneGame* scene);
	void SceneUpdate();
	void Update(float dt, int nPassTime);
	void Render();
public:
	void UsingPen();
	void StopUsingPen();
	void ClosingPen();
	void ChoosePen(int nLineColor);
	void UsingItem(PENITEMTYPE ePenItemType);
public:
	void CreateLine(stEMVec2 stStart, stEMVec2 stEnd,
		float fLineWidth = 5.0f);
	void DeleteLine();
};

