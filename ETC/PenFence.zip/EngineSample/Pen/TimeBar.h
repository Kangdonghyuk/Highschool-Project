#pragma once

#include "stdafx.h"

#include "UV.h"

class CTimeBar
{
private:
	CSceneGame* m_pCSceneGame;
private:
	CEMPlane* m_pTimeBar;
	CEMPlane** m_pTime;
	CUV *m_uTime;
private:
	int m_nSecondTime;
	int m_nUvPlaneNum;
	float m_fMaxPlayTime;
private:
	bool m_bFinishTimeState;
public:
	CTimeBar(void);
	~CTimeBar(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
	void Render();
public:
	void SetTime(float nPlayTime = 30.0f);
	void ReTime();
public:
	bool GetFinishTimeState();
public:
	void DrawCilCle();
	void DrawStar();
	void DrawLine(stEMVec2 stPos1, stEMVec2 stPos2);
};

