#include "stdafx.h"

 
CTimeBar::CTimeBar(void)
{
}


CTimeBar::~CTimeBar(void)
{
}

void CTimeBar::Enter(CSceneGame* scene)
{
	m_pCSceneGame = scene;

	m_pTimeBar = new CEMPlane;
	m_pTimeBar->SetTexture(scene,"Data/�ð���2.png");
	m_pTimeBar->SetOrtho2D(true);
	//m_pTimeBar->SetLocalVec(457,-29);
	m_pTimeBar->SetPos(400,40);
	m_pTimeBar->SetSize(1.0f,1.0f);
	m_pTimeBar->SetShow(false);

	/*m_pTime = new CEMPlane;
	m_pTime->SetTexture(scene,"Data/�ð���.png");
	m_pTime->SetOrtho2D(true);
	m_pTime->SetLocalVec(350,-25);
	m_pTime->SetPos(48,20);
	m_pTime->SetSize(1.0f,0.8f);
	m_pTime->SetShow(true);*/
	
	scene->Commit(3,"TimeBar",m_pTimeBar);
	//scene->Commit(2,"Time",m_pTime);

	/////////////////////////////////////////

	m_nSecondTime = 1000;
	m_fMaxPlayTime = 30;

	m_bFinishTimeState = false;
}

void CTimeBar::Update(float dt, int nPassTime)
{
	if(m_nUvPlaneNum < m_fMaxPlayTime)
	{
		m_pTime[0]->SetSize(
			m_pTime[0]->GetSize().m_fX - ((1/m_fMaxPlayTime)*dt),0.8f);
		m_uTime[0].SetEndPos(m_uTime[0].GetUVLast().m_fX - (714/m_fMaxPlayTime),50.0f);
		m_pTime[0]->SetUV(m_uTime[0].GetUVFirst(),m_uTime[0].GetUVLast());
		if(nPassTime > m_nSecondTime)
		{
			//m_pTime[0]->SetShow(false);
			//m_pTime[0]->SetUV(m_uTime[m_nUvPlaneNum].GetUVFirst(),m_uTime[m_nUvPlaneNum].GetUVLast());
			//m_pTime[m_nUvPlaneNum]->SetSize(
			//m_pTime[m_nUvPlaneNum]->GetSize().m_fX - ((1/m_fMaxPlayTime)*dt),0.8f);
			m_nUvPlaneNum++;
			m_nSecondTime = nPassTime + 1000;
		}
	}
	if(m_pTime[0]->GetSize().m_fX <= 0.00f)
		m_bFinishTimeState = true;
	
	//if(m_pTime->GetSize().m_fX <= 0.0f)
		//m_bFinishTimeState = true;
	/*if(nPassTime > m_nSecondTime)
	{
		m_bFinishTimeState = true;
		//m_nSecondTime = 500;
	}*/


}

void CTimeBar::Render()
{
	//DrawCilCle();
}

void CTimeBar::SetTime(float nPlayTime)
{
	m_fMaxPlayTime = nPlayTime;
	//m_nSecondTime = (nPlayTime*1000);

	m_nUvPlaneNum = 0;
	int _NewPlane = m_fMaxPlayTime;

	m_uTime = new CUV[_NewPlane];
	m_pTime = new CEMPlane*[_NewPlane];

	for(int i=0; i<_NewPlane; i++)
	{
		m_uTime[i].SetUV(714,50);
		m_uTime[i].SetStartPos(0.0f,0.0f);
		float xX = 714/_NewPlane;
		m_uTime[i].SetEndPos(714 - (xX * i),50);
	}

	for(int i=0; i<_NewPlane; i++)
	{
		m_pTime[i] = new CEMPlane();
		m_pTime[i]->SetTexture(m_pCSceneGame,"Data/�ð���.png");
		m_pTime[i]->SetOrtho2D(true);
		m_pTime[i]->SetZRot(90.0f);
		m_pTime[i]->SetLocalVec(357,0.0);
		m_pTime[i]->SetUV(m_uTime[i].GetUVFirst(),m_uTime[i].GetUVLast());
		m_pTime[i]->SetPos(48,450);
		m_pTime[i]->SetSize((1/m_fMaxPlayTime)*(_NewPlane - i) - 0.4f,0.8f);
		m_pTime[i]->SetShow(false);

		m_pCSceneGame->Commit(2,i,"Time",m_pTime[i]);
	}
	m_pTime[0]->SetShow(true);
	//m_pTime[0]->SetShow(true);
}

void CTimeBar::ReTime()
{
	//m_pTime->SetSize(1.0f,0.8f);

	m_bFinishTimeState = false;
}

bool CTimeBar::GetFinishTimeState()
{
	return m_bFinishTimeState;
}

void CTimeBar::DrawCilCle()
{
	static int cx = 0;
	static int cy = 0;

	static int angle = 0;

	static int rad = 200;

	int nx, ny;

	//cx++;
	//for(int angle = 0; angle < 360; angle++)
	//{
	nx= cos(angle* 3.14/180) *rad;
	ny= -sin(angle *3.14/180) *rad;

	angle = angle +1;

	if(angle > 360)
		angle = 0;

	//g_ItemPen.AddLine(stEMVec2((cx+nx),(cy+ny)),stEMVec2((cx+nx)+1,(cy+ny)),1,5.0f);
	//}

	DrawLine(stEMVec2(cx,cy),stEMVec2(nx,ny));
}

void CTimeBar::DrawStar()
{
	//DrawLine(stEMVec2(cx,cy),stEMVec2(nx,ny));
}

void CTimeBar::DrawLine(stEMVec2 stPos1, stEMVec2 stPos2)
{
	glPushMatrix();

	glColor4f(1.0f,
		0,
		0,
		1);

	glLineWidth(5.0f);
	glBegin(GL_LINES);

	glVertex2f(stPos1.m_fX, stPos1.m_fY);
	glVertex2f(stPos2.m_fX,stPos2.m_fY);

	glEnd();
	glPopMatrix();
}