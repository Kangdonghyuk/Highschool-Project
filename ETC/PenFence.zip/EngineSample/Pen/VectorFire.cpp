#include "stdafx.h"

void Fire::CreateFire(CSceneGame* scene,stEMVec2 stPos, int nFireNum)
{
	m_pCSceneGame = scene;
	m_nFireNum = nFireNum;

	m_b2Def.type = b2_dynamicBody;
	m_b2Def.position.Set(stPos.m_fX,stPos.m_fY);
	m_b2Def.allowSleep = false;
	m_b2Def.fixedRotation = true;

	m_pb2Body = m_pCSceneGame->GetWorldPt()->
		CreateBody(&m_b2Def);

	m_b2Shape.SetAsBox(10.0f,10.0f);

	m_pb2Body->CreateFixture(&m_b2Shape,0.0f);

	//////////////////////////////////////////////
	m_pFire = new CEMAni;
	m_pFire->SetTexture(m_pCSceneGame,
		"Data/fire.png", stEMVec2(100,100),1,1);
	m_pFire->SetMotion(0,1,0.3f,0);
	m_pFire->SetPos(stPos);
	m_pFire->SetSize(0.3f,0.3f);
	m_pFire->SetBlend(true);
	m_pFire->SetType(E_FIRE);
	m_pFire->ChangeMotion(0);
	m_pFire->ConnectBody(m_pb2Body);

	m_pCSceneGame->Commit(0,m_nFireNum,"Fire",m_pFire);

	m_pFire->SetShow(true);
}

void Fire::UpdateBug(float dt, int nPassTime)
{
	m_pFire->SetAlpha(m_pFire->GetAlpha() - 0.3f*dt);
}

float Fire::GetFireAlpha()
{
	return m_pFire->GetAlpha();
}

CEMPlane* Fire::GetFirePoint()
{
	return m_pFire;
}

CVectorFire::CVectorFire(void)
{
}


CVectorFire::~CVectorFire(void)
{
}

void CVectorFire::Enter(CSceneGame* scene)
{
	m_pCSceneGame = scene;

	m_nFireNum = 0;
}

void CVectorFire::Update(float dt, int nPassTime)
{
	for(m_vFireIt = m_vFire.begin();
		m_vFireIt < m_vFire.end(); )
	{
		(*m_vFireIt)->UpdateBug(dt,nPassTime);

		if((*m_vFireIt)->GetFireAlpha() <= 0.1)
		{
			(*m_vFireIt)->GetFirePoint()->Destroy();
			m_vFireIt = m_vFire.erase(m_vFireIt);
		}
		else
			m_vFireIt++;
	}
}

void CVectorFire::CreateFire(stEMVec2 stPos)
{
	Fire* pFire = new Fire;
	pFire->CreateFire(m_pCSceneGame,stPos,m_nFireNum);

	m_vFire.push_back(pFire);

	m_nFireNum++;
}

void CVectorFire::DeleteFire()
{
	for(m_vFireIt = m_vFire.begin();
		m_vFireIt < m_vFire.end();)
	{
		(*m_vFireIt)->GetFirePoint()->Destroy();
		m_vFireIt = m_vFire.erase(m_vFireIt);
		//m_vBugIt++;
	}

	m_vFire.clear();
}
