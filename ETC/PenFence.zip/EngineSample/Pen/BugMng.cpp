#include "stdafx.h"


CBugMng::CBugMng(void)
{
}


CBugMng::~CBugMng(void)
{
}

void CBugMng::Enter(CSceneGame* scene)
{
	/*m_pBug[0] = new CAnt;
	m_pBug[1] = new CLadyBug;

	m_nDieBugNum = 0;*/

	m_pAnt = new CAnt;
	m_pAnt->Enter(scene);

	//CAnt::Enter(scene);
	m_pLadyBug = new CLadyBug;
	m_pLadyBug->Enter(scene);

	m_pFireFly = new CFireFly;
	m_pFireFly->Enter(scene);
}

void CBugMng::Update(float dt, int nPassTime)
{
	/*int nDieBugNum = 0;
	for(int i=0; i<E_BUG_MAX; i++)
	{
		m_pBug[i]->Update(dt,nPassTime);
		nDieBugNum += m_pBug[i]->GetDieBugNum();
	}

	m_nDieBugNum = nDieBugNum;*/

	m_pAnt->Update(dt,nPassTime);
	//CAnt::Update(dt, nPassTime);
	if(g_nRound >= 2)
		m_pLadyBug->Update(dt, nPassTime);
	if(g_nRound >= 3)
		m_pFireFly->Update(dt,nPassTime);
}

void CBugMng::Pause()
{
	m_pAnt->Pause();
	//CAnt::Pause();
	m_pLadyBug->Pause();
	m_pFireFly->Pause();
}

void CBugMng::DeleteBug()
{
	//for(int i=0; i<E_BUG_MAX; i++)
	//	m_pBug[i]->DeleteBug();

	m_pAnt->DeleteBug();
	//CAnt::DeleteBug();
	m_pLadyBug->DeleteBug();
	m_pFireFly->DeleteBug();
}

void CBugMng::SetItmeType(BUGITEMTYPE eBugItemType)
{
	m_pAnt->SetItmeType(eBugItemType);
	//CAnt::SetItmeType(eBugItemType);
	m_pLadyBug->SetItmeType(eBugItemType);
	m_pFireFly->SetItmeType(eBugItemType);
}

int CBugMng::GetDieBugNum()
{
	return (
		m_pAnt->GetDieBugNum() + 
		//CAnt::GetDieBugNum() + 
		m_pLadyBug->GetDieBugNum() + 
		m_pFireFly->GetDieBugNum()
		);
}