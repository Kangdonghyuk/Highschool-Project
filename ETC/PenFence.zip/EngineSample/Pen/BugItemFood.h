#pragma once

#include "stdafx.h"

class CBugItemFood
{
private:
	CEMPlane* m_pFood;
	CEMPlane* m_pFoodAlpha;
private:
	int m_nCoolTime;
	int m_nPassTime;
private:
	bool m_bUsingItemState;
public:
	CBugItemFood(void);
	~CBugItemFood(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
public:
	void UseItem();
public:
	BUGITEMTYPE GetUseItem();
};

