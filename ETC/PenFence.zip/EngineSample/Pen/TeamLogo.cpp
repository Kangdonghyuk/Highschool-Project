#include "stdafx.h"

void TeamLogo::Enter(CSceneWork* pSceneWork)
{
	//!=====================================================
	TwAddVarRW(m_pBar, "Camera_x", TW_TYPE_FLOAT, &m_stCamPos.m_fX, " label = 'Camera x' min=-1000 max=2500 step=0.1 keyIncr=z keyDecr=Z help = 'Camera x' ");
	TwAddVarRW(m_pBar, "Camera_y", TW_TYPE_FLOAT, &m_stCamPos.m_fY, " label = 'Camera y' min=-1000 max=2500 step=0.1 keyIncr=z keyDecr=Z help = 'Camera y' ");
	TwAddVarRW(m_pBar, "Camera_z", TW_TYPE_FLOAT, &m_stCamPos.m_fZ, " label = 'Camera z' min=-1000 max=2500 step=0.1 keyIncr=z keyDecr=Z help = 'Camera z' ");
	//!=====================================================
	//!ī�޶�	
	D_CAMERA->SetPos(m_stCamPos);
	for(int i=0; i<40; i++)
	{
	  m_Crack[i].SetUV(400,30);;
	  m_Crack[i].SetStartPos(0 + i* 10,0);
	  m_Crack[i].SetEndPos(10 + i* 10,150);

	  m_pCrack[i] = new CEMPlane();
	  m_pCrack[i]->SetTexture(this,"Data/Crack.png");
	  m_pCrack[i]->SetUV(m_Crack[i].GetUVFirst(), m_Crack[i].GetUVLast());
	  m_pCrack[i]->SetSize(stEMVec2(1.2f, 4.0f));
	  m_pCrack[i]->SetPos(-200.0f + i*10.f, 0.0f);
	  m_pCrack[i]->SetTexTureHeightHalfSize(m_Crack[i].GetHeightHalf());
	  m_pCrack[i]->SetTextureWidthHalfSize(m_Crack[i].GetWidthHalf());
	  m_pCrack[i]->SetShow(false);
	  m_pCrack[i]->SetBlend(true);
	
	  Commit(3,i,"�տ�",m_pCrack[i]);
	 }
	//!=====================================================
	//for(m_n1=0; m_n1<4; m_n1++)
	//{
	//	m_pPlane[m_n1]= new CEMPlane;
	//	/*m_pButten[m_n1]->SetOrtho2D(true);*/
	//	
	//	m_pPlane[m_n1]->SetSize(1.f, 1.f);
	//	m_pPlane[m_n1]->SetPos(-200.0f+m_n1*100,0.f);
	//	m_pPlane[m_n1]->SetBlend(true);
	//	m_pPlane[m_n1]->SetShow(false);
	//	
	//}
	//m_pPlane[0]->SetTexture(this,"Data/T.png");
	//m_pPlane[1]->SetTexture(this,"Data/E.png");
	//m_pPlane[2]->SetTexture(this,"Data/A.png");
	//m_pPlane[3]->SetTexture(this,"Data/M.png");

	//
	//Commit(3,"T",m_pPlane[0]);
	//Commit(3,"E",m_pPlane[1]);
	//Commit(3,"A",m_pPlane[2]);
	//Commit(3,"M",m_pPlane[3]);
	//===========================================================
	m_Ant = new CEMPlane;
	m_Ant->SetSize(1.0f,1.0f);
	m_Ant->SetPos(-300.f,0.f);
	m_Ant->SetBlend(true);
	m_Ant->SetShow(true);
	m_Ant->SetTexture(this,"Data/����.png");
	Commit(2,"����",m_Ant);

	m_pBackGround= new CEMPlane;
	m_pBackGround->SetSize(1.f, 1.f);
	m_pBackGround->SetTexture(this,"Data/���.png");
	m_pBackGround->SetPos(0.0f,0.0f);
	m_pBackGround->SetBlend(true);
	m_pBackGround->SetShow(true);



	Commit(4,"���",m_pBackGround);
	
	g_ItemPen.Enter(this);

	CRootScene::Enter(pSceneWork);
}



void TeamLogo::Update(CSceneWork* pSceneWork, float dt)
{

	g_ItemPen.SceneUpdate();

	m_MovSumX+=m_MovX;
	
	m_Ant->MoveX(m_MovX*30*dt);
		
	if(m_Ant->GetPosVec2().m_fX>=-200 && m_Ant->GetPosVec2().m_fX<200)
	{
		if(m_MovSumX%10==0)
		{
			if(i<40)
			{
				m_pCrack[i]->SetShow(true);
				i++;
			}
		}
	}
	if(m_Ant->GetPosVec2().m_fX>=200)
	{
		for(int j=0; j<40; j++)
		{	
			m_pCrack[j]->SetShow(false);
		}

		m_Ant->SetShow(false);
		i=0;
		D_SCENE->ChangeScene("GameMenu");
	}
	CRootScene::Update(pSceneWork, dt);
}	

void TeamLogo::Render(CSceneWork* pSceneWork)
{

	CRootScene::Render(pSceneWork);
}

void TeamLogo::Exit(CSceneWork* pSceneWork)
{
	Destroy();				//!< ���� ������ �޸� ������ ���� ����
	TwDeleteBar(m_pBar);	//!< ���� ����

	CRootScene::Exit(pSceneWork);
}

void TeamLogo::MouseDownEvent(stMouseInfo stPos, enumMouseButton eButton)
{

}

void TeamLogo::MouseUpEvent(stMouseInfo stPos, enumMouseButton eButton)
{
 	switch(eButton)
 	{
 	case E_MOUSE_LEFT:
 		{
 			D_SCENE->ChangeSceneFade("GameMenu",0.05f,0.05f);
 		}break;
 	}
}

void TeamLogo::MouseMoveEvent(stMouseInfo stPos)
{

}

HRESULT TeamLogo::WindowMessage(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_LBUTTONDOWN:
		{
			int x = 0;
		}break;
	}
	return msg;
}


void TeamLogo::BeginContact(b2Contact* contact)
{
	CEMPhysicRoot::BeginContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���


}

void TeamLogo::EndContact(b2Contact* contact)
{
	CEMPhysicRoot::EndContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void TeamLogo::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
{
	CEMPhysicRoot::PreSolve(contact, oldManifold);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void TeamLogo::PostSolve(const b2Contact* contact, const b2ContactImpulse* impulse)
{
	CEMPhysicRoot::PostSolve(contact, impulse);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}