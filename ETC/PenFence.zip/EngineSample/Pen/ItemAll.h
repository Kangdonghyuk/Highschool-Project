#pragma once

#include "stdafx.h"

class CItemAll
{
private:
	CEMPlane* m_pAll;
	CEMPlane* m_pAllAlpha;
private:
	int m_nCoolTime;
	int m_nPassTime;
private:
	bool m_bUsingItemState;
public:
	CItemAll(void);
	~CItemAll(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
public:
	void UsingItem();
public:
	bool GetUsingState();
};

