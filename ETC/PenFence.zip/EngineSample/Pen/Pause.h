#pragma once

#include "stdafx.h"

class CPause
{
private:
	CSceneGame* m_pCSceneGame;
private:
	CEMPlane* m_pPause;
	CEMPlane* m_pBackPause;
	CEMPlane* m_pReGame;
	CEMPlane* m_pMenu;
	CEMPlane* m_pStayGame;
private:
	bool m_bPauseState;
public:
	CPause(void);
	~CPause(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
	void Render();
public:
	void SetPause();
	void RePause();
	bool GetPause();
public:
	void CreateButton(CEMPlane* pPlane,char* pcName,
		char* pnCmName,stEMVec2 stPos,bool bShow);
};

