#include "stdafx.h"

CBugMng g_BugMng;
//CItemPen g_ItemPen;

CPause g_Pause;
CTimeBar g_TimeBar;
CScore g_Score;
CFinish g_Finish;
CBackGround g_BackGround;

CLeaf g_Leaf;

CBugItemFood g_BugItemFood;

int g_nRound;

void CSceneGame::Enter(CSceneWork* pSceneWork)
{
	D_SOUNDMNG->Commit("ClickBG","Data/Button.wav");
//	D_SOUNDMNG->Play("ClickBG");

	StartPhysic(stEMVec2(0.0f,0.0f));

	//////////////////////
	EnterNumber();

	SeeButton = NULL;
	/////////////////////

	m_ulStartTime = GetTickCount();
	m_nPassTime = 0;

	m_bMouseLeftClick = false;
	m_bMouseRightClick = false;

	m_nLineColor = E_LINE_BLACK;

	/////////////////////////////////
	for(int i=0; i<2; i++)
	{
		m_stMousePos[i].m_fX = 0.0f;
		m_stMousePos[i].m_fY = 0.0f;
	}
	////////////////////////////////
	m_pGo = new CEMPlane();
	m_pGo->SetTexture(this,"Data/Go.png");
	m_pGo->SetSize(3.5f,3.5f);
	m_pGo->SetPos(0.0f,0.0f);
	m_pGo->SetBlend(true);
	m_pGo->SetShow(true);

	Commit(0,"Go",m_pGo);
	///////////////////////////////

	g_ItemPen.Enter(this);
	g_BugMng.Enter(this);

	g_Pause.Enter(this);
	g_TimeBar.Enter(this);
	g_TimeBar.SetTime(((g_nRound+1)*2)*10);
	g_Score.Enter(this);
	g_Finish.Enter(this);
	g_BackGround.Enter(this);

	g_Leaf.Enter(this);

	g_BugItemFood.Enter(this);

	m_nEscapeBugNum = 50;
	m_nEscapeBugMaxNum = 0;

	m_eGameState = E_GAME_PLAY;

	CRootScene::Enter(pSceneWork);
}

void CSceneGame::EnterNumber()
{
	m_pEacapeBugNum = new CEMNumber(10);
	m_pEacapeBugNum->SetPos(950.0f, 420.0f, 0.0f);
	m_pEacapeBugNum->SetStyle(E_NUMSTYLE_BASIC);							//!< �ð����� �� ����Ҷ����� E_NUMSTYLE_BASIC�� ��� �Ͻø� �˴ϴ�. ��Ÿ �ٸ� �ɼ��� Update���� ��� ȣ���Ͻø� �����ϴ�.
	m_pEacapeBugNum->SetSize(1.0f, 1.0f);
	m_pEacapeBugNum->SetOrtho2D(true);
	m_pEacapeBugNum->SetTexture(this, 10, 
		"Data/Image/Number/0.png", 
		"Data/Image/Number/1.png", 
		"Data/Image/Number/2.png", 
		"Data/Image/Number/3.png",
		"Data/Image/Number/4.png",
		"Data/Image/Number/5.png",
		"Data/Image/Number/6.png",
		"Data/Image/Number/7.png",
		"Data/Image/Number/8.png",
		"Data/Image/Number/9.png"
		);
	m_pEacapeBugNum->SetShow(true); //���ھ��߰�
	m_pEacapeBugNum->SetNumber(0);

	Commit(2,"EacapeBugNum", m_pEacapeBugNum);
}

void CSceneGame::Update(CSceneWork* pSceneWork, float dt)
{
	/////////////////////////////

	if(m_pGo->GetShow() == true)
	{
		static bool tt = true;
		static int a = 0;
		if(tt == true)
		{
			m_pGo->SetSize(m_pGo->GetSize().m_fX + 0.01f,m_pGo->GetSize().m_fY + 0.01f);
			a++;
			if(a > 30)
				tt = false;
		}
		else if(tt == false)
		{
			m_pGo->SetSize(m_pGo->GetSize().m_fX - 0.03f,m_pGo->GetSize().m_fY - 0.03f);
			m_pGo->SetAlpha(m_pGo->GetAlpha() - 0.009f);
			if(m_pGo->GetAlpha() <= 0.0f)
			{
				m_pGo->SetShow(false);
				tt = true;
				a = 0;
			}
		}
	}
	else if(m_pGo->GetShow() != true)
	{
		g_ItemPen.Update(dt,m_nPassTime);

		switch(m_eGameState)
		{
		case E_GAME_PLAY:
			{
				m_nPassTime = (GetTickCount() - m_ulStartTime);

				g_ItemPen.Update(dt,m_nPassTime);
				g_BugMng.Update(dt,m_nPassTime);

				g_Pause.Update(dt,m_nPassTime);
				g_TimeBar.Update(dt, m_nPassTime);
				g_Score.Update(dt,m_nPassTime);
				g_Finish.Update(dt,m_nPassTime);
				g_BackGround.Update(dt,m_nPassTime);

				g_Leaf.Update(dt,m_nPassTime);

				g_BugItemFood.Update(dt,m_nPassTime);
				////////////////////////////////////////

				g_BugMng.SetItmeType(g_BugItemFood.GetUseItem());   
				m_nEscapeBugMaxNum = m_nEscapeBugNum - g_BugMng.GetDieBugNum();

				//////////////////////////////////////Key
				if(D_INPUT->IsKeyDown(VK_Z))
					g_ItemPen.ChoosePen(-1);
				if(D_INPUT->IsKeyDown(VK_X))
					g_ItemPen.ChoosePen(-2);
				if(D_INPUT->IsKeyDown(VK_C))
					g_ItemPen.ChoosePen(-3);
				////////////////////////////////////////

				if(m_nEscapeBugMaxNum <= 0)
				{
					m_eGameState = E_GAME_OVER;
				}
				if(g_TimeBar.GetFinishTimeState() == true)
				{
					m_eGameState = E_GAME_CLEAR;
				}

				if(g_Leaf.GetChoose() == NULL)
					m_bMouseRightClick = false;
				if(g_Pause.GetPause() == true)
					m_eGameState = E_GAME_PAUSE;
			}break;
		case E_GAME_PAUSE:
			{
				g_BugMng.Pause();
				//D_SOUNDMNG->Pause("GameBG",true);
			}break;
		case E_GAME_CLEAR:
			{
				g_Finish.Clear();
				//D_SOUNDMNG->Pause("GameBG",true);
				//g_nRound+=1;
				//D_SCENE->ChangeScene("Game");
			}break;
		case E_GAME_OVER:
			{
				//D_SCENE->ChangeScene("Rank");
				g_Finish.Fail();
				//D_SCENE->ChangeScene("Game");
			}break;
		}
	}
	D_CAMERA->SetPos(m_stCamPos);
	CRootScene::Update(pSceneWork, dt);
}

void CSceneGame::Render(CSceneWork* pSceneWork)
{
	g_ItemPen.Render();

	g_Pause.Render();
	g_TimeBar.Render();
	g_Score.Render();
	g_Finish.Render();
	g_BackGround.Render();

	g_Leaf.Render();

	m_pEacapeBugNum->SetNumber(m_nEscapeBugMaxNum);

	CRootScene::Render(pSceneWork);
}

void CSceneGame::Exit(CSceneWork* pSceneWork)
{
	g_ItemPen.DeleteLine();
	g_BugMng.DeleteBug();

	Destroy();				//!< ���� ������ �޸� ������ ���� ����

	CRootScene::Exit(pSceneWork);
}

void CSceneGame::MouseDownEvent(stMouseInfo stPos, enumMouseButton eButton)
{
	//if(m_eGameState != E_GAME_READY)
	{
		switch(eButton)
		{
		case E_MOUSE_LEFT:
			{
				if(g_Finish.GetFinishState() == false)
				{
					CEMPlane* now = NULL;
					now = AABBvsRay(stPos.m_nX,stPos.m_nY,1);
					if(now != NULL)
					{
						//if(now->GetType() != 0) /////// ���� �ȵ��´� ������
						//{
						//	g_Leaf.SetChoose(now);
						//}
						now->SetSize(1.0f,1.0f);
						if(now->GetName() == "pause")
							g_Pause.SetPause();
						if(now->GetName() == "movemenu")
						{
							D_SCENE->ChangeSceneFade("GameMenu");
						}
						if(now->GetName() == "regame")
						{
							g_nRound = 0;
							D_SCENE->ChangeScene("Game");;
						}
						if(now->GetName() == "staygame")
						{
							g_Pause.RePause();
							m_eGameState = E_GAME_PLAY;
						}
					}
					g_ItemPen.UsingPen();
					m_stMousePos[0] = CEMMath::ScreenToWorld(D_INPUT->GetMouseMovePos().m_nX,D_INPUT->GetMouseMovePos().m_nY);
					m_stMousePos[1] = CEMMath::ScreenToWorld(D_INPUT->GetMouseMovePos().m_nX,D_INPUT->GetMouseMovePos().m_nY);
					m_bMouseLeftClick = true;
				}
				else
				{
					CEMPlane* now = NULL;
					now = AABBvsRay(stPos.m_nX,stPos.m_nY,1);
					if(now != NULL)
					{
						now->SetSize(1.0f,1.0f);
						if(now->GetName() == "Next")
						{
							g_nRound += 1;
							D_SCENE->ChangeScene("Game");
						}
						else if(now->GetName() == "Re")
						{
							D_SCENE->ChangeScene("Game");
						}
						else if(now->GetName() == "Rank")
						{
							D_SCENE->ChangeScene("Rank");
						}
					}
				}
			}break;
		case E_MOUSE_RIGHT:
			{
				CEMPlane* now = NULL;
				now = AABBvsRay(stPos.m_nX,stPos.m_nY,1);
				if(now != NULL)
				{
					//switch(now->GetType())
					{
						cout<<"a"<<endl;
						//case E_ITEM:
						//{
						now->SetSize(1.0f,1.0f);
						if(now->GetName() == "food")
						{
							g_BugItemFood.UseItem();
							if(m_bSound2==true)
							{
								//D_SOUNDMNG->Play("FoodBG",false,1.0f);
							}
						}
						if(now->GetName() == "fire")
						{
							g_ItemPen.UsingItem(E_PEN_ITEM_FIRE);
							if(m_bSound2==true)
							{
								//D_SOUNDMNG->Play("FireBG",false,1.0f);
							}
						}
						if(now->GetName() == "all")
						{
							g_ItemPen.UsingItem(E_PEN_ITEM_ALL);
							if(m_bSound2==true)
							{
								//D_SOUNDMNG->Play("AllBG",false,1.0f);
							}
						}
						if(now->GetType() == E_LEAF)
						{
							g_Leaf.SetChoose(now);
							if(m_bSound2==true)
							{
								//D_SOUNDMNG->Play("LeafBG",false,1.0f);
							}
							m_bMouseRightClick = true;
						}
						//}break;
						//case E_LEAF:
						//	{
						//	g_Leaf.SetChoose(now);
						//	}break;
					}
					//else
					//now->SetShow(false);
				}
				//m_bMouseRightClick = true;
			}break;
		}
	}
}

void CSceneGame::MouseUpEvent(stMouseInfo stPos, enumMouseButton eButton)
{
	//if(m_eGameState != E_GAME_READY)
	{
		switch(eButton)
		{
		case E_MOUSE_LEFT:
			{
				g_ItemPen.StopUsingPen();
				m_bMouseLeftClick = false;
			}break;
		case E_MOUSE_RIGHT:
			{
				g_Leaf.SetChoose(NULL);
				m_bMouseRightClick = false;
			}break;
		}
	}
}

void CSceneGame::MouseMoveEvent(stMouseInfo stPos)
{
	//if(m_eGameState != E_GAME_READY)
	{
		m_stMousePos[0] = CEMMath::ScreenToWorld
			(D_INPUT->GetMouseMovePos().m_nX,D_INPUT->GetMouseMovePos().m_nY);
		if(m_bMouseLeftClick == true)
		{
			if(m_eGameState == E_GAME_PLAY)
			{
				if(g_Leaf.GetLeafState() == false)
				{
					g_ItemPen.UsingPen();
					g_ItemPen.CreateLine(m_stMousePos[0],m_stMousePos[1]);
				}
			}

			m_stMousePos[1] = CEMMath::ScreenToWorld
				(D_INPUT->GetMouseMovePos().m_nX,D_INPUT->GetMouseMovePos().m_nY);
		}
		if(m_bMouseRightClick == true)
		{
			if(g_Leaf.GetChoose() != NULL)
			{
				g_Leaf.SetLeafPos(m_stMousePos[0]);
			}
		}

		CEMPlane* now = NULL;
		now = AABBvsRay(D_INPUT->GetMouseMovePos().m_nX,D_INPUT->GetMouseMovePos().m_nY,1);
		if(now != NULL)
		{
			//if(D_SOUNDMNG->IsPlay("ClickBG") == false)
				//D_SOUNDMNG->Play("ClickBG",false);
			now->SetSize(1.2f,1.2f);
			SeeButton = now;
		}
		else
		{
			if(SeeButton != NULL)
			{
				//D_SOUNDMNG->Stop("EffectBG");
				SeeButton->SetSize(1.0f,1.0f);
				SeeButton = NULL;
				return ;
			}
			//D_SOUNDMNG->Stop("EffectBG");
			//nnow = NULL;
		}
	}
}

HRESULT CSceneGame::WindowMessage(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_MOUSEWHEEL:
		{
			if((short)HIWORD(wParam) > 0)
			{
				m_nLineColor--;
				if(m_nLineColor < E_LINE_GREEN)
					m_nLineColor = E_LINE_BLACK;
			}
			else if((short)HIWORD(wParam) < 0)
			{
				m_nLineColor++;
				if(m_nLineColor > E_LINE_BLACK)
					m_nLineColor = E_LINE_GREEN;

			}
			g_ItemPen.ChoosePen(m_nLineColor);
			//int x = 0;
		}break;
	}

	return msg;
}


void CSceneGame::BeginContact(b2Contact* contact)
{
	CEMPhysicRoot::BeginContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���


}

void CSceneGame::EndContact(b2Contact* contact)
{
	CEMPhysicRoot::EndContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void CSceneGame::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
{
	CEMPhysicRoot::PreSolve(contact, oldManifold);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void CSceneGame::PostSolve(const b2Contact* contact, const b2ContactImpulse* impulse)
{
	CEMPhysicRoot::PostSolve(contact, impulse);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}