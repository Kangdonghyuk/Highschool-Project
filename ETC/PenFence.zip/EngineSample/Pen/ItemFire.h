#pragma once

#include "stdafx.h"

class CItemFire
{
private:
	CVectorFire* m_pVectorFire;
private:
	CEMPlane* m_pFire;
	CEMPlane* m_pFireAlpha;
private:
	int m_nCoolTime;
	int m_nPassTime;
private:
	bool m_bUsingItemState;
public:
	CItemFire(void);
	~CItemFire(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
public:
	void CreateFire(stEMVec2 stPos);
public:
	void UsingItem();
public:
	bool GetUsingState();
};

