#include "stdafx.h"


CLadyBug::CLadyBug(void)
{
}


CLadyBug::~CLadyBug(void)
{
}

void CLadyBug::Enter(CSceneGame* scene)
{
	m_pBug = new CRootBug;
	m_pBug->Enter(scene,E_LADYBUG,1500);
}

void CLadyBug::Update(float dt, int nPassTime)
{
	m_pBug->Update(dt, nPassTime);
}

void CLadyBug::Pause()
{
	m_pBug->Pause();
}

void CLadyBug::CreateBug()
{
	m_pBug->CreateBug();
}

void CLadyBug::DeleteBug()
{
	m_pBug->DeleteBug();
}

void CLadyBug::SetItmeType(BUGITEMTYPE eBugItemType)
{
	m_pBug->SetItmeType(eBugItemType);
}


int CLadyBug::GetDieBugNum()
{
	return m_pBug->GetDieBugNum();
}
