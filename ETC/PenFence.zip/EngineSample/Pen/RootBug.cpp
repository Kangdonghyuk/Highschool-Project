#include "stdafx.h"


CRootBug::CRootBug(void)
{
}


CRootBug::~CRootBug(void)
{
}

void CRootBug::Enter(CSceneGame* scene, BUGNAME eBugName, int nReSpawnTime)
{
	m_pVectorBug = new CVectorBug;

	m_eBugName = eBugName;

	m_nReSpawnTime = nReSpawnTime;
	m_nSpawnTime = m_nReSpawnTime;

	m_pVectorBug->Enter(scene,m_eBugName);
}

void CRootBug::Update(float dt, int nPassTime)
{
	m_nPassTime = nPassTime;

	m_pVectorBug->Update(dt,m_nPassTime);

	if(m_nPassTime > m_nSpawnTime)
	{
		CreateBug();
		m_nSpawnTime = m_nPassTime + m_nReSpawnTime;
	}
}

void CRootBug::Pause()
{
	m_pVectorBug->Pause();
}

void CRootBug::CreateBug()
{
	m_pVectorBug->CreateBug();
}

void CRootBug::DeleteBug()
{
	m_pVectorBug->DeleteBug();
}

void CRootBug::SetItmeType(BUGITEMTYPE eBugItemType)
{
	m_pVectorBug->SetBugItemType(eBugItemType);
}

int CRootBug::GetDieBugNum()
{
	return m_pVectorBug->GetDieBugNum();
}
