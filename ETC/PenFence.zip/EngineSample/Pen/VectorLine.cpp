#include "stdafx.h"

void Line::CreateLine(stEMVec2 stStart, stEMVec2 stEnd,
	CEMColor color, float fLineWidth)
{
	m_stStartPos = stStart;
	m_stEndPos = stEnd;

	m_stArrLinePos[0] = b2Vec2(m_stStartPos.m_fX,
		m_stStartPos.m_fY);
	m_stArrLinePos[1] = b2Vec2(m_stEndPos.m_fX,
		m_stEndPos.m_fY);

	m_CLineColor = color;

	m_fLineWidth = fLineWidth;
}

void Line::CreateBody(CSceneGame* scene, int MaskBit)
{
	m_pCSceneGame = scene;

	m_b2Def.position.Set(0.0f, 0.0f);

	m_pb2Body = m_pCSceneGame->GetWorldPt()->
		CreateBody(&m_b2Def);

	m_b2Shape.CreateChain(m_stArrLinePos,2);

	m_b2Filter.groupIndex = MaskBit;

	m_pb2Body->CreateFixture(&m_b2Shape,0.0f);

	m_pb2Body->GetFixtureList()->SetFilterData(m_b2Filter);
}

void Line::DrawLine()
{
	glPushMatrix();

	glColor4f(m_CLineColor.m_fR,
		m_CLineColor.m_fG,
		m_CLineColor.m_fB,
		m_CLineColor.m_fA);

	glLineWidth(m_fLineWidth);
	glBegin(GL_LINES);

	glVertex2f(m_stStartPos.m_fX, m_stStartPos.m_fY);
	glVertex2f(m_stEndPos.m_fX,m_stEndPos.m_fY);

	glEnd();
	glPopMatrix();
}

void Line::DeleteBody()
{
	m_pCSceneGame->GetWorldPt()->
		DestroyBody(m_pb2Body);
}

void Line::SetLineAlpha(float Alpha)
{
	m_CLineColor.m_fA -= Alpha;
}

float Line::GetLineAlpha()
{
	return m_CLineColor.m_fA;
}

//////////////////////////////////////////////

CVectorLine::CVectorLine(void)
{
}


CVectorLine::~CVectorLine(void)
{
}

void CVectorLine::Enter(CSceneGame* scene)
{
	m_pCSceneGame = scene;
}

void CVectorLine::Update(float dt)
{
	for(m_vLineIt = m_vLine.begin();
		m_vLineIt < m_vLine.end();)
	{
		if((*m_vLineIt)->GetLineAlpha() <= 0.1f)
		{
			(*m_vLineIt)->DeleteBody();
			m_vLineIt = m_vLine.erase(m_vLineIt);
		}
		else
		{
			(*m_vLineIt)->SetLineAlpha(0.008f);
			m_vLineIt++;
		}
	}
}

void CVectorLine::Render()
{
	for(m_vLineIt = m_vLine.begin();
		m_vLineIt < m_vLine.end(); )
	{
		(*m_vLineIt)->DrawLine();
		m_vLineIt++;
	}
}

void CVectorLine::CreateLine(stEMVec2 stStart, stEMVec2 stEnd,
		CEMColor color, float fLineWidth,int MaskBit)
{
	Line* pLine = new Line;
	pLine->CreateLine(stStart,stEnd,color,
		fLineWidth);
	pLine->CreateBody(m_pCSceneGame,MaskBit);

	m_vLine.push_back(pLine);
}

void CVectorLine::DeleteLine()
{
	for(m_vLineIt = m_vLine.begin();
		m_vLineIt < m_vLine.end();)
	{
		(*m_vLineIt)->DeleteBody();
		m_vLineIt++;
	}

	m_vLine.clear();
}