#include "stdafx.h"


CBackGround::CBackGround(void)
{
}


CBackGround::~CBackGround(void)
{
}

void CBackGround::Enter(CSceneGame* scene)
{
	m_pBackGround = new CEMPlane;
	m_pBackGround->SetTexture(scene,"Data/BackGround.png");
	m_pBackGround->SetPos(0.0f,0.0f,-1.0f);
	m_pBackGround->SetSize(1.0f,1.0f);
	m_pBackGround->SetBlend(true);
	m_pBackGround->SetShow(true);

	scene->Commit(10,"back",m_pBackGround);
}

void CBackGround::Update(float dt, int nPassTime)
{
}

void CBackGround::Render()
{
}

