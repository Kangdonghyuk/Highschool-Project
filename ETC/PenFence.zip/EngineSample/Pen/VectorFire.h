#pragma once

#include "stdafx.h"

class Fire
{
private:
	CSceneGame* m_pCSceneGame;
private:
	//CEMPlane* m_pFire;
	CEMAni* m_pFire;
private:
	b2BodyDef m_b2Def;
	b2Body* m_pb2Body;
	b2PolygonShape m_b2Shape;
private:
	int m_nFireNum;
public:
	void CreateFire(CSceneGame* scene, stEMVec2 stPos, int nFireNum);
	void UpdateBug(float dt, int nPassTime);
public:
	float  GetFireAlpha();
	CEMPlane* GetFirePoint();
};

class CVectorFire
{
private:
	CSceneGame* m_pCSceneGame;
private:
	vector<Fire*> m_vFire;
	vector<Fire*>::iterator m_vFireIt;
private:
	int m_nFireNum;
public:
	CVectorFire(void);
	~CVectorFire(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
public:
	void CreateFire(stEMVec2 stPos);
	void DeleteFire();
};

