#include "stdafx.h"


CPause::CPause(void)
{
}


CPause::~CPause(void)
{
}

void CPause::Enter(CSceneGame* scene)
{
	m_pCSceneGame = scene;

	//D_SOUNDMNG->Commit("PauseBG","Data/FenceBug.mp3");
	//D_SOUNDMNG->Commit("GameBG","Data/FenceBug.mp3");

	//if(m_bSound==true)
		//D_SOUNDMNG->Play("GameBG",false,1.f);


	m_pPause = new CEMPlane;
	m_pPause->SetTexture(scene,"Data/�Ͻ�����.png");
	m_pPause->SetPos(450.0f,200.0f);
	m_pPause->SetSize(1.0f,1.0f);
	m_pPause->SetBlend(true);
	m_pPause->SetShow(true);


	
	scene->Commit(1,"pause",m_pPause);
	////////////////����
	//CreateButton(m_pPause,"Data/pause.png","pause",stEMVec2(400.0f,200.0f),true);
	//CreateButton(m_pBackPause,"Data/backpause.png","backpause",stEMVec2(0.0f,0.0f),false);
	//CreateButton(m_pReGame,"Data/regame.png","regame",stEMVec2(-100.0f,0.0f),false);
	//CreateButton(m_pStayGame,"Data/staygame.png","staygame",stEMVec2(100.0f,0.0f),false);

	m_pBackPause = new CEMPlane;
	m_pBackPause->SetTexture(scene,"Data/backpause.png");
	m_pBackPause->SetPos(0.0f,0.0f);
	m_pBackPause->SetSize(1.0f,1.0f);
	m_pBackPause->SetBlend(true);
	m_pBackPause->SetShow(false);

	scene->Commit(0,"backpause",m_pBackPause);

	m_pReGame = new CEMPlane;
	m_pReGame->SetTexture(scene,"Data/�ٽ��ϱ�.png");
	m_pReGame->SetPos(-100.0f,0.0f);
	m_pReGame->SetSize(1.0f,1.0f);
	m_pReGame->SetBlend(true);
	m_pReGame->SetShow(false);

	scene->Commit(1,"regame",m_pReGame);

	m_pStayGame = new CEMPlane;
	m_pStayGame->SetTexture(scene,"Data/����ϱ�.png");
	m_pStayGame->SetPos(100.0f,0.0f);
	m_pStayGame->SetSize(1.0f,1.0f);
	m_pStayGame->SetBlend(true);
	m_pStayGame->SetShow(false);

	scene->Commit(1,"staygame",m_pStayGame);

	m_pMenu = new CEMPlane;
	m_pMenu->SetTexture(scene,"Data/���θ޴�.png");
	m_pMenu->SetPos(0.0f,0.0f);
	m_pMenu->SetSize(1.0f,1.0f);
	m_pMenu->SetBlend(true);
	m_pMenu->SetShow(false);

	scene->Commit(1,"movemenu",m_pMenu);

	m_bPauseState = false;
}

void CPause::Update(float dt, int nPassTime)
{
	//D_SOUNDMNG->Play("PauseBG",false,1.f);
}

void CPause::Render()
{
}

void CPause::SetPause()
{
	m_pBackPause->SetShow(false);
	m_pReGame->SetShow(true);
	m_pStayGame->SetShow(true);
	m_pMenu->SetShow(true);
	m_bPauseState = true;
}

void CPause::RePause()
{
	m_pBackPause->SetShow(false);
	m_pReGame->SetShow(false);
	m_pStayGame->SetShow(false);
	m_pMenu->SetShow(false);
	m_bPauseState = false;
}

bool CPause::GetPause()
{
	return m_bPauseState;
}

void CPause::CreateButton(CEMPlane* pPlane,char* pcName,
		char* pnCmName,stEMVec2 stPos,bool bShow)
{
	pPlane = new CEMPlane;
	pPlane->SetTexture(m_pCSceneGame,pcName);
	pPlane->SetPos(stPos);
	pPlane->SetSize(1.0f,1.0f);
	pPlane->SetBlend(true);
	pPlane->SetShow(bShow);

	m_pCSceneGame->Commit(0,pnCmName,pPlane);
}

