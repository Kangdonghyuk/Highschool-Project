#include "stdafx.h"


CFireFly::CFireFly(void)
{
}


CFireFly::~CFireFly(void)
{
}

void CFireFly::Enter(CSceneGame* scene)
{
	m_pBug = new CRootBug;
	m_pBug->Enter(scene,E_FIREFLY,1800);
}

void CFireFly::Update(float dt, int nPassTime)
{
	m_pBug->Update(dt,nPassTime);
}

void CFireFly::Pause()
{
	m_pBug->Pause();
}

void CFireFly::CreateBug()
{
	m_pBug->CreateBug();
}

void CFireFly::DeleteBug()
{
	m_pBug->DeleteBug();
}

void CFireFly::SetItmeType(BUGITEMTYPE eBugItemType)
{
	m_pBug->SetItmeType(eBugItemType);
}

int CFireFly::GetDieBugNum()
{
	return m_pBug->GetDieBugNum();
}
