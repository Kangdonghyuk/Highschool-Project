#pragma once

#include "stdafx.h"

class CLeaf
{
private:
	//CEMPlane* m_pLeaf[5];
	CEMPlane* m_pLeaf;
	CEMPlane* m_pChoLeaf;
private:
	int m_nReTime;
	int m_nReAddTime;
	bool m_bLeafState;
public:
	CLeaf(void);
	~CLeaf(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
	void Render();
public:
	void SetChoose(CEMPlane* pLeaf);
	CEMPlane*  GetChoose();
	void SetLeafPos(stEMVec2 stPos);
	bool GetLeafState();
};

