#pragma once

#include "stdafx.h"

class CAnt : public CRootBug
{
private:
	CRootBug* m_pBug;
public:
	CAnt(void);
	~CAnt(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
	void Pause();
public:
	void CreateBug();
	void DeleteBug();
public:
	void SetItmeType(BUGITEMTYPE eBugItemType);
	int GetDieBugNum();
};

