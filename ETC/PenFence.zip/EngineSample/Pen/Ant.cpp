#include "stdafx.h"


CAnt::CAnt(void)
{
}


CAnt::~CAnt(void)
{
}

void CAnt::Enter(CSceneGame* scene)
{
	m_pBug = new CRootBug;
	m_pBug->Enter(scene,E_ANT,1000);
	//CRootBug::Enter(scene,E_ANT,1000);
}

void CAnt::Update(float dt, int nPassTime)
{
	m_pBug->Update(dt,nPassTime);
	//CRootBug::Update(dt, nPassTime);
}

void CAnt::Pause()
{
	m_pBug->Pause();
	//CRootBug::Pause();
}

void CAnt::CreateBug()
{
	m_pBug->CreateBug();
	//CRootBug::CreateBug();
}

void CAnt::DeleteBug()
{
	m_pBug->DeleteBug();
	//CRootBug::DeleteBug();
}

void CAnt::SetItmeType(BUGITEMTYPE eBugItemType)
{
	m_pBug->SetItmeType(eBugItemType);
	//CRootBug::SetItmeType(eBugItemType);
}

int CAnt::GetDieBugNum()
{
	return m_pBug->GetDieBugNum();
	//return CRootBug::GetDieBugNum();
}
