#include "stdafx.h"


CFinish::CFinish(void)
{
}


CFinish::~CFinish(void)
{
}

void CFinish::Enter(CSceneGame* scene)
{
	m_pCSCeneGame = scene;

	m_pTitle = new CEMPlane;
	m_pTitle->SetTexture(scene,"Data/clear.png");
	m_pTitle->SetPos(0,0);
	m_pTitle->SetShow(false);

	m_pNextGameButton = new CEMPlane;
	m_pNextGameButton->SetTexture(scene,"Data/����ϱ�.png");
	m_pNextGameButton->SetPos(100,-50);
	m_pNextGameButton->SetShow(false);

	m_pReGameButton = new CEMPlane;
	m_pReGameButton->SetTexture(scene,"Data/�ٽ��ϱ�.png");
	m_pReGameButton->SetPos(-100,-50);
	m_pReGameButton->SetShow(false);

	scene->Commit(2,"Title",m_pTitle);
	scene->Commit(1,"Next",m_pNextGameButton);
	scene->Commit(1,"Re",m_pReGameButton);
}

void CFinish::Update(float dt, int nPassTime)
{
	/*if(m_bSound==true)
	{
		D_SOUNDMNG->Pause("GameBG",true);
	}*/
}

void CFinish::Render()
{
}

void CFinish::Clear()
{
	m_pTitle->SetTexture(m_pCSCeneGame,"Data/clear.png");

	m_pTitle->SetShow(true);
	m_pNextGameButton->SetShow(true);
	m_pReGameButton->SetShow(true);
}

void CFinish::Fail()
{
	m_pTitle->SetTexture(m_pCSCeneGame,"Data/fail.png");

	m_pTitle->SetShow(true);
	m_pReGameButton->SetShow(true);
}

bool CFinish::GetFinishState()
{
	if(m_pTitle->GetShow() == true)
		return true;
	return false;
}