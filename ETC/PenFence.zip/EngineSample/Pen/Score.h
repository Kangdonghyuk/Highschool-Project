#pragma once

#include "stdafx.h"

class CScore
{
private:
	CEMNumber* m_pScore;
private:
	float m_fScore;
private:
	
public:
	CScore(void);
	~CScore(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
	void Render();
public:
	int GetScore();
};

