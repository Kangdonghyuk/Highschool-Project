#include "stdafx.h"


void Bug::CreateBug(CSceneGame* scene, BUGNAME eBugName, int nBugNum)
{
	m_pCSceneGame = scene;

	m_eBugName = eBugName;
	m_eBugItemType = E_BUG_ITEM_NONE;
	m_nBugNum = nBugNum;

	m_stPrevPos.m_fX = 0;
	m_stPrevPos.m_fY = 0;

	switch(m_eBugName)
	{
	case E_ANT:
		m_pcBugName = "ANT";
		m_pcBugImageName = "Data/AntSprite.png";
		m_nMoveSpeed = 30.0f;
		break;
	case E_LADYBUG:
		m_pcBugName = "LADYBUG";
		m_pcBugImageName = "Data/LadyBugSprite.png";
		m_nMoveSpeed = 40.0f;
		break;
	case E_FIREFLY:
		m_pcBugName = "FIREFLY";
		m_pcBugImageName = "Data/FireFlySprite.png";
		m_nMoveSpeed = 50.0f;
		break;
	}

	m_b2Def.type = b2_dynamicBody;
	m_b2Def.position.Set(rand()%30-15,rand()%30-15);
	m_b2Def.allowSleep = false;
	m_b2Def.fixedRotation = true;

	m_b2Filter.groupIndex = m_eBugName;

	m_pb2Body = m_pCSceneGame->GetWorldPt()->
		CreateBody(&m_b2Def);

	m_b2Shape.SetAsBox(20.0f,20.0f);

	m_pb2Body->CreateFixture(&m_b2Shape,0.0f);

	/////////////////////////////////////////////////
	m_pBug = new CEMAni();
	switch(m_eBugName)
	{
	case E_ANT:
		m_pBug->SetTexture(m_pCSceneGame,
		m_pcBugImageName,stEMVec2(100,120),4,6);
		m_pBug->SetMotion(4, 6, 0.3f, 0, 1, 2, 3, 4, 5);
		m_pBug->SetMotion(3, 6, 0.1f, 6, 7, 8, 9, 10, 11);
		m_pBug->SetMotion(1, 6, 0.1f, 12, 13, 14, 15, 16, 17);
		m_pBug->SetMotion(2, 6, 0.1f, 18, 19, 20, 21, 22, 23);
		break;
	case E_LADYBUG:
		m_pBug->SetTexture(m_pCSceneGame,
		m_pcBugImageName,stEMVec2(100,120),4,3);
		m_pBug->SetMotion(4, 3, 0.3f, 0, 1, 2);
		m_pBug->SetMotion(3, 3, 0.1f, 3, 4, 5);
		m_pBug->SetMotion(1, 3, 0.1f, 6, 7, 8);
		m_pBug->SetMotion(2, 3, 0.1f, 9, 10, 11);
		break;
	case E_FIREFLY:
		m_pBug->SetTexture(m_pCSceneGame,
		m_pcBugImageName,stEMVec2(100,120),4,6);
		m_pBug->SetMotion(4, 6, 0.3f, 0, 1, 2, 3, 4, 5);
		m_pBug->SetMotion(3, 6, 0.1f, 6, 7, 8, 9, 10, 11);
		m_pBug->SetMotion(1, 6, 0.1f, 12, 13, 14, 15, 16, 17);
		m_pBug->SetMotion(2, 6, 0.1f, 18, 19, 20, 21, 22, 23);
		break;
	}
	m_pBug->SetBlend(true);
	m_pBug->SetType(E_BUG);
	m_pBug->ChangeMotion(0);
	m_pBug->ConnectBody(m_pb2Body);
	m_pBug->GetBody()->GetFixtureList()->SetFilterData(m_b2Filter);

	m_pCSceneGame->Commit(9,m_nBugNum,
		m_pcBugName,m_pBug);  

	m_pBug->SetShow(true);

	m_nMoveChangeTime = 10000;

	ChangeBugMoveType();
}

void Bug::UpdateBug(float dt, int nPassTime)
{
	BugCollision();

	if(nPassTime > m_nMoveChangeTime)
	{
		ChangeBugMoveType();
		m_nMoveChangeTime = nPassTime + 10000;
	}

	m_stPrevPos.m_fX = m_pBug->GetPosVec2().m_fX;
	m_stPrevPos.m_fY = m_pBug->GetPosVec2().m_fY;

	MoveBug();
}

void Bug::MoveBug()
{
	switch(m_eBugItemType)
	{
	case E_BUG_ITEM_NONE:
		{
			switch(m_eBugMoveType)
			{
			case E_BUG_MOVE_LEFT:
				m_pBug->MoveX(-m_nMoveSpeed);
				break;
			case E_BUG_MOVE_RIGHT:
				m_pBug->MoveX(m_nMoveSpeed);
				break;
			case E_BUG_MOVE_UP:
				m_pBug->MoveY(m_nMoveSpeed);
				break;
			case E_BUG_MOVE_DOWN:
				m_pBug->MoveY(-m_nMoveSpeed);
				break;
			case E_BUG_MOVE_LEFT_UP:
				m_pBug->MoveX(-m_nMoveSpeed);
				m_pBug->MoveY(m_nMoveSpeed);
				break;
			case E_BUG_MOVE_LEFT_DOWN:
				m_pBug->MoveX(-m_nMoveSpeed);
				m_pBug->MoveY(-m_nMoveSpeed);
				break;
			case E_BUG_MOVE_RIGHT_UP:
				m_pBug->MoveX(m_nMoveSpeed);
				m_pBug->MoveY(m_nMoveSpeed);
				break;
			case E_BUG_MOVE_RIGHT_DOWN:
				m_pBug->MoveX(m_nMoveSpeed);
				m_pBug->MoveY(-m_nMoveSpeed);
				break;
			}
		}break;
	case E_BUG_ITEM_FOOD:
		{
			if(m_pBug->GetPosVec2().m_fX > 0)
				m_pBug->MoveX(-m_nMoveSpeed);
			else if(m_pBug->GetPosVec2().m_fX < 0)
				m_pBug->MoveX(m_nMoveSpeed);
			if(m_pBug->GetPosVec2().m_fY > 0)
				m_pBug->MoveY(-m_nMoveSpeed);
			else if(m_pBug->GetPosVec2().m_fY < 0)
				m_pBug->MoveY(m_nMoveSpeed);
		}break;
	}
}

void Bug::Pause()
{
	//cout<<"a"<<endl;
	//m_pBug->SetPos(m_pBug->GetPosVec2());
	m_pBug->MoveX(0.f);
	m_pBug->MoveY(0.f);
}

void Bug::UpdateVal()
{
	stEMVec2 vGetPos = m_pBug->GetPosVec2();

	float fInterX = vGetPos.m_fX - m_stPrevPos.m_fX;
	float fInterY = vGetPos.m_fY - m_stPrevPos.m_fY;

	float fRad = (float)atan2(fInterY, fInterX);

	//if(abs(fInterX) >= 0.3f
	//	|| abs(fInterY) >= 0.3f)
	{
		m_pBug->SetZRot((180.f / 3.141592f) * fRad - 90.f);
	}
}

void Bug::SetBugItemType(BUGITEMTYPE eBugItemType)
{
	m_eBugItemType = eBugItemType;
}

void Bug::ChangeBugMoveType()
{
	int nRander = rand()%(E_BUG_MOVE_MAX-1)+1;

	m_eBugMoveType = (BUGMOVETYPE)nRander;

	m_nMoveChangeTime = rand()%300000+5000;

	switch(m_eBugMoveType)
	{
	case E_BUG_MOVE_LEFT:
		m_pBug->ChangeMotion(E_BUG_MOVE_LEFT);
		break;
	case E_BUG_MOVE_RIGHT:
		m_pBug->ChangeMotion(E_BUG_MOVE_RIGHT);
		break;
	case E_BUG_MOVE_UP:
		m_pBug->ChangeMotion(E_BUG_MOVE_UP);
		break;
	case E_BUG_MOVE_DOWN:
		m_pBug->ChangeMotion(E_BUG_MOVE_DOWN);
		break;
	case E_BUG_MOVE_LEFT_UP:
		m_pBug->ChangeMotion(E_BUG_MOVE_LEFT);
		break;
	case E_BUG_MOVE_LEFT_DOWN:
		m_pBug->ChangeMotion(E_BUG_MOVE_LEFT);
		break;
	case E_BUG_MOVE_RIGHT_UP:
		m_pBug->ChangeMotion(E_BUG_MOVE_RIGHT);
		break;
	case E_BUG_MOVE_RIGHT_DOWN:
		m_pBug->ChangeMotion(E_BUG_MOVE_RIGHT);
		break;
	}
}

void Bug::BugCollision()
{
	vector<CEMPlane*> hihi = m_pCSceneGame->
		GetCollisionPlanes(m_pBug);
	vector<CEMPlane*>::iterator pos = hihi.begin();

	for(pos; pos!=hihi.end(); pos++)
	{
		switch((*pos)->GetType())
		{
		case E_BUG:
			//ChangeBugMoveType();
			break;
		case E_FIRE:
			m_pBug->SetShow(false);
			break;
		}
		//(*pos)->Destroy();		//!< �浹 �� ������.
	}
}

stEMVec2 Bug::GetBugPos()
{
	return m_pBug->GetPosVec2();
}

CEMPlane* Bug::GetBugPoint()
{
	return m_pBug;
}

///////////////////////////////////////////

CVectorBug::CVectorBug(void)
{
}


CVectorBug::~CVectorBug(void)
{
}

void CVectorBug::Enter(CSceneGame* scene, BUGNAME eBugName)
{
	m_pCSceneGame = scene;

	m_eBugName = eBugName;
	m_eBugItemType = E_BUG_ITEM_NONE;

	m_nBugNum = 0;
	m_nDieBugNum = 0;
}

void CVectorBug::Update(float dt, int nPassTime)
{
	m_nPassTime = nPassTime;

	for(m_vBugIt = m_vBug.begin();
		m_vBugIt < m_vBug.end();)
	{
		(*m_vBugIt)->UpdateBug(dt,m_nPassTime);
		(*m_vBugIt)->SetBugItemType(m_eBugItemType);
		//(*m_vBugIt)->UpdateVal();

		if(abs((*m_vBugIt)->GetBugPos().m_fY) > 200 ||
			abs((*m_vBugIt)->GetBugPos().m_fX) > 300
			)
		{
			(*m_vBugIt)->GetBugPoint()->Destroy();
			m_vBugIt = m_vBug.erase(m_vBugIt);
			m_nDieBugNum++;
			//m_vBugIt--;
		}
		else if((*m_vBugIt)->GetBugPoint()->GetShow() == false)
		{
			(*m_vBugIt)->GetBugPoint()->Destroy();
			m_vBugIt = m_vBug.erase(m_vBugIt);
		}
		else if((*m_vBugIt)->GetBugPoint()->GetShow() != false &&
			abs((*m_vBugIt)->GetBugPos().m_fY) >= 200 ||
			abs((*m_vBugIt)->GetBugPos().m_fX) <= 300 )
		{
			m_vBugIt++;
		}
	}
}

void CVectorBug::Pause()
{
	for(m_vBugIt = m_vBug.begin();
		m_vBugIt < m_vBug.end();)
	{
		(*m_vBugIt)->Pause();
		m_vBugIt++;
	}
}

void CVectorBug::CreateBug()
{
	Bug* pBug = new Bug;
	pBug->CreateBug(m_pCSceneGame,m_eBugName,m_nBugNum);

	m_vBug.push_back(pBug);

	m_nBugNum++;
}

void CVectorBug::DeleteBug()
{
	for(m_vBugIt = m_vBug.begin();
		m_vBugIt < m_vBug.end();)
	{
		(*m_vBugIt)->GetBugPoint()->Destroy();
		m_vBugIt = m_vBug.erase(m_vBugIt);
		//m_vBugIt++;
	}

	m_vBug.clear();
}

void CVectorBug::SetBugItemType(BUGITEMTYPE eBugItemType)
{
	m_eBugItemType = eBugItemType;
}

int CVectorBug::GetDieBugNum()
{
	return m_nDieBugNum;
}
