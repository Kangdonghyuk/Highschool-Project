//#include "HowToPlay.h"
//
//void HowToPlay::Enter(CSceneWork* pSceneWork)
//{
//	//!=========================================
//	//!ī�޶�	
//	D_CAMERA->SetPos(m_stCamPos);
//	
//	D_SOUNDMNG->Commit("EffectBG","Data/Button.wav");
//	D_SOUNDMNG->Commit("GameBG","Data/Sleep Away.mp3");
//	if(m_bSound==true)
//	{
//		D_SOUNDMNG->Play("GameBG",true,1.0f);
//	}
//	//!=====================================================
//		m_pBeckGround= new CEMPlane;
//		m_pBeckGround->SetSize(1.f, 1.f);
//		m_pBeckGround->SetTexture(this,"Data/���1.png");
//		m_pBeckGround->SetPos(0.0f,0.0f);
//		m_pBeckGround->SetBlend(true);
//		m_pBeckGround->SetShow(true);
//		Commit(1,"���",m_pBeckGround);
//
//	m_pBackButten= new CEMPlane;
//	m_pBackButten->SetSize(1.f, 1.f);
//	m_pBackButten->SetTexture(this,"Data/BackButten.png");
//	m_pBackButten->SetPos(230.0f,-170.0f);
//	m_pBackButten->SetBlend(true);
//	m_pBackButten->SetShow(true);
//	Commit(0,"�ڷΰ���",m_pBackButten);
//	
//	//===========================================================
//	g_ItemPen.Enter(this);
//	
//	CRootScene::Enter(pSceneWork);
//}
//
//void HowToPlay::Update(CSceneWork* pSceneWork, float dt)
//{
//	g_ItemPen.SceneUpdate();
//
//	CEMPlane* pPlane = NULL;
//	pPlane = AABBvsRay(D_INPUT->GetMouseMovePos().m_nX, D_INPUT->GetMouseMovePos().m_nY);
//
//	if(pPlane != NULL)
//	{
//		if(pPlane->GetName()!="�ڷΰ���")
//		m_pBackButten->SetSize(1.0f,1.0f);
//	}	
//	CRootScene::Update(pSceneWork, dt);
//}
//
//void HowToPlay::Render(CSceneWork* pSceneWork)
//{
//
//
//	CRootScene::Render(pSceneWork);
//}
//
//void HowToPlay::Exit(CSceneWork* pSceneWork)
//{
//	Destroy();				//!< ���� ������ �޸� ������ ���� ����
//	TwDeleteBar(m_pBar);	//!< ���� ����
//
//	if(D_SOUNDMNG->IsPlay("GameBG") == true)
//			D_SOUNDMNG->Stop("GameBG");
//
//	CRootScene::Exit(pSceneWork);
//}
//
//void HowToPlay::MouseDownEvent(stMouseInfo stPos, enumMouseButton eButton)
//{
//
//}
//
//void HowToPlay::MouseUpEvent(stMouseInfo stPos, enumMouseButton eButton)
//{
// 	switch(eButton)
// 	{
// 	case E_MOUSE_LEFT:
// 		{
// 			CEMPlane* pPlane = AABBvsRay(stPos.m_nX, stPos.m_nY);
//			if(pPlane)
//			{       
//				if(pPlane->GetName()=="�ڷΰ���")
//				D_SCENE->ChangeSceneFade("GameMenu",0.05f,0.05f);
//			} 
// 		}break;
// 	}
//}
//
//void HowToPlay::MouseMoveEvent(stMouseInfo stPos)
//{
//	CEMPlane* pPlane = AABBvsRay(stPos.m_nX, stPos.m_nY);
//	if(pPlane)
//	{
//		if(pPlane->GetName()=="�ڷΰ���")
//		{
//			m_pBackButten->SetSize(1.5f,1.5f);
//			if(m_bSound2==true)
//			{
//				if(m_SoundCount==0)
//				{
//					D_SOUNDMNG->Play("EffectBG",false,1.f);
//					m_SoundCount++;
//				}
//			}
//		}	
//		if(pPlane->GetName()!="�ڷΰ���")
//		{
//			m_SoundCount=0;
//		}
//	}
//}
//
//HRESULT HowToPlay::WindowMessage(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
//{
//	switch(msg)
//	{
//	case WM_LBUTTONDOWN:
//		{
//			int x = 0;
//		}break;
//	}
//	return msg;
//}
//
//
//void HowToPlay::BeginContact(b2Contact* contact)
//{
//	CEMPhysicRoot::BeginContact(contact);
//	//�Ʒ��� �ڵ带 �ۼ��ϼ���
//
//
//}
//
//void HowToPlay::EndContact(b2Contact* contact)
//{
//	CEMPhysicRoot::EndContact(contact);
//	//�Ʒ��� �ڵ带 �ۼ��ϼ���
//
//}
//
//void HowToPlay::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
//{
//	CEMPhysicRoot::PreSolve(contact, oldManifold);
//	//�Ʒ��� �ڵ带 �ۼ��ϼ���
//
//}
//
//void HowToPlay::PostSolve(const b2Contact* contact, const b2ContactImpulse* impulse)
//{
//	CEMPhysicRoot::PostSolve(contact, impulse);
//	//�Ʒ��� �ڵ带 �ۼ��ϼ���
//
//}
//
