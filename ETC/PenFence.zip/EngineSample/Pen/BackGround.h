#pragma once

#include "stdafx.h"

class CBackGround
{
private:
	CSceneGame* m_pCSceneGame;
private:
	CEMPlane* m_pBackGround;
public:
	CBackGround(void);
	~CBackGround(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
	void Render();
};

