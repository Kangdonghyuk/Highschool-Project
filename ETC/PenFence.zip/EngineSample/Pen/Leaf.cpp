#include "stdafx.h"


CLeaf::CLeaf(void)
{
}


CLeaf::~CLeaf(void)
{
}

void CLeaf::Enter(CSceneGame* scene)
{
	/*for(int i=0; i<5; i++)
	{
	m_pLeaf[i]= new CEMPlane;
	m_pLeaf[i]->SetTexture(scene,"Data/leaf.png");
	m_pLeaf[i]->SetSize(0.2f,0.2f);
	m_pLeaf[i]->SetPos(rand()%200-100,rand()%200-100,0.0f);
	m_pLeaf[i]->SetType(E_LEAF);
	m_pLeaf[i]->SetBlend(true);
	m_pLeaf[i]->SetShow(true);

	scene->Commit(0,i,"leaf",m_pLeaf[i]);
	}*/

	m_pLeaf= new CEMPlane;
	m_pLeaf->SetTexture(scene,"Data/leaf.png");
	m_pLeaf->SetSize(1.0f,1.0f);
	m_pLeaf->SetPos(rand()%200-100,rand()%200-100,0.0f);
	m_pLeaf->SetType(E_LEAF);
	m_pLeaf->SetBlend(true);
	m_pLeaf->SetShow(false);

	scene->Commit(1,"leaf",m_pLeaf);

	m_bLeafState = false;

	if(g_nRound <= 20)
		m_nReAddTime = 25000 - (g_nRound*1000);
	else if(g_nRound > 20)
		m_nReAddTime = 4000;
	m_nReTime = m_nReAddTime;

	m_pChoLeaf = NULL;
}

void CLeaf::Update(float dt, int nPassTime)
{
	if(m_bLeafState == false)
	{
		if(nPassTime > m_nReTime)
		{
			m_pLeaf->SetPos(rand()%200-100,rand()%200-100);
			m_pLeaf->SetShow(true);
			m_nReTime = nPassTime + m_nReAddTime;
			m_bLeafState = true;
		}
	}
	else if(m_bLeafState == true)
	{
		if(GetChoose() != NULL)
		{
			if(abs(m_pChoLeaf->GetPosVec2().m_fY) > 150 ||
				abs(m_pChoLeaf->GetPosVec2().m_fX) > 250)
			{
				m_pChoLeaf->SetShow(false);
				m_pChoLeaf = NULL;
				m_nReTime = nPassTime+m_nReAddTime;
				m_bLeafState = false;
			}
		}
	}
}

void CLeaf::Render()
{
}

void CLeaf::SetChoose(CEMPlane* pLeaf)
{
	m_pChoLeaf = pLeaf;
}

CEMPlane* CLeaf::GetChoose()
{
	return m_pChoLeaf;
}

void CLeaf::SetLeafPos(stEMVec2 stPos)
{
	m_pChoLeaf->SetPos(stPos);
}

bool CLeaf::GetLeafState()
{
	return m_pLeaf->GetShow();
}