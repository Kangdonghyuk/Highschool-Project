#include "stdafx.h"

CItemPen g_ItemPen;

void KGLogo::Enter(CSceneWork* pSceneWork)
{
	D_SOUNDMNG->Commit("GameBG","Data/FenceBug.wav");
	D_SOUNDMNG->Play("GameBG",true);

	g_ItemPen.Enter(this);

	D_CAMERA->SetPos(m_stCamPos);
	//!=====================================================
	m_pPlane = new CEMPlane;
	m_pPlane->SetTexture(this, "Data/�Ա���.png");
	m_pPlane->SetSize(3.5f, 1.5f);
	m_pPlane->SetPos(0.0f, 150.0f, 0.0f);
	m_pPlane->SetBlend(true);
	m_pPlane->SetShow(true);

	Commit(0,"�Ա���",m_pPlane);
	
	
	m_pKg = new CEMPlane;
	m_pKg->SetTexture(this, "Data/Kg.png");
	m_pKg->SetSize(1.f, 1.f);
	m_pKg->SetPos(0.0f, 0.0f, 0.0f);
	m_pKg->SetBlend(true);		
	m_pKg->SetShow(true);

	m_pKg->SetXRot(160);
	Commit(0,"kg�ΰ�",m_pKg);
	//===========================================================
	k=0;
	CRootScene::Enter(pSceneWork);
}



void KGLogo::Update(CSceneWork* pSceneWork, float dt)
{	
	g_ItemPen.SceneUpdate();
	k+=1;
	m_pKg->SetXRot(160+k);

 	if(k>=200)
	{
		D_SCENE->ChangeScene("TeamLogo");
	}
	CRootScene::Update(pSceneWork, dt);
}

void KGLogo::Render(CSceneWork* pSceneWork)
{


	CRootScene::Render(pSceneWork);
}

void KGLogo::Exit(CSceneWork* pSceneWork)
{
	Destroy();				//!< ���� ������ �޸� ������ ���� ����
	TwDeleteBar(m_pBar);	//!< ���� ����

	CRootScene::Exit(pSceneWork);
}

void KGLogo::MouseDownEvent(stMouseInfo stPos, enumMouseButton eButton)
{
	
}

void KGLogo::MouseUpEvent(stMouseInfo stPos, enumMouseButton eButton)
{
 	switch(eButton)
 	{
 	case E_MOUSE_LEFT:
 		{
			D_SCENE->ChangeSceneFade("TeamLogo",0.05f,0.05f);
 		}break;
 	}
}

void KGLogo::MouseMoveEvent(stMouseInfo stPos)
{

}

HRESULT KGLogo::WindowMessage(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_LBUTTONDOWN:
		{
			int x = 0;
		}break;
	}
	return msg;
}


void KGLogo::BeginContact(b2Contact* contact)
{
	CEMPhysicRoot::BeginContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void KGLogo::EndContact(b2Contact* contact)
{
	CEMPhysicRoot::EndContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void KGLogo::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
{
	CEMPhysicRoot::PreSolve(contact, oldManifold);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void KGLogo::PostSolve(const b2Contact* contact, const b2ContactImpulse* impulse)
{
	CEMPhysicRoot::PostSolve(contact, impulse);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

