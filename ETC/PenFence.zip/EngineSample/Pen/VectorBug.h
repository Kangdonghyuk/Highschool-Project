#pragma once

#include "stdafx.h"

class Bug
{
private:
	CSceneGame* m_pCSceneGame;
private:
	//CEMPlane* m_pBug;
	CEMAni* m_pBug;
	BUGMOVETYPE m_eBugMoveType;
	BUGITEMTYPE	m_eBugItemType;
	BUGNAME m_eBugName;
	stEMVec2	m_stPrevPos;
private:
	b2BodyDef m_b2Def;
	b2Body* m_pb2Body;
	b2Filter m_b2Filter;
	b2PolygonShape m_b2Shape;
private:
	char* m_pcBugName;
	char* m_pcBugImageName;
	int m_nBugNum;
	int m_nMoveChangeTime;
	int m_nMoveSpeed;
	//////////////////////////
public:
	void CreateBug(CSceneGame* scene,BUGNAME eBugName, int nBugNum);
	void UpdateBug(float dt, int nPassTime);
	void MoveBug();
	void Pause();
	void UpdateVal();
public:
	void SetBugItemType(BUGITEMTYPE eBugItemType);
	void ChangeBugMoveType();
public:
	void BugCollision();
public:
	stEMVec2 GetBugPos();
	CEMPlane* GetBugPoint();
};

class CVectorBug
{
private:
	CSceneGame* m_pCSceneGame;
private:
	vector<Bug*> m_vBug;
	vector<Bug*>::iterator m_vBugIt;
private:
	BUGNAME m_eBugName;
	BUGITEMTYPE m_eBugItemType;
private:
	int m_nBugNum;
	int m_nDieBugNum;
private:
	int m_nPassTime;
	////////////////////////////////
public:
	CVectorBug(void);
	~CVectorBug(void);
public:
	void Enter(CSceneGame* scene, BUGNAME eBugName);
	void Update(float dt, int nPassTime);
	void Pause();
public:
	void CreateBug();
	void DeleteBug();
public:
	void SetBugItemType(BUGITEMTYPE eBugItemType);
	int GetDieBugNum();
};

