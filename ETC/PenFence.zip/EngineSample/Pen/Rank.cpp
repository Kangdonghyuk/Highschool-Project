#include "stdafx.h"

//CItemPen g_ItemPen;

void Rank::Enter(CSceneWork* pSceneWork)
{
	FILE* fp = fopen("Rank.txt","rt");

	for(int i=0; i<10; i++)
		fscanf(fp,"%d",&m_nArr[i]);

	if(g_nRound > m_nArr[9])
		m_nArr[9] = g_nRound;

	g_nRound = 0;

	for(int i=0; i<10; i++)
	{
		for(int j=i; j<10; j++)
		{
			if(m_nArr[i] < m_nArr[j])
			{
				int Temp = m_nArr[i];
				m_nArr[i] = m_nArr[j];
				m_nArr[j] = Temp;
			}
		}
	}

	fclose(fp);

	for(int i=0; i<10; i++)
	{
		m_Rank[i] = new CEMNumber(10);
		m_Rank[i]->SetPos(0.0f, 200.0f - (i*40), 0.0f);
		m_Rank[i]->SetStyle(E_NUMSTYLE_BASIC);							//!< �ð����� �� ����Ҷ����� E_NUMSTYLE_BASIC�� ��� �Ͻø� �˴ϴ�. ��Ÿ �ٸ� �ɼ��� Update���� ��� ȣ���Ͻø� �����ϴ�.
		m_Rank[i]->SetSize(1.0f, 1.0f);
		//m_Rank[i]->SetOrtho2D(true);
		m_Rank[i]->SetTexture(this, 10, 
			"Data/Image/Number/0.png", 
			"Data/Image/Number/1.png", 
			"Data/Image/Number/2.png", 
			"Data/Image/Number/3.png",
			"Data/Image/Number/4.png",
			"Data/Image/Number/5.png",
			"Data/Image/Number/6.png",
			"Data/Image/Number/7.png",
			"Data/Image/Number/8.png",
			"Data/Image/Number/9.png"
			);
		m_Rank[i]->SetShow(true); //���ھ��߰�
		m_Rank[i]->SetNumber(m_nArr[i]);

		Commit(0,i,"Rank", m_Rank[i]);
	}

	g_ItemPen.Enter(this);

	CRootScene::Enter(pSceneWork);
}

void Rank::Update(CSceneWork* pSceneWork, float dt)
{
	g_ItemPen.SceneUpdate();

	CRootScene::Update(pSceneWork, dt);
}

void Rank::Render(CSceneWork* pSceneWork)
{
	CRootScene::Render(pSceneWork);
}

void Rank::Exit(CSceneWork* pSceneWork)
{
	FILE* fp = fopen("Rank.txt","wt");

	for(int i=0; i<10; i++)
	{
		fprintf(fp,"%d\n",m_nArr[i]);
	}

	fclose(fp);

	Destroy();				//!< ���� ������ �޸� ������ ���� ����

	CRootScene::Exit(pSceneWork);
}

void Rank::MouseDownEvent(stMouseInfo stPos, enumMouseButton eButton)
{

}

void Rank::MouseUpEvent(stMouseInfo stPos, enumMouseButton eButton)
{
 	switch(eButton)
 	{
 	case E_MOUSE_LEFT:
 		{
 			D_SCENE->ChangeScene("GameMenu");
 
 		}break;
 	}
}

void Rank::MouseMoveEvent(stMouseInfo stPos)
{

}

HRESULT Rank::WindowMessage(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_LBUTTONDOWN:
		{
			int x = 0;
		}break;
	}
	return msg;
}


void Rank::BeginContact(b2Contact* contact)
{
	CEMPhysicRoot::BeginContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���


}

void Rank::EndContact(b2Contact* contact)
{
	CEMPhysicRoot::EndContact(contact);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void Rank::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
{
	CEMPhysicRoot::PreSolve(contact, oldManifold);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

void Rank::PostSolve(const b2Contact* contact, const b2ContactImpulse* impulse)
{
	CEMPhysicRoot::PostSolve(contact, impulse);
	//�Ʒ��� �ڵ带 �ۼ��ϼ���

}

