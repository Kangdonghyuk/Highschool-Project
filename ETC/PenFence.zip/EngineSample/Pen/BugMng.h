#pragma once

#include "stdafx.h"

class CBugMng
{ 
private:
	CRootBug* m_pBug[E_BUG_MAX];
	CAnt* m_pAnt;
	CLadyBug* m_pLadyBug;
	CFireFly* m_pFireFly;
private:
	int m_nDieBugNum;
public:
	CBugMng(void);
	~CBugMng(void);
public:
	void Enter(CSceneGame* scene);
	void Update(float dt, int nPassTime);
	void Pause();
public:
	void DeleteBug();
public:
	void SetItmeType(BUGITEMTYPE eBugItemType);
	int GetDieBugNum();
};

